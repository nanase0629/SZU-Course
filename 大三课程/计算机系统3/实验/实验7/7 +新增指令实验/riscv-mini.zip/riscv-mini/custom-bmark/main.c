int add(int a, int b);

int main(int argc, char** argv) {
  int res = add(3, 2);
  return res == 5 ? 0 : -1;
}
