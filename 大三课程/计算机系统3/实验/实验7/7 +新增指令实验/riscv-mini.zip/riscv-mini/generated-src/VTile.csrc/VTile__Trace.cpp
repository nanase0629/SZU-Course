// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "VTile__Syms.h"


//======================

void VTile::traceChg(VerilatedVcd* vcdp, void* userthis, uint32_t code) {
    // Callback from vcd->dump()
    VTile* t = (VTile*)userthis;
    VTile__Syms* __restrict vlSymsp = t->__VlSymsp;  // Setup global symbol table
    if (vlSymsp->getClearActivity()) {
        t->traceChgThis(vlSymsp, vcdp, code);
    }
}

//======================


void VTile::traceChgThis(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        if (VL_UNLIKELY((1U & (vlTOPp->__Vm_traceActivity 
                               | (vlTOPp->__Vm_traceActivity 
                                  >> 1U))))) {
            vlTOPp->traceChgThis__2(vlSymsp, vcdp, code);
        }
        if (VL_UNLIKELY((1U & ((vlTOPp->__Vm_traceActivity 
                                | (vlTOPp->__Vm_traceActivity 
                                   >> 1U)) | (vlTOPp->__Vm_traceActivity 
                                              >> 2U))))) {
            vlTOPp->traceChgThis__3(vlSymsp, vcdp, code);
        }
        if (VL_UNLIKELY((1U & (vlTOPp->__Vm_traceActivity 
                               | (vlTOPp->__Vm_traceActivity 
                                  >> 2U))))) {
            vlTOPp->traceChgThis__4(vlSymsp, vcdp, code);
        }
        if (VL_UNLIKELY((2U & vlTOPp->__Vm_traceActivity))) {
            vlTOPp->traceChgThis__5(vlSymsp, vcdp, code);
        }
        vlTOPp->traceChgThis__6(vlSymsp, vcdp, code);
    }
    // Final
    vlTOPp->__Vm_traceActivity = 0U;
}

void VTile::traceChgThis__2(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Variables
    // Begin mtask footprint all: 
    WData/*287:0*/ __Vtemp95[9];
    WData/*287:0*/ __Vtemp96[9];
    // Body
    {
        vcdp->chgBit(c+1,((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))));
        vcdp->chgBus(c+9,((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__next_pc)),32);
        vcdp->chgBit(c+17,(vlTOPp->Tile__DOT__icache_io_cpu_resp_valid));
        vcdp->chgBus(c+25,(((3U == (3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                          >> 2U))) ? 
                            vlTOPp->Tile__DOT__icache__DOT__read[3U]
                             : ((2U == (3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                              >> 2U)))
                                 ? vlTOPp->Tile__DOT__icache__DOT__read[2U]
                                 : ((1U == (3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                  >> 2U)))
                                     ? vlTOPp->Tile__DOT__icache__DOT__read[1U]
                                     : vlTOPp->Tile__DOT__icache__DOT__read[0U])))),32);
        vcdp->chgBit(c+33,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt));
        vcdp->chgBit(c+41,(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
        vcdp->chgBus(c+49,((IData)(((QData)((IData)(
                                                    (0x3fffffffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___daddr_T 
                                                        >> 2U)))) 
                                    << 2U))),32);
        VL_EXTEND_WI(287,32, __Vtemp95, vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2);
        VL_SHIFTL_WWI(287,287,8, __Vtemp96, __Vtemp95, 
                      ((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                 << 3U)) | (8U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                                  << 3U))));
        vcdp->chgBus(c+57,(__Vtemp96[0U]),32);
        vcdp->chgBus(c+65,((0xfU & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T_10))),4);
        vcdp->chgBit(c+73,(vlTOPp->Tile__DOT__dcache_io_cpu_resp_valid));
        vcdp->chgBus(c+81,(vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data),32);
        vcdp->chgBit(c+89,(((0U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                            & ((1U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                ? ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT__hit)) 
                                   & (IData)(vlTOPp->Tile__DOT__icache__DOT__is_dirty))
                                : ((2U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                   & ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T)) 
                                      & (IData)(vlTOPp->Tile__DOT__icache__DOT__is_dirty)))))));
        vcdp->chgBus(c+97,(((vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_data 
                             << 0xcU) | (0xff0U & vlTOPp->Tile__DOT__icache__DOT__addr_reg))),32);
        vcdp->chgQuad(c+105,(((IData)(vlTOPp->Tile__DOT__icache__DOT__write_count)
                               ? (((QData)((IData)(
                                                   vlTOPp->Tile__DOT__icache__DOT__read[3U])) 
                                   << 0x20U) | (QData)((IData)(
                                                               vlTOPp->Tile__DOT__icache__DOT__read[2U])))
                               : (((QData)((IData)(
                                                   vlTOPp->Tile__DOT__icache__DOT__read[1U])) 
                                   << 0x20U) | (QData)((IData)(
                                                               vlTOPp->Tile__DOT__icache__DOT__read[0U]))))),64);
        vcdp->chgBit(c+121,(vlTOPp->Tile__DOT__icache_io_nasti_ar_valid));
        vcdp->chgBit(c+129,(vlTOPp->Tile__DOT__dcache_io_nasti_aw_valid));
        vcdp->chgBus(c+137,(((vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data 
                              << 0xcU) | (0xff0U & vlTOPp->Tile__DOT__dcache__DOT__addr_reg))),32);
        vcdp->chgBit(c+145,(vlTOPp->Tile__DOT__dcache_io_nasti_w_valid));
        vcdp->chgQuad(c+153,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count)
                               ? (((QData)((IData)(
                                                   vlTOPp->Tile__DOT__dcache__DOT__read[3U])) 
                                   << 0x20U) | (QData)((IData)(
                                                               vlTOPp->Tile__DOT__dcache__DOT__read[2U])))
                               : (((QData)((IData)(
                                                   vlTOPp->Tile__DOT__dcache__DOT__read[1U])) 
                                   << 0x20U) | (QData)((IData)(
                                                               vlTOPp->Tile__DOT__dcache__DOT__read[0U]))))),64);
        vcdp->chgBit(c+169,(vlTOPp->Tile__DOT__dcache_io_nasti_b_ready));
        vcdp->chgBit(c+177,(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid));
        vcdp->chgBit(c+185,(vlTOPp->Tile__DOT__arb_io_nasti_aw_valid));
        vcdp->chgBit(c+193,(((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_valid) 
                             & (3U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
        vcdp->chgBit(c+201,(vlTOPp->Tile__DOT__arb_io_nasti_b_ready));
        vcdp->chgBit(c+209,(((((IData)(vlTOPp->Tile__DOT__icache_io_nasti_ar_valid) 
                               | (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid)) 
                              & (~ (IData)(vlTOPp->Tile__DOT__arb_io_nasti_aw_valid))) 
                             & (0U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
        vcdp->chgBus(c+217,(((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid)
                              ? (0xfffffff0U & vlTOPp->Tile__DOT__dcache__DOT__addr_reg)
                              : (0xfffffff0U & vlTOPp->Tile__DOT__icache__DOT__addr_reg))),32);
        vcdp->chgBit(c+225,(vlTOPp->Tile__DOT__arb_io_nasti_r_ready));
        vcdp->chgBus(c+233,(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel),2);
        vcdp->chgBit(c+241,(((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x6fU == (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   | ((0x67U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x5063U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x6063U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_434))))))))))));
        vcdp->chgBit(c+249,(((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x6fU != (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x67U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x5063U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x6063U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_189))))))))))));
        vcdp->chgBit(c+257,(((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x6fU != (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x67U != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_240))))))))));
        vcdp->chgBus(c+265,(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel),3);
        vcdp->chgBus(c+273,(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op),4);
        vcdp->chgBus(c+281,(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type),3);
        vcdp->chgBus(c+289,(vlTOPp->Tile__DOT__core__DOT__ctrl_io_st_type),2);
        vcdp->chgBus(c+297,(vlTOPp->Tile__DOT__core__DOT__ctrl_io_ld_type),3);
        vcdp->chgBus(c+305,(((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x17U == (0x7fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_588)))),2);
        vcdp->chgBit(c+313,(((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             | ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                | ((0x6fU == (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   | ((0x67U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x5063U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x6063U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & ((0x7063U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((3U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           | ((0x1003U 
                                                               == 
                                                               (0x707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              | ((0x2003U 
                                                                  == 
                                                                  (0x707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                 | ((0x4003U 
                                                                     == 
                                                                     (0x707fU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                    | ((0x5003U 
                                                                        == 
                                                                        (0x707fU 
                                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                       | ((0x23U 
                                                                           != 
                                                                           (0x707fU 
                                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                          & ((0x1023U 
                                                                              != 
                                                                              (0x707fU 
                                                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                             & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_622))))))))))))))))))));
        vcdp->chgBus(c+321,(((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x17U == (0x7fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_686)))),3);
        vcdp->chgBit(c+329,(((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x6fU != (0x7fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x67U != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x63U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x1063U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x4063U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x5063U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x6063U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & ((0x7063U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((3U 
                                                            != 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & ((0x1003U 
                                                               != 
                                                               (0x707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              & ((0x2003U 
                                                                  != 
                                                                  (0x707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                 & ((0x4003U 
                                                                     != 
                                                                     (0x707fU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                    & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_723)))))))))))))))));
        vcdp->chgBit(c+337,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall));
        vcdp->chgBus(c+345,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out),32);
        vcdp->chgBus(c+353,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata1),32);
        vcdp->chgBus(c+361,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata2),32);
        vcdp->chgBit(c+369,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
                              & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall))) 
                             & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))));
        vcdp->chgBus(c+377,((IData)(((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                      ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out))
                                      : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                          ? (QData)((IData)(
                                                            ((IData)(4U) 
                                                             + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc)))
                                          : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                              ? ((5U 
                                                  == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                                  ? (QData)((IData)(
                                                                    (0xffU 
                                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift)))
                                                  : 
                                                 ((4U 
                                                   == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                                   ? (QData)((IData)(
                                                                     (0xffffU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift)))
                                                   : 
                                                  ((3U 
                                                    == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                                    ? 
                                                   (((QData)((IData)(
                                                                     (0x1ffffffU 
                                                                      & VL_NEGATE_I((IData)(
                                                                                (1U 
                                                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
                                                                                >> 7U))))))) 
                                                     << 8U) 
                                                    | (QData)((IData)(
                                                                      (0xffU 
                                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift))))
                                                    : 
                                                   ((2U 
                                                     == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                                     ? 
                                                    (((QData)((IData)(
                                                                      (0x1ffffU 
                                                                       & VL_NEGATE_I((IData)(
                                                                                (1U 
                                                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
                                                                                >> 0xfU))))))) 
                                                      << 0x10U) 
                                                     | (QData)((IData)(
                                                                       (0xffffU 
                                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift))))
                                                     : (QData)((IData)(vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data))))))
                                              : (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu))))))),32);
        vcdp->chgBus(c+385,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A),32);
        vcdp->chgBus(c+393,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B),32);
        vcdp->chgBus(c+401,((((0U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)) 
                              | (1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)))
                              ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum
                              : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___out_T_25)),32);
        vcdp->chgBus(c+409,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum),32);
        vcdp->chgBus(c+417,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen_io_out),32);
        vcdp->chgBus(c+425,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1),32);
        vcdp->chgBus(c+433,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2),32);
        vcdp->chgBit(c+441,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond_io_taken));
        vcdp->chgQuad(c+449,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__next_pc),33);
        vcdp->chgBit(c+465,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1hazard));
        vcdp->chgBit(c+473,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2hazard));
        vcdp->chgQuad(c+481,(((QData)((IData)((0x3fffffffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___daddr_T 
                                                  >> 2U)))) 
                              << 2U)),35);
        vcdp->chgBus(c+497,(((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                       << 3U)) | (8U 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                                     << 3U)))),8);
        vcdp->chgBus(c+505,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift),32);
        vcdp->chgQuad(c+513,(((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                               ? (QData)((IData)((0xffU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift)))
                               : ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                   ? (QData)((IData)(
                                                     (0xffffU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift)))
                                   : ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                       ? (((QData)((IData)(
                                                           (0x1ffffffU 
                                                            & VL_NEGATE_I((IData)(
                                                                                (1U 
                                                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
                                                                                >> 7U))))))) 
                                           << 8U) | (QData)((IData)(
                                                                    (0xffU 
                                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift))))
                                       : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                           ? (((QData)((IData)(
                                                               (0x1ffffU 
                                                                & VL_NEGATE_I((IData)(
                                                                                (1U 
                                                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
                                                                                >> 0xfU))))))) 
                                               << 0x10U) 
                                              | (QData)((IData)(
                                                                (0xffffU 
                                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift))))
                                           : (QData)((IData)(vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data))))))),33);
        vcdp->chgQuad(c+529,(((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                               ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out))
                               : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                   ? (QData)((IData)(
                                                     ((IData)(4U) 
                                                      + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc)))
                                   : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                       ? ((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                           ? (QData)((IData)(
                                                             (0xffU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift)))
                                           : ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                               ? (QData)((IData)(
                                                                 (0xffffU 
                                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift)))
                                               : ((3U 
                                                   == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                                   ? 
                                                  (((QData)((IData)(
                                                                    (0x1ffffffU 
                                                                     & VL_NEGATE_I((IData)(
                                                                                (1U 
                                                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
                                                                                >> 7U))))))) 
                                                    << 8U) 
                                                   | (QData)((IData)(
                                                                     (0xffU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift))))
                                                   : 
                                                  ((2U 
                                                    == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                                    ? 
                                                   (((QData)((IData)(
                                                                     (0x1ffffU 
                                                                      & VL_NEGATE_I((IData)(
                                                                                (1U 
                                                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
                                                                                >> 0xfU))))))) 
                                                     << 0x10U) 
                                                    | (QData)((IData)(
                                                                      (0xffffU 
                                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift))))
                                                    : (QData)((IData)(vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data))))))
                                       : (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu)))))),33);
        vcdp->chgBit(c+545,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid));
        vcdp->chgBit(c+553,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall));
        vcdp->chgBit(c+561,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak));
        vcdp->chgBit(c+569,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret));
        vcdp->chgBit(c+577,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__csrValid));
        vcdp->chgBit(c+585,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen));
        vcdp->chgBus(c+593,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata),32);
        vcdp->chgBit(c+601,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid));
        vcdp->chgBit(c+609,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid));
        vcdp->chgBit(c+617,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid));
        vcdp->chgBit(c+625,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet));
        vcdp->chgBit(c+633,(((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
                               & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall))) 
                              & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))) 
                             & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                >> 7U))))));
        vcdp->chgBit(c+641,((1U & (((1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                                           >> 0x1fU)) 
                                    == (1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B 
                                              >> 0x1fU)))
                                    ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                       >> 0x1fU) : 
                                   ((2U & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                     ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B 
                                        >> 0x1fU) : 
                                    (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                                     >> 0x1fU))))));
        vcdp->chgBus(c+649,((0x1fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)),5);
        vcdp->chgBus(c+657,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin),32);
        vcdp->chgBus(c+665,((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5)),32);
        vcdp->chgBus(c+673,(((0x55555555U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 
                                             >> 1U)) 
                             | (0xaaaaaaaaU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 
                                               << 1U)))),32);
        vcdp->chgBus(c+681,(((0xffff0000U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A) 
                             | (0xffffU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B))),32);
        vcdp->chgBus(c+689,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm),21);
        vcdp->chgBus(c+697,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff),32);
        vcdp->chgBit(c+705,((0U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff)));
        vcdp->chgBit(c+713,((1U & (~ (IData)((0U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff))))));
        vcdp->chgBit(c+721,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign));
        vcdp->chgBit(c+729,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt));
        vcdp->chgBit(c+737,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu));
        vcdp->chgBit(c+745,((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt)))));
        vcdp->chgBit(c+753,((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu)))));
        vcdp->chgBus(c+761,(vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_data),20);
        vcdp->chgBit(c+769,(vlTOPp->Tile__DOT__icache__DOT__hit));
        vcdp->chgArray(c+777,(vlTOPp->Tile__DOT__icache__DOT__rdata),128);
        vcdp->chgArray(c+809,(vlTOPp->Tile__DOT__icache__DOT__read),128);
        vcdp->chgBit(c+841,(vlTOPp->Tile__DOT__icache__DOT__is_dirty));
        vcdp->chgBus(c+849,(vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data),20);
        vcdp->chgBit(c+857,(vlTOPp->Tile__DOT__dcache__DOT__hit));
        vcdp->chgArray(c+865,(vlTOPp->Tile__DOT__dcache__DOT__rdata),128);
        vcdp->chgArray(c+897,(vlTOPp->Tile__DOT__dcache__DOT__read),128);
        vcdp->chgBit(c+929,(vlTOPp->Tile__DOT__dcache__DOT__is_dirty));
    }
}

void VTile::traceChgThis__3(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        vcdp->chgBit(c+937,(((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
                             | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc))));
        vcdp->chgBit(c+945,(((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
                             | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc))));
        vcdp->chgBit(c+953,(((IData)(vlTOPp->Tile__DOT__dcache__DOT___T_1) 
                             & (IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count))));
    }
}

void VTile::traceChgThis__4(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        vcdp->chgBit(c+961,(vlTOPp->Tile__DOT__arb_io_icache_ar_ready));
        vcdp->chgBit(c+969,(vlTOPp->Tile__DOT__arb_io_dcache_aw_ready));
        vcdp->chgBit(c+977,(vlTOPp->Tile__DOT__arb_io_dcache_w_ready));
        vcdp->chgBit(c+985,(vlTOPp->Tile__DOT__dcache_io_nasti_w_bits_last));
        vcdp->chgBit(c+993,(vlTOPp->Tile__DOT__arb_io_dcache_ar_ready));
        vcdp->chgBit(c+1001,(((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
                              & (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc))));
        vcdp->chgBus(c+1009,((0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[0U])),8);
        vcdp->chgBit(c+1017,((1U & vlTOPp->Tile__DOT__icache__DOT__wmask)));
        vcdp->chgBus(c+1025,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1033,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 1U))));
        vcdp->chgBus(c+1041,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1049,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 2U))));
        vcdp->chgBus(c+1057,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1065,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 3U))));
        vcdp->chgBus(c+1073,((0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[1U])),8);
        vcdp->chgBit(c+1081,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 4U))));
        vcdp->chgBus(c+1089,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1097,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 5U))));
        vcdp->chgBus(c+1105,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1113,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 6U))));
        vcdp->chgBus(c+1121,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1129,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 7U))));
        vcdp->chgBus(c+1137,((0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[2U])),8);
        vcdp->chgBit(c+1145,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 8U))));
        vcdp->chgBus(c+1153,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1161,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 9U))));
        vcdp->chgBus(c+1169,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1177,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 0xaU))));
        vcdp->chgBus(c+1185,((0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                        << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1193,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 0xbU))));
        vcdp->chgBus(c+1201,((0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[3U])),8);
        vcdp->chgBit(c+1209,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 0xcU))));
        vcdp->chgBus(c+1217,((0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                       >> 8U))),8);
        vcdp->chgBit(c+1225,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 0xdU))));
        vcdp->chgBus(c+1233,((0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                       >> 0x10U))),8);
        vcdp->chgBit(c+1241,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 0xeU))));
        vcdp->chgBus(c+1249,((0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                                       >> 0x18U))),8);
        vcdp->chgBit(c+1257,((1U & (vlTOPp->Tile__DOT__icache__DOT__wmask 
                                    >> 0xfU))));
        vcdp->chgBit(c+1265,(vlTOPp->Tile__DOT__icache__DOT__read_wrap_out));
        vcdp->chgBit(c+1273,(vlTOPp->Tile__DOT__icache__DOT__is_alloc));
        vcdp->chgBit(c+1281,(vlTOPp->Tile__DOT__icache__DOT__wen));
        vcdp->chgBus(c+1289,(vlTOPp->Tile__DOT__icache__DOT__wmask),20);
        vcdp->chgArray(c+1297,(vlTOPp->Tile__DOT__icache__DOT__wdata),128);
        vcdp->chgBit(c+1329,(((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
                              & (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc))));
        vcdp->chgBus(c+1337,((0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[0U])),8);
        vcdp->chgBit(c+1345,((1U & vlTOPp->Tile__DOT__dcache__DOT__wmask)));
        vcdp->chgBus(c+1353,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1361,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 1U))));
        vcdp->chgBus(c+1369,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1377,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 2U))));
        vcdp->chgBus(c+1385,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1393,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 3U))));
        vcdp->chgBus(c+1401,((0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[1U])),8);
        vcdp->chgBit(c+1409,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 4U))));
        vcdp->chgBus(c+1417,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1425,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 5U))));
        vcdp->chgBus(c+1433,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1441,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 6U))));
        vcdp->chgBus(c+1449,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1457,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 7U))));
        vcdp->chgBus(c+1465,((0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[2U])),8);
        vcdp->chgBit(c+1473,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 8U))));
        vcdp->chgBus(c+1481,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                        << 0x18U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        >> 8U)))),8);
        vcdp->chgBit(c+1489,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 9U))));
        vcdp->chgBus(c+1497,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                        << 0x10U) | 
                                       (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                        >> 0x10U)))),8);
        vcdp->chgBit(c+1505,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 0xaU))));
        vcdp->chgBus(c+1513,((0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                        << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                                  >> 0x18U)))),8);
        vcdp->chgBit(c+1521,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 0xbU))));
        vcdp->chgBus(c+1529,((0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[3U])),8);
        vcdp->chgBit(c+1537,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 0xcU))));
        vcdp->chgBus(c+1545,((0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                       >> 8U))),8);
        vcdp->chgBit(c+1553,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 0xdU))));
        vcdp->chgBus(c+1561,((0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                       >> 0x10U))),8);
        vcdp->chgBit(c+1569,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 0xeU))));
        vcdp->chgBus(c+1577,((0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                                       >> 0x18U))),8);
        vcdp->chgBit(c+1585,((1U & (vlTOPp->Tile__DOT__dcache__DOT__wmask 
                                    >> 0xfU))));
        vcdp->chgBit(c+1593,(vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out));
        vcdp->chgBit(c+1601,(vlTOPp->Tile__DOT__dcache__DOT__is_alloc));
        vcdp->chgBit(c+1609,(vlTOPp->Tile__DOT__dcache__DOT__wen));
        vcdp->chgBus(c+1617,(vlTOPp->Tile__DOT__dcache__DOT__wmask),20);
        vcdp->chgArray(c+1625,(vlTOPp->Tile__DOT__dcache__DOT__wdata),128);
    }
}

void VTile::traceChgThis__5(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        vcdp->chgBus(c+1657,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost),32);
        vcdp->chgBit(c+1665,(((0U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                              & ((1U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                 & ((2U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                    & (3U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)))))));
        vcdp->chgBit(c+1673,(((0U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                              & ((1U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                 & ((2U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                    & ((3U != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                       & (4U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))))))));
        vcdp->chgBus(c+1681,((0xfffffff0U & vlTOPp->Tile__DOT__icache__DOT__addr_reg)),32);
        vcdp->chgBit(c+1689,((6U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
        vcdp->chgBus(c+1697,((0xfffffff0U & vlTOPp->Tile__DOT__dcache__DOT__addr_reg)),32);
        vcdp->chgBit(c+1705,((6U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
        vcdp->chgBus(c+1713,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst),32);
        vcdp->chgBus(c+1721,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd),3);
        vcdp->chgBus(c+1729,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in),32);
        vcdp->chgBus(c+1737,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc),32);
        vcdp->chgBus(c+1745,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu),32);
        vcdp->chgBus(c+1753,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst),32);
        vcdp->chgBit(c+1761,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__illegal));
        vcdp->chgBus(c+1769,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type),2);
        vcdp->chgBus(c+1777,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type),3);
        vcdp->chgBit(c+1785,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc_check));
        vcdp->chgBus(c+1793,(((IData)(0x100U) + ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                                 << 6U))),32);
        vcdp->chgBus(c+1801,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc),32);
        vcdp->chgBus(c+1809,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                       >> 0xfU))),5);
        vcdp->chgBus(c+1817,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                       >> 0x14U))),5);
        vcdp->chgBus(c+1825,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                       >> 7U))),5);
        vcdp->chgBus(c+1833,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc),32);
        vcdp->chgBus(c+1841,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel),2);
        vcdp->chgBit(c+1849,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en));
        vcdp->chgBit(c+1857,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__started));
        vcdp->chgQuad(c+1865,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc),33);
        vcdp->chgBus(c+1881,(((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                                        << 3U)) | (8U 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                                                      << 3U)))),8);
        vcdp->chgBus(c+1889,((0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                        >> 0x14U))),12);
        vcdp->chgBus(c+1897,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                       >> 0xfU))),5);
        vcdp->chgBus(c+1905,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_),32);
        vcdp->chgBus(c+1913,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh),32);
        vcdp->chgBus(c+1921,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle),32);
        vcdp->chgBus(c+1929,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh),32);
        vcdp->chgBus(c+1937,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret),32);
        vcdp->chgBus(c+1945,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth),32);
        vcdp->chgBus(c+1953,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV),2);
        vcdp->chgBus(c+1961,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1),2);
        vcdp->chgBit(c+1969,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE));
        vcdp->chgBit(c+1977,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1));
        vcdp->chgBus(c+1985,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1) 
                               << 4U) | (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1) 
                                          << 3U) | 
                                         (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                           << 1U) | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE))))),32);
        vcdp->chgBit(c+1993,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP));
        vcdp->chgBit(c+2001,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE));
        vcdp->chgBit(c+2009,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP));
        vcdp->chgBit(c+2017,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE));
        vcdp->chgBus(c+2025,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP) 
                               << 7U) | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP) 
                                         << 3U))),32);
        vcdp->chgBus(c+2033,((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE) 
                               << 7U) | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE) 
                                         << 3U))),32);
        vcdp->chgBus(c+2041,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp),32);
        vcdp->chgBus(c+2049,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch),32);
        vcdp->chgBus(c+2057,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause),32);
        vcdp->chgBus(c+2065,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr),32);
        vcdp->chgBus(c+2073,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost),32);
        vcdp->chgBit(c+2081,((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))));
        vcdp->chgBit(c+2089,((((3U == (3U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x1eU))) 
                               | (0x301U == (0xfffU 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                >> 0x14U)))) 
                              | (0x302U == (0xfffU 
                                            & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U))))));
        vcdp->chgBus(c+2097,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[0]),32);
        vcdp->chgBus(c+2098,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[1]),32);
        vcdp->chgBus(c+2099,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[2]),32);
        vcdp->chgBus(c+2100,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[3]),32);
        vcdp->chgBus(c+2101,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[4]),32);
        vcdp->chgBus(c+2102,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[5]),32);
        vcdp->chgBus(c+2103,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[6]),32);
        vcdp->chgBus(c+2104,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[7]),32);
        vcdp->chgBus(c+2105,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[8]),32);
        vcdp->chgBus(c+2106,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[9]),32);
        vcdp->chgBus(c+2107,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[10]),32);
        vcdp->chgBus(c+2108,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[11]),32);
        vcdp->chgBus(c+2109,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[12]),32);
        vcdp->chgBus(c+2110,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[13]),32);
        vcdp->chgBus(c+2111,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[14]),32);
        vcdp->chgBus(c+2112,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[15]),32);
        vcdp->chgBus(c+2113,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[16]),32);
        vcdp->chgBus(c+2114,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[17]),32);
        vcdp->chgBus(c+2115,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[18]),32);
        vcdp->chgBus(c+2116,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[19]),32);
        vcdp->chgBus(c+2117,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[20]),32);
        vcdp->chgBus(c+2118,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[21]),32);
        vcdp->chgBus(c+2119,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[22]),32);
        vcdp->chgBus(c+2120,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[23]),32);
        vcdp->chgBus(c+2121,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[24]),32);
        vcdp->chgBus(c+2122,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[25]),32);
        vcdp->chgBus(c+2123,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[26]),32);
        vcdp->chgBus(c+2124,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[27]),32);
        vcdp->chgBus(c+2125,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[28]),32);
        vcdp->chgBus(c+2126,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[29]),32);
        vcdp->chgBus(c+2127,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[30]),32);
        vcdp->chgBus(c+2128,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[31]),32);
        vcdp->chgBus(c+2353,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
                             [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                        >> 0xfU))]),32);
        vcdp->chgBus(c+2361,(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
                             [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                        >> 0x14U))]),32);
        vcdp->chgBus(c+2369,((0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                        >> 0x14U))),12);
        vcdp->chgBus(c+2377,(((0xfe0U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                         >> 0x14U)) 
                              | (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                          >> 7U)))),12);
        vcdp->chgBus(c+2385,(((0x1000U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                          >> 0x13U)) 
                              | ((0x800U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                            << 4U)) 
                                 | ((0x7e0U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                               >> 0x14U)) 
                                    | (0x1eU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                >> 7U)))))),13);
        vcdp->chgBus(c+2393,((0xfffff000U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)),32);
        vcdp->chgBus(c+2401,((0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                       >> 0xfU))),6);
        vcdp->chgBit(c+2409,(vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_en_pipe_0));
        vcdp->chgBus(c+2417,(vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_addr_pipe_0),8);
        vcdp->chgBus(c+2425,((0xfffffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                          >> 0xcU))),20);
        vcdp->chgBus(c+2433,((0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                       >> 4U))),8);
        vcdp->chgBit(c+2441,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_0_rdata_MPORT_en_pipe_0));
        vcdp->chgBus(c+2449,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0),8);
        vcdp->chgBus(c+2457,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_0
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2465,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_1_rdata_MPORT_en_pipe_0));
        vcdp->chgBus(c+2473,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_1
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2481,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_2_rdata_MPORT_en_pipe_0));
        vcdp->chgBus(c+2489,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_2
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2497,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_3_rdata_MPORT_en_pipe_0));
        vcdp->chgBus(c+2505,(vlTOPp->Tile__DOT__icache__DOT__dataMem_0_3
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2513,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_0_rdata_MPORT_1_en_pipe_0));
        vcdp->chgBus(c+2521,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_0
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2529,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_1_rdata_MPORT_1_en_pipe_0));
        vcdp->chgBus(c+2537,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_1
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2545,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_2_rdata_MPORT_1_en_pipe_0));
        vcdp->chgBus(c+2553,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_2
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2561,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_en_pipe_0));
        vcdp->chgBus(c+2569,(vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2577,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0_rdata_MPORT_2_en_pipe_0));
        vcdp->chgBus(c+2585,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2593,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1_rdata_MPORT_2_en_pipe_0));
        vcdp->chgBus(c+2601,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2609,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2_rdata_MPORT_2_en_pipe_0));
        vcdp->chgBus(c+2617,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2625,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3_rdata_MPORT_2_en_pipe_0));
        vcdp->chgBus(c+2633,(vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2641,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0_rdata_MPORT_3_en_pipe_0));
        vcdp->chgBus(c+2649,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2657,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1_rdata_MPORT_3_en_pipe_0));
        vcdp->chgBus(c+2665,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2673,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2_rdata_MPORT_3_en_pipe_0));
        vcdp->chgBus(c+2681,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBit(c+2689,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3_rdata_MPORT_3_en_pipe_0));
        vcdp->chgBus(c+2697,(vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3
                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]),8);
        vcdp->chgBus(c+2705,(vlTOPp->Tile__DOT__icache__DOT__state),3);
        vcdp->chgArray(c+2713,(vlTOPp->Tile__DOT__icache__DOT__v),256);
        vcdp->chgArray(c+2777,(vlTOPp->Tile__DOT__icache__DOT__d),256);
        vcdp->chgBus(c+2841,(vlTOPp->Tile__DOT__icache__DOT__addr_reg),32);
        vcdp->chgBus(c+2849,(vlTOPp->Tile__DOT__icache__DOT__cpu_data),32);
        vcdp->chgBus(c+2857,(vlTOPp->Tile__DOT__icache__DOT__cpu_mask),4);
        vcdp->chgBit(c+2865,(vlTOPp->Tile__DOT__icache__DOT__read_count));
        vcdp->chgBit(c+2873,(vlTOPp->Tile__DOT__icache__DOT__write_count));
        vcdp->chgBit(c+2881,((0U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
        vcdp->chgBit(c+2889,((1U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
        vcdp->chgBit(c+2897,((2U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
        vcdp->chgBit(c+2905,(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg));
        vcdp->chgBit(c+2913,(vlTOPp->Tile__DOT__icache__DOT__ren_reg));
        vcdp->chgBus(c+2921,((3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                    >> 2U))),2);
        vcdp->chgQuad(c+2929,((((QData)((IData)(((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3
                                                  [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_2
                                                     [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_1
                                                        [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__icache__DOT__dataMem_1_0
                                                       [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]))))) 
                                << 0x20U) | (QData)((IData)(
                                                            ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_3
                                                              [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                              << 0x18U) 
                                                             | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_2
                                                                 [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                 << 0x10U) 
                                                                | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_1
                                                                    [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                    << 8U) 
                                                                   | vlTOPp->Tile__DOT__icache__DOT__dataMem_0_0
                                                                   [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]))))))),64);
        vcdp->chgArray(c+2945,(vlTOPp->Tile__DOT__icache__DOT__rdata_buf),128);
        vcdp->chgQuad(c+2977,(vlTOPp->Tile__DOT__icache__DOT__refill_buf_0),64);
        vcdp->chgQuad(c+2993,(vlTOPp->Tile__DOT__icache__DOT__refill_buf_1),64);
        vcdp->chgBit(c+3009,(vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_en_pipe_0));
        vcdp->chgBus(c+3017,(vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0),8);
        vcdp->chgBus(c+3025,((0xfffffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                          >> 0xcU))),20);
        vcdp->chgBus(c+3033,((0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                       >> 4U))),8);
        vcdp->chgBit(c+3041,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_0_rdata_MPORT_en_pipe_0));
        vcdp->chgBus(c+3049,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_0
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3057,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_1_rdata_MPORT_en_pipe_0));
        vcdp->chgBus(c+3065,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_1
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3073,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_2_rdata_MPORT_en_pipe_0));
        vcdp->chgBus(c+3081,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_2
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3089,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_3_rdata_MPORT_en_pipe_0));
        vcdp->chgBus(c+3097,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_3
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3105,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_0_rdata_MPORT_1_en_pipe_0));
        vcdp->chgBus(c+3113,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_0
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3121,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_1_rdata_MPORT_1_en_pipe_0));
        vcdp->chgBus(c+3129,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_1
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3137,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_2_rdata_MPORT_1_en_pipe_0));
        vcdp->chgBus(c+3145,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_2
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3153,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_3_rdata_MPORT_1_en_pipe_0));
        vcdp->chgBus(c+3161,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_3
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3169,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0_rdata_MPORT_2_en_pipe_0));
        vcdp->chgBus(c+3177,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3185,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1_rdata_MPORT_2_en_pipe_0));
        vcdp->chgBus(c+3193,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3201,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2_rdata_MPORT_2_en_pipe_0));
        vcdp->chgBus(c+3209,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3217,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3_rdata_MPORT_2_en_pipe_0));
        vcdp->chgBus(c+3225,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3233,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0_rdata_MPORT_3_en_pipe_0));
        vcdp->chgBus(c+3241,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3249,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1_rdata_MPORT_3_en_pipe_0));
        vcdp->chgBus(c+3257,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3265,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2_rdata_MPORT_3_en_pipe_0));
        vcdp->chgBus(c+3273,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBit(c+3281,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3_rdata_MPORT_3_en_pipe_0));
        vcdp->chgBus(c+3289,(vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3
                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]),8);
        vcdp->chgBus(c+3297,(vlTOPp->Tile__DOT__dcache__DOT__state),3);
        vcdp->chgArray(c+3305,(vlTOPp->Tile__DOT__dcache__DOT__v),256);
        vcdp->chgArray(c+3369,(vlTOPp->Tile__DOT__dcache__DOT__d),256);
        vcdp->chgBus(c+3433,(vlTOPp->Tile__DOT__dcache__DOT__addr_reg),32);
        vcdp->chgBus(c+3441,(vlTOPp->Tile__DOT__dcache__DOT__cpu_data),32);
        vcdp->chgBus(c+3449,(vlTOPp->Tile__DOT__dcache__DOT__cpu_mask),4);
        vcdp->chgBit(c+3457,(vlTOPp->Tile__DOT__dcache__DOT__read_count));
        vcdp->chgBit(c+3465,(vlTOPp->Tile__DOT__dcache__DOT__write_count));
        vcdp->chgBit(c+3473,((0U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
        vcdp->chgBit(c+3481,((1U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
        vcdp->chgBit(c+3489,((2U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
        vcdp->chgBit(c+3497,(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg));
        vcdp->chgBit(c+3505,(vlTOPp->Tile__DOT__dcache__DOT__ren_reg));
        vcdp->chgBus(c+3513,((3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                    >> 2U))),2);
        vcdp->chgQuad(c+3521,((((QData)((IData)(((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_3
                                                  [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_2
                                                     [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_1
                                                        [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_0
                                                       [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]))))) 
                                << 0x20U) | (QData)((IData)(
                                                            ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_3
                                                              [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                              << 0x18U) 
                                                             | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_2
                                                                 [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                 << 0x10U) 
                                                                | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_1
                                                                    [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                    << 8U) 
                                                                   | vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_0
                                                                   [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]))))))),64);
        vcdp->chgArray(c+3537,(vlTOPp->Tile__DOT__dcache__DOT__rdata_buf),128);
        vcdp->chgQuad(c+3569,(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0),64);
        vcdp->chgQuad(c+3585,(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_1),64);
        vcdp->chgBus(c+3601,(vlTOPp->Tile__DOT__arb__DOT__state),3);
    }
}

void VTile::traceChgThis__6(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) {
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    int c = code;
    if (0 && vcdp && c) {}  // Prevent unused
    // Body
    {
        vcdp->chgBit(c+3609,(vlTOPp->clock));
        vcdp->chgBit(c+3617,(vlTOPp->reset));
        vcdp->chgBit(c+3625,(vlTOPp->io_host_fromhost_valid));
        vcdp->chgBus(c+3633,(vlTOPp->io_host_fromhost_bits),32);
        vcdp->chgBus(c+3641,(vlTOPp->io_host_tohost),32);
        vcdp->chgBit(c+3649,(vlTOPp->io_nasti_aw_ready));
        vcdp->chgBit(c+3657,(vlTOPp->io_nasti_aw_valid));
        vcdp->chgBus(c+3665,(vlTOPp->io_nasti_aw_bits_id),5);
        vcdp->chgBus(c+3673,(vlTOPp->io_nasti_aw_bits_addr),32);
        vcdp->chgBus(c+3681,(vlTOPp->io_nasti_aw_bits_len),8);
        vcdp->chgBus(c+3689,(vlTOPp->io_nasti_aw_bits_size),3);
        vcdp->chgBus(c+3697,(vlTOPp->io_nasti_aw_bits_burst),2);
        vcdp->chgBit(c+3705,(vlTOPp->io_nasti_aw_bits_lock));
        vcdp->chgBus(c+3713,(vlTOPp->io_nasti_aw_bits_cache),4);
        vcdp->chgBus(c+3721,(vlTOPp->io_nasti_aw_bits_prot),3);
        vcdp->chgBus(c+3729,(vlTOPp->io_nasti_aw_bits_qos),4);
        vcdp->chgBit(c+3737,(vlTOPp->io_nasti_w_ready));
        vcdp->chgBit(c+3745,(vlTOPp->io_nasti_w_valid));
        vcdp->chgQuad(c+3753,(vlTOPp->io_nasti_w_bits_data),64);
        vcdp->chgBus(c+3769,(vlTOPp->io_nasti_w_bits_strb),8);
        vcdp->chgBit(c+3777,(vlTOPp->io_nasti_w_bits_last));
        vcdp->chgBit(c+3785,(vlTOPp->io_nasti_b_ready));
        vcdp->chgBit(c+3793,(vlTOPp->io_nasti_b_valid));
        vcdp->chgBus(c+3801,(vlTOPp->io_nasti_b_bits_id),5);
        vcdp->chgBus(c+3809,(vlTOPp->io_nasti_b_bits_resp),2);
        vcdp->chgBit(c+3817,(vlTOPp->io_nasti_ar_ready));
        vcdp->chgBit(c+3825,(vlTOPp->io_nasti_ar_valid));
        vcdp->chgBus(c+3833,(vlTOPp->io_nasti_ar_bits_id),5);
        vcdp->chgBus(c+3841,(vlTOPp->io_nasti_ar_bits_addr),32);
        vcdp->chgBus(c+3849,(vlTOPp->io_nasti_ar_bits_len),8);
        vcdp->chgBus(c+3857,(vlTOPp->io_nasti_ar_bits_size),3);
        vcdp->chgBus(c+3865,(vlTOPp->io_nasti_ar_bits_burst),2);
        vcdp->chgBit(c+3873,(vlTOPp->io_nasti_ar_bits_lock));
        vcdp->chgBus(c+3881,(vlTOPp->io_nasti_ar_bits_cache),4);
        vcdp->chgBus(c+3889,(vlTOPp->io_nasti_ar_bits_prot),3);
        vcdp->chgBus(c+3897,(vlTOPp->io_nasti_ar_bits_qos),4);
        vcdp->chgBit(c+3905,(vlTOPp->io_nasti_r_ready));
        vcdp->chgBit(c+3913,(vlTOPp->io_nasti_r_valid));
        vcdp->chgBus(c+3921,(vlTOPp->io_nasti_r_bits_id),5);
        vcdp->chgQuad(c+3929,(vlTOPp->io_nasti_r_bits_data),64);
        vcdp->chgBus(c+3945,(vlTOPp->io_nasti_r_bits_resp),2);
        vcdp->chgBit(c+3953,(vlTOPp->io_nasti_r_bits_last));
        vcdp->chgBit(c+3961,(((IData)(vlTOPp->io_nasti_r_valid) 
                              & (1U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
        vcdp->chgBit(c+3969,(((IData)(vlTOPp->io_nasti_b_valid) 
                              & (4U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
        vcdp->chgBit(c+3977,(((IData)(vlTOPp->io_nasti_r_valid) 
                              & (2U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)))));
    }
}
