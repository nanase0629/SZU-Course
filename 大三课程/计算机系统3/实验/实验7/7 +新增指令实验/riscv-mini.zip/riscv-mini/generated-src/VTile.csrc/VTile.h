// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Primary design header
//
// This header should be included by all source files instantiating the design.
// The class here is then constructed to instantiate the design.
// See the Verilator manual for examples.

#ifndef _VTILE_H_
#define _VTILE_H_  // guard

#include "verilated.h"

//==========

class VTile__Syms;
class VTile_VerilatedVcd;


//----------

VL_MODULE(VTile) {
  public:
    
    // PORTS
    // The application code writes and reads these signals to
    // propagate new values into/out from the Verilated model.
    // Begin mtask footprint all: 
    VL_IN8(clock,0,0);
    VL_IN8(reset,0,0);
    VL_IN8(io_host_fromhost_valid,0,0);
    VL_IN8(io_nasti_aw_ready,0,0);
    VL_OUT8(io_nasti_aw_valid,0,0);
    VL_OUT8(io_nasti_aw_bits_id,4,0);
    VL_OUT8(io_nasti_aw_bits_len,7,0);
    VL_OUT8(io_nasti_aw_bits_size,2,0);
    VL_OUT8(io_nasti_aw_bits_burst,1,0);
    VL_OUT8(io_nasti_aw_bits_lock,0,0);
    VL_OUT8(io_nasti_aw_bits_cache,3,0);
    VL_OUT8(io_nasti_aw_bits_prot,2,0);
    VL_OUT8(io_nasti_aw_bits_qos,3,0);
    VL_IN8(io_nasti_w_ready,0,0);
    VL_OUT8(io_nasti_w_valid,0,0);
    VL_OUT8(io_nasti_w_bits_strb,7,0);
    VL_OUT8(io_nasti_w_bits_last,0,0);
    VL_OUT8(io_nasti_b_ready,0,0);
    VL_IN8(io_nasti_b_valid,0,0);
    VL_IN8(io_nasti_b_bits_id,4,0);
    VL_IN8(io_nasti_b_bits_resp,1,0);
    VL_IN8(io_nasti_ar_ready,0,0);
    VL_OUT8(io_nasti_ar_valid,0,0);
    VL_OUT8(io_nasti_ar_bits_id,4,0);
    VL_OUT8(io_nasti_ar_bits_len,7,0);
    VL_OUT8(io_nasti_ar_bits_size,2,0);
    VL_OUT8(io_nasti_ar_bits_burst,1,0);
    VL_OUT8(io_nasti_ar_bits_lock,0,0);
    VL_OUT8(io_nasti_ar_bits_cache,3,0);
    VL_OUT8(io_nasti_ar_bits_prot,2,0);
    VL_OUT8(io_nasti_ar_bits_qos,3,0);
    VL_OUT8(io_nasti_r_ready,0,0);
    VL_IN8(io_nasti_r_valid,0,0);
    VL_IN8(io_nasti_r_bits_id,4,0);
    VL_IN8(io_nasti_r_bits_resp,1,0);
    VL_IN8(io_nasti_r_bits_last,0,0);
    VL_IN(io_host_fromhost_bits,31,0);
    VL_OUT(io_host_tohost,31,0);
    VL_OUT(io_nasti_aw_bits_addr,31,0);
    VL_OUT(io_nasti_ar_bits_addr,31,0);
    VL_OUT64(io_nasti_w_bits_data,63,0);
    VL_IN64(io_nasti_r_bits_data,63,0);
    
    // LOCAL SIGNALS
    // Internals; generally not touched by application code
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        // Begin mtask footprint all: 
        CData/*0:0*/ Tile__DOT__icache_io_cpu_resp_valid;
        CData/*0:0*/ Tile__DOT__icache_io_nasti_ar_valid;
        CData/*0:0*/ Tile__DOT__dcache_io_cpu_resp_valid;
        CData/*0:0*/ Tile__DOT__dcache_io_nasti_aw_valid;
        CData/*0:0*/ Tile__DOT__dcache_io_nasti_w_valid;
        CData/*0:0*/ Tile__DOT__dcache_io_nasti_w_bits_last;
        CData/*0:0*/ Tile__DOT__dcache_io_nasti_b_ready;
        CData/*0:0*/ Tile__DOT__dcache_io_nasti_ar_valid;
        CData/*0:0*/ Tile__DOT__arb_io_icache_ar_ready;
        CData/*0:0*/ Tile__DOT__arb_io_dcache_aw_ready;
        CData/*0:0*/ Tile__DOT__arb_io_dcache_w_ready;
        CData/*0:0*/ Tile__DOT__arb_io_dcache_ar_ready;
        CData/*0:0*/ Tile__DOT__arb_io_nasti_aw_valid;
        CData/*0:0*/ Tile__DOT__arb_io_nasti_b_ready;
        CData/*0:0*/ Tile__DOT__arb_io_nasti_r_ready;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath_io_dcache_req_valid;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl_io_pc_sel;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl_io_inst_kill;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl_io_imm_sel;
        CData/*3:0*/ Tile__DOT__core__DOT__ctrl_io_alu_op;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl_io_br_type;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl_io_st_type;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl_io_ld_type;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr_io_stall;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr_io_expt;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond_io_taken;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__st_type;
        CData/*2:0*/ Tile__DOT__core__DOT__dpath__DOT__ld_type;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__wb_sel;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__wb_en;
        CData/*2:0*/ Tile__DOT__core__DOT__dpath__DOT__csr_cmd;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__illegal;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__pc_check;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__started;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__rs1hazard;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__rs2hazard;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T;
        CData/*4:0*/ Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T_10;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__csrValid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_176;
        CData/*1:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_178;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_179;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_180;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_181;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_182;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_183;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_200;
    };
    struct {
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt;
        CData/*0:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_117;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_132;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_147;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_156;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_189;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_223;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_240;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_266;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_281;
        CData/*3:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_311;
        CData/*3:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_326;
        CData/*3:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_341;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_414;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_434;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_489;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_558;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_573;
        CData/*1:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_588;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_622;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_656;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_671;
        CData/*2:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_686;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_706;
        CData/*0:0*/ Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_723;
        CData/*0:0*/ Tile__DOT__icache__DOT__metaMem_tag_rmeta_en_pipe_0;
        CData/*7:0*/ Tile__DOT__icache__DOT__metaMem_tag_rmeta_addr_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_0_0_rdata_MPORT_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_0_1_rdata_MPORT_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_0_2_rdata_MPORT_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_0_3_rdata_MPORT_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_1_0_rdata_MPORT_1_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_1_1_rdata_MPORT_1_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_1_2_rdata_MPORT_1_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_en_pipe_0;
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_2_0_rdata_MPORT_2_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_2_1_rdata_MPORT_2_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_2_2_rdata_MPORT_2_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_2_3_rdata_MPORT_2_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_3_0_rdata_MPORT_3_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_3_1_rdata_MPORT_3_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_3_2_rdata_MPORT_3_en_pipe_0;
        CData/*0:0*/ Tile__DOT__icache__DOT__dataMem_3_3_rdata_MPORT_3_en_pipe_0;
        CData/*2:0*/ Tile__DOT__icache__DOT__state;
        CData/*3:0*/ Tile__DOT__icache__DOT__cpu_mask;
        CData/*0:0*/ Tile__DOT__icache__DOT___T;
        CData/*0:0*/ Tile__DOT__icache__DOT__read_count;
        CData/*0:0*/ Tile__DOT__icache__DOT__read_wrap_out;
        CData/*0:0*/ Tile__DOT__icache__DOT__write_count;
        CData/*0:0*/ Tile__DOT__icache__DOT__is_alloc;
        CData/*0:0*/ Tile__DOT__icache__DOT__is_alloc_reg;
        CData/*0:0*/ Tile__DOT__icache__DOT__hit;
        CData/*0:0*/ Tile__DOT__icache__DOT___wen_T;
        CData/*0:0*/ Tile__DOT__icache__DOT___wen_T_3;
        CData/*0:0*/ Tile__DOT__icache__DOT__wen;
        CData/*0:0*/ Tile__DOT__icache__DOT___ren_T_2;
        CData/*0:0*/ Tile__DOT__icache__DOT__ren_reg;
        CData/*0:0*/ Tile__DOT__icache__DOT__is_dirty;
        CData/*2:0*/ Tile__DOT__icache__DOT___GEN_107;
        CData/*2:0*/ Tile__DOT__icache__DOT___GEN_128;
        CData/*0:0*/ Tile__DOT__dcache__DOT__metaMem_tag_rmeta_en_pipe_0;
    };
    struct {
        CData/*7:0*/ Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_0_0_rdata_MPORT_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_0_1_rdata_MPORT_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_0_2_rdata_MPORT_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_0_3_rdata_MPORT_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_1_0_rdata_MPORT_1_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_1_1_rdata_MPORT_1_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_1_2_rdata_MPORT_1_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_1_3_rdata_MPORT_1_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_2_0_rdata_MPORT_2_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_2_1_rdata_MPORT_2_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_2_2_rdata_MPORT_2_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_2_3_rdata_MPORT_2_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_3_0_rdata_MPORT_3_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_3_1_rdata_MPORT_3_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_3_2_rdata_MPORT_3_en_pipe_0;
        CData/*0:0*/ Tile__DOT__dcache__DOT__dataMem_3_3_rdata_MPORT_3_en_pipe_0;
        CData/*2:0*/ Tile__DOT__dcache__DOT__state;
        CData/*3:0*/ Tile__DOT__dcache__DOT__cpu_mask;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T;
        CData/*0:0*/ Tile__DOT__dcache__DOT__read_count;
        CData/*0:0*/ Tile__DOT__dcache__DOT__read_wrap_out;
        CData/*0:0*/ Tile__DOT__dcache__DOT___T_1;
        CData/*0:0*/ Tile__DOT__dcache__DOT__write_count;
        CData/*0:0*/ Tile__DOT__dcache__DOT__is_alloc;
        CData/*0:0*/ Tile__DOT__dcache__DOT__is_alloc_reg;
        CData/*0:0*/ Tile__DOT__dcache__DOT__hit;
        CData/*0:0*/ Tile__DOT__dcache__DOT___wen_T;
        CData/*0:0*/ Tile__DOT__dcache__DOT___wen_T_3;
        CData/*0:0*/ Tile__DOT__dcache__DOT__wen;
        CData/*0:0*/ Tile__DOT__dcache__DOT___ren_T_2;
        CData/*0:0*/ Tile__DOT__dcache__DOT__ren_reg;
        CData/*0:0*/ Tile__DOT__dcache__DOT__is_dirty;
        CData/*2:0*/ Tile__DOT__dcache__DOT___GEN_107;
        CData/*2:0*/ Tile__DOT__dcache__DOT___GEN_108;
        CData/*2:0*/ Tile__DOT__dcache__DOT___GEN_128;
        CData/*2:0*/ Tile__DOT__arb__DOT__state;
        CData/*2:0*/ Tile__DOT__arb__DOT___GEN_0;
        CData/*2:0*/ Tile__DOT__arb__DOT___GEN_3;
        CData/*2:0*/ Tile__DOT__arb__DOT___GEN_8;
        SData/*11:0*/ Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_5;
        SData/*12:0*/ Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_7;
        IData/*31:0*/ Tile__DOT__dcache_io_cpu_resp_bits_data;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr_io_out;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata2;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu_io_A;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu_io_B;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu_io_sum;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__immGen_io_out;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__rs1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__rs2;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT___daddr_T;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__lshift;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh;
    };
    struct {
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_68;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_80;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___time_T_1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___cycle_T_1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_96;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_97;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_110;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_121;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_134;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_135;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_165;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_166;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_168;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_169;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_184;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_191;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_193;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___sum_T_3;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_9;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_19;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_29;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_39;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_8;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_18;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_28;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___out_T_25;
        IData/*20:0*/ Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff;
        IData/*19:0*/ Tile__DOT__icache__DOT__metaMem_tag_rmeta_data;
        WData/*255:0*/ Tile__DOT__icache__DOT__v[8];
        WData/*255:0*/ Tile__DOT__icache__DOT__d[8];
        IData/*31:0*/ Tile__DOT__icache__DOT__addr_reg;
        IData/*31:0*/ Tile__DOT__icache__DOT__cpu_data;
        WData/*255:0*/ Tile__DOT__icache__DOT___hit_T[8];
        WData/*127:0*/ Tile__DOT__icache__DOT__rdata[4];
        WData/*127:0*/ Tile__DOT__icache__DOT__rdata_buf[4];
        WData/*127:0*/ Tile__DOT__icache__DOT__read[4];
        IData/*19:0*/ Tile__DOT__icache__DOT__wmask;
        WData/*127:0*/ Tile__DOT__icache__DOT__wdata[4];
        WData/*255:0*/ Tile__DOT__icache__DOT___v_T_1[8];
        WData/*255:0*/ Tile__DOT__icache__DOT___d_T_2[8];
        WData/*255:0*/ Tile__DOT__icache__DOT___d_T_4[8];
        IData/*19:0*/ Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data;
        WData/*255:0*/ Tile__DOT__dcache__DOT__v[8];
        WData/*255:0*/ Tile__DOT__dcache__DOT__d[8];
        IData/*31:0*/ Tile__DOT__dcache__DOT__addr_reg;
        IData/*31:0*/ Tile__DOT__dcache__DOT__cpu_data;
    };
    struct {
        WData/*255:0*/ Tile__DOT__dcache__DOT___hit_T[8];
        WData/*127:0*/ Tile__DOT__dcache__DOT__rdata[4];
        WData/*127:0*/ Tile__DOT__dcache__DOT__rdata_buf[4];
        WData/*127:0*/ Tile__DOT__dcache__DOT__read[4];
        IData/*19:0*/ Tile__DOT__dcache__DOT__wmask;
        WData/*127:0*/ Tile__DOT__dcache__DOT__wdata[4];
        WData/*255:0*/ Tile__DOT__dcache__DOT___v_T_1[8];
        WData/*255:0*/ Tile__DOT__dcache__DOT___d_T_2[8];
        WData/*255:0*/ Tile__DOT__dcache__DOT___d_T_4[8];
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__pc;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT___next_pc_T_9;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__next_pc;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT___GEN_31;
        QData/*34:0*/ Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_239;
        QData/*32:0*/ Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5;
        QData/*63:0*/ Tile__DOT__icache__DOT__refill_buf_0;
        QData/*63:0*/ Tile__DOT__icache__DOT__refill_buf_1;
        QData/*63:0*/ Tile__DOT__dcache__DOT__refill_buf_0;
        QData/*63:0*/ Tile__DOT__dcache__DOT__refill_buf_1;
        IData/*31:0*/ Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[32];
        IData/*19:0*/ Tile__DOT__icache__DOT__metaMem_tag[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_0_0[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_0_1[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_0_2[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_0_3[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_0[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_1[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_2[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_1_3[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_2_0[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_2_1[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_2_2[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_2_3[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_3_0[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_3_1[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_3_2[256];
        CData/*7:0*/ Tile__DOT__icache__DOT__dataMem_3_3[256];
        IData/*19:0*/ Tile__DOT__dcache__DOT__metaMem_tag[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_0_0[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_0_1[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_0_2[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_0_3[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_1_0[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_1_1[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_1_2[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_1_3[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_2_0[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_2_1[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_2_2[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_2_3[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_3_0[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_3_1[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_3_2[256];
        CData/*7:0*/ Tile__DOT__dcache__DOT__dataMem_3_3[256];
    };
    
    // LOCAL VARIABLES
    // Internals; generally not touched by application code
    // Begin mtask footprint all: 
    CData/*0:0*/ __Vclklast__TOP__clock;
    IData/*31:0*/ __Vm_traceActivity;
    
    // INTERNAL VARIABLES
    // Internals; generally not touched by application code
    VTile__Syms* __VlSymsp;  // Symbol table
    
    // CONSTRUCTORS
  private:
    VL_UNCOPYABLE(VTile);  ///< Copying not allowed
  public:
    /// Construct the model; called by application code
    /// The special name  may be used to make a wrapper with a
    /// single model invisible with respect to DPI scope names.
    VTile(const char* name = "TOP");
    /// Destroy the model; called (often implicitly) by application code
    ~VTile();
    /// Trace signals in the model; called by application code
    void trace(VerilatedVcdC* tfp, int levels, int options = 0);
    
    // API METHODS
    /// Evaluate the model.  Application must call when inputs change.
    void eval();
    /// Simulation complete, run final blocks.  Application must call on completion.
    void final();
    
    // INTERNAL METHODS
  private:
    static void _eval_initial_loop(VTile__Syms* __restrict vlSymsp);
  public:
    void __Vconfigure(VTile__Syms* symsp, bool first);
  private:
    static QData _change_request(VTile__Syms* __restrict vlSymsp);
  public:
    static void _combo__TOP__4(VTile__Syms* __restrict vlSymsp);
  private:
    void _ctor_var_reset() VL_ATTR_COLD;
  public:
    static void _eval(VTile__Syms* __restrict vlSymsp);
  private:
#ifdef VL_DEBUG
    void _eval_debug_assertions();
#endif  // VL_DEBUG
  public:
    static void _eval_initial(VTile__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _eval_settle(VTile__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _initial__TOP__1(VTile__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void _sequent__TOP__2(VTile__Syms* __restrict vlSymsp);
    static void _settle__TOP__3(VTile__Syms* __restrict vlSymsp) VL_ATTR_COLD;
    static void traceChgThis(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__2(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__3(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__4(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__5(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceChgThis__6(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code);
    static void traceFullThis(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) VL_ATTR_COLD;
    static void traceFullThis__1(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) VL_ATTR_COLD;
    static void traceInitThis(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) VL_ATTR_COLD;
    static void traceInitThis__1(VTile__Syms* __restrict vlSymsp, VerilatedVcd* vcdp, uint32_t code) VL_ATTR_COLD;
    static void traceInit(VerilatedVcd* vcdp, void* userthis, uint32_t code);
    static void traceFull(VerilatedVcd* vcdp, void* userthis, uint32_t code);
    static void traceChg(VerilatedVcd* vcdp, void* userthis, uint32_t code);
} VL_ATTR_ALIGNED(VL_CACHE_LINE_BYTES);

//----------


#endif  // guard
