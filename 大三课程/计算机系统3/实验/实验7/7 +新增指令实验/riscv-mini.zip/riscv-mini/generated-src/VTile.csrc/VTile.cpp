// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTile.h for the primary calling header

#include "VTile.h"
#include "VTile__Syms.h"

//==========

VL_CTOR_IMP(VTile) {
    VTile__Syms* __restrict vlSymsp = __VlSymsp = new VTile__Syms(this, name());
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Reset internal values
    
    // Reset structure values
    _ctor_var_reset();
}

void VTile::__Vconfigure(VTile__Syms* vlSymsp, bool first) {
    if (0 && first) {}  // Prevent unused
    this->__VlSymsp = vlSymsp;
}

VTile::~VTile() {
    delete __VlSymsp; __VlSymsp=NULL;
}

void VTile::eval() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate VTile::eval\n"); );
    VTile__Syms* __restrict vlSymsp = this->__VlSymsp;  // Setup global symbol table
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
#ifdef VL_DEBUG
    // Debug assertions
    _eval_debug_assertions();
#endif  // VL_DEBUG
    // Initialize
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) _eval_initial_loop(vlSymsp);
    // MTask 0 start
    VL_DEBUG_IF(VL_DBG_MSGF("MTask0 starting\n"););
    Verilated::mtaskId(0);
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        VL_DEBUG_IF(VL_DBG_MSGF("+ Clock loop\n"););
        vlSymsp->__Vm_activity = true;
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/ubuntu20/Desktop/riscv-mini/generated-src/Tile.v", 3000, "",
                "Verilated model didn't converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
    Verilated::endOfThreadMTask(vlSymsp->__Vm_evalMsgQp);
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

void VTile::_eval_initial_loop(VTile__Syms* __restrict vlSymsp) {
    vlSymsp->__Vm_didInit = true;
    _eval_initial(vlSymsp);
    vlSymsp->__Vm_activity = true;
    // Evaluate till stable
    int __VclockLoop = 0;
    QData __Vchange = 1;
    do {
        _eval_settle(vlSymsp);
        _eval(vlSymsp);
        if (VL_UNLIKELY(++__VclockLoop > 100)) {
            // About to fail, so enable debug to see what's not settling.
            // Note you must run make with OPT=-DVL_DEBUG for debug prints.
            int __Vsaved_debug = Verilated::debug();
            Verilated::debug(1);
            __Vchange = _change_request(vlSymsp);
            Verilated::debug(__Vsaved_debug);
            VL_FATAL_MT("/home/ubuntu20/Desktop/riscv-mini/generated-src/Tile.v", 3000, "",
                "Verilated model didn't DC converge\n"
                "- See DIDNOTCONVERGE in the Verilator manual");
        } else {
            __Vchange = _change_request(vlSymsp);
        }
    } while (VL_UNLIKELY(__Vchange));
}

void VTile::_initial__TOP__1(VTile__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_initial__TOP__1\n"); );
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->io_nasti_aw_bits_id = 0U;
    vlTOPp->io_nasti_aw_bits_len = 1U;
    vlTOPp->io_nasti_aw_bits_size = 3U;
    vlTOPp->io_nasti_aw_bits_burst = 1U;
    vlTOPp->io_nasti_aw_bits_lock = 0U;
    vlTOPp->io_nasti_aw_bits_cache = 0U;
    vlTOPp->io_nasti_aw_bits_prot = 0U;
    vlTOPp->io_nasti_aw_bits_qos = 0U;
    vlTOPp->io_nasti_w_bits_strb = 0xffU;
    vlTOPp->io_nasti_ar_bits_id = 0U;
    vlTOPp->io_nasti_ar_bits_len = 1U;
    vlTOPp->io_nasti_ar_bits_size = 3U;
    vlTOPp->io_nasti_ar_bits_burst = 1U;
    vlTOPp->io_nasti_ar_bits_lock = 0U;
    vlTOPp->io_nasti_ar_bits_cache = 0U;
    vlTOPp->io_nasti_ar_bits_prot = 0U;
    vlTOPp->io_nasti_ar_bits_qos = 0U;
}

VL_INLINE_OPT void VTile::_sequent__TOP__2(VTile__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_sequent__TOP__2\n"); );
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    // Begin mtask footprint all: 
    CData/*1:0*/ __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1;
    CData/*0:0*/ __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE;
    CData/*4:0*/ __Vdlyvdim0__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_3__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_3__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_3__v0;
    CData/*2:0*/ __Vdly__Tile__DOT__icache__DOT__state;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_3__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_3__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_3__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_2__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_2__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_2__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_1__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_1__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_1__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_1__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_1__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_1__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_0__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_0__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_0__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__metaMem_tag__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__metaMem_tag__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_2__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_2__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_2__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_0__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_0__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_0__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_3__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_3__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_3__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_1__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_1__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_1__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_0__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_0__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_0__v0;
    CData/*0:0*/ __Vdly__Tile__DOT__icache__DOT__read_count;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_2__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_2__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_2__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_1__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_1__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_1__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_3__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_3__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_3__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_2__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_2__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_2__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_0__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_0__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_0__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_3__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_3__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_3__v0;
    CData/*2:0*/ __Vdly__Tile__DOT__dcache__DOT__state;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_3__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_3__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_3__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_2__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_2__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_2__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_1__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_1__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_1__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_1__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_1__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_1__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_0__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_0__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_0__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__metaMem_tag__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__metaMem_tag__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_2__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_2__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_2__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_0__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_0__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_0__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_3__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_3__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_3__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_1__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_1__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_1__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_0__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_0__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_0__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_2__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_2__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_2__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_1__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_1__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_1__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_3__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_3__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_3__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_2__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_2__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_2__v0;
    CData/*7:0*/ __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_0__v0;
    CData/*7:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_0__v0;
    CData/*0:0*/ __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_0__v0;
    CData/*0:0*/ __Vdly__Tile__DOT__dcache__DOT__read_count;
    CData/*0:0*/ __Vdly__Tile__DOT__dcache__DOT__write_count;
    IData/*31:0*/ __Vdlyvval__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0;
    IData/*19:0*/ __Vdlyvval__Tile__DOT__icache__DOT__metaMem_tag__v0;
    IData/*19:0*/ __Vdlyvval__Tile__DOT__dcache__DOT__metaMem_tag__v0;
    WData/*287:0*/ __Vtemp4[9];
    WData/*287:0*/ __Vtemp5[9];
    WData/*255:0*/ __Vtemp17[8];
    WData/*255:0*/ __Vtemp18[8];
    WData/*255:0*/ __Vtemp20[8];
    WData/*255:0*/ __Vtemp21[8];
    WData/*255:0*/ __Vtemp24[8];
    WData/*255:0*/ __Vtemp25[8];
    WData/*255:0*/ __Vtemp27[8];
    WData/*255:0*/ __Vtemp28[8];
    WData/*255:0*/ __Vtemp32[8];
    WData/*255:0*/ __Vtemp33[8];
    WData/*255:0*/ __Vtemp35[8];
    WData/*255:0*/ __Vtemp36[8];
    WData/*255:0*/ __Vtemp39[8];
    WData/*255:0*/ __Vtemp40[8];
    WData/*255:0*/ __Vtemp42[8];
    WData/*255:0*/ __Vtemp43[8];
    // Body
    __Vdly__Tile__DOT__dcache__DOT__write_count = vlTOPp->Tile__DOT__dcache__DOT__write_count;
    __Vdly__Tile__DOT__icache__DOT__read_count = vlTOPp->Tile__DOT__icache__DOT__read_count;
    __Vdly__Tile__DOT__dcache__DOT__read_count = vlTOPp->Tile__DOT__dcache__DOT__read_count;
    __Vdly__Tile__DOT__icache__DOT__state = vlTOPp->Tile__DOT__icache__DOT__state;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_0__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_2__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_3__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_1__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_2__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_0__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_1__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_3__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_0__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_2__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_0__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_1__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_1__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_2__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_3__v0 = 0U;
    __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_3__v0 = 0U;
    __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE 
        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE;
    __Vdly__Tile__DOT__dcache__DOT__state = vlTOPp->Tile__DOT__dcache__DOT__state;
    __Vdlyvset__Tile__DOT__icache__DOT__metaMem_tag__v0 = 0U;
    __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1 
        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_0__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_2__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_3__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_1__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_2__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_0__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_1__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_3__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_0__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_2__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_0__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_1__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_1__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_2__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_3__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_3__v0 = 0U;
    __Vdlyvset__Tile__DOT__dcache__DOT__metaMem_tag__v0 = 0U;
    __Vdlyvset__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0 = 0U;
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__icache__DOT__write_count = 0U;
    }
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_3_rdata_MPORT_1_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_2_rdata_MPORT_1_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_1_rdata_MPORT_1_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_3_rdata_MPORT_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0_rdata_MPORT_2_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1_rdata_MPORT_2_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2_rdata_MPORT_2_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3_rdata_MPORT_2_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0_rdata_MPORT_3_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1_rdata_MPORT_3_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_0_rdata_MPORT_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2_rdata_MPORT_3_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_1_rdata_MPORT_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3_rdata_MPORT_3_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_2_rdata_MPORT_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_0_rdata_MPORT_1_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
           & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    if (vlTOPp->reset) {
        __Vdly__Tile__DOT__dcache__DOT__write_count = 0U;
    } else {
        if (vlTOPp->Tile__DOT__dcache__DOT___T_1) {
            __Vdly__Tile__DOT__dcache__DOT__write_count 
                = (1U & ((IData)(1U) + (IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count)));
        }
    }
    vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_1_2_rdata_MPORT_1_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_1_1_rdata_MPORT_1_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_1_0_rdata_MPORT_1_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_0_3_rdata_MPORT_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0_rdata_MPORT_2_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1_rdata_MPORT_2_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2_rdata_MPORT_2_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3_rdata_MPORT_2_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0_rdata_MPORT_3_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1_rdata_MPORT_3_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_0_0_rdata_MPORT_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2_rdata_MPORT_3_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_0_1_rdata_MPORT_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3_rdata_MPORT_3_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__icache__DOT__dataMem_0_2_rdata_MPORT_en_pipe_0 
        = ((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    if (((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
         & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0 
            = (0xffU & (IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT__next_pc 
                                >> 4U)));
    }
    if (vlTOPp->Tile__DOT__icache_io_cpu_resp_valid) {
        vlTOPp->Tile__DOT__icache__DOT__cpu_data = 0U;
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__icache__DOT__d[0U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__d[1U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__d[2U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__d[3U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__d[4U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__d[5U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__d[6U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__d[7U] = 0U;
    } else {
        if (vlTOPp->Tile__DOT__icache__DOT__wen) {
            vlTOPp->Tile__DOT__icache__DOT__d[0U] = 
                ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__icache__DOT___d_T_4[0U])
                  : vlTOPp->Tile__DOT__icache__DOT___d_T_2[0U]);
            vlTOPp->Tile__DOT__icache__DOT__d[1U] = 
                ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__icache__DOT___d_T_4[1U])
                  : vlTOPp->Tile__DOT__icache__DOT___d_T_2[1U]);
            vlTOPp->Tile__DOT__icache__DOT__d[2U] = 
                ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__icache__DOT___d_T_4[2U])
                  : vlTOPp->Tile__DOT__icache__DOT___d_T_2[2U]);
            vlTOPp->Tile__DOT__icache__DOT__d[3U] = 
                ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__icache__DOT___d_T_4[3U])
                  : vlTOPp->Tile__DOT__icache__DOT___d_T_2[3U]);
            vlTOPp->Tile__DOT__icache__DOT__d[4U] = 
                ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__icache__DOT___d_T_4[4U])
                  : vlTOPp->Tile__DOT__icache__DOT___d_T_2[4U]);
            vlTOPp->Tile__DOT__icache__DOT__d[5U] = 
                ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__icache__DOT___d_T_4[5U])
                  : vlTOPp->Tile__DOT__icache__DOT___d_T_2[5U]);
            vlTOPp->Tile__DOT__icache__DOT__d[6U] = 
                ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__icache__DOT___d_T_4[6U])
                  : vlTOPp->Tile__DOT__icache__DOT___d_T_2[6U]);
            vlTOPp->Tile__DOT__icache__DOT__d[7U] = 
                ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__icache__DOT___d_T_4[7U])
                  : vlTOPp->Tile__DOT__icache__DOT___d_T_2[7U]);
        }
    }
    if (vlTOPp->reset) {
        __Vdly__Tile__DOT__icache__DOT__read_count = 0U;
    } else {
        if (vlTOPp->Tile__DOT__icache__DOT___T) {
            __Vdly__Tile__DOT__icache__DOT__read_count 
                = (1U & ((IData)(1U) + (IData)(vlTOPp->Tile__DOT__icache__DOT__read_count)));
        }
    }
    if (vlTOPp->Tile__DOT__icache__DOT___T) {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__icache__DOT__read_count)))) {
            vlTOPp->Tile__DOT__icache__DOT__refill_buf_0 
                = vlTOPp->io_nasti_r_bits_data;
        }
    }
    if (vlTOPp->Tile__DOT__icache__DOT___T) {
        if (vlTOPp->Tile__DOT__icache__DOT__read_count) {
            vlTOPp->Tile__DOT__icache__DOT__refill_buf_1 
                = vlTOPp->io_nasti_r_bits_data;
        }
    }
    if (vlTOPp->reset) {
        __Vdly__Tile__DOT__dcache__DOT__read_count = 0U;
    } else {
        if (vlTOPp->Tile__DOT__dcache__DOT___T) {
            __Vdly__Tile__DOT__dcache__DOT__read_count 
                = (1U & ((IData)(1U) + (IData)(vlTOPp->Tile__DOT__dcache__DOT__read_count)));
        }
    }
    if (vlTOPp->Tile__DOT__dcache__DOT___T) {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__read_count)))) {
            vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0 
                = vlTOPp->io_nasti_r_bits_data;
        }
    }
    if (vlTOPp->Tile__DOT__dcache__DOT___T) {
        if (vlTOPp->Tile__DOT__dcache__DOT__read_count) {
            vlTOPp->Tile__DOT__dcache__DOT__refill_buf_1 
                = vlTOPp->io_nasti_r_bits_data;
        }
    }
    if (vlTOPp->Tile__DOT__icache__DOT__ren_reg) {
        vlTOPp->Tile__DOT__icache__DOT__rdata_buf[0U] 
            = vlTOPp->Tile__DOT__icache__DOT__rdata[0U];
        vlTOPp->Tile__DOT__icache__DOT__rdata_buf[1U] 
            = vlTOPp->Tile__DOT__icache__DOT__rdata[1U];
        vlTOPp->Tile__DOT__icache__DOT__rdata_buf[2U] 
            = vlTOPp->Tile__DOT__icache__DOT__rdata[2U];
        vlTOPp->Tile__DOT__icache__DOT__rdata_buf[3U] 
            = vlTOPp->Tile__DOT__icache__DOT__rdata[3U];
    }
    if (vlTOPp->Tile__DOT__icache_io_cpu_resp_valid) {
        vlTOPp->Tile__DOT__icache__DOT__cpu_mask = 0U;
    }
    if (vlTOPp->Tile__DOT__dcache_io_cpu_resp_valid) {
        vlTOPp->Tile__DOT__dcache__DOT__cpu_mask = 
            (0xfU & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T_10));
    }
    if (vlTOPp->Tile__DOT__dcache__DOT__ren_reg) {
        vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[0U] 
            = vlTOPp->Tile__DOT__dcache__DOT__rdata[0U];
        vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[1U] 
            = vlTOPp->Tile__DOT__dcache__DOT__rdata[1U];
        vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[2U] 
            = vlTOPp->Tile__DOT__dcache__DOT__rdata[2U];
        vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[3U] 
            = vlTOPp->Tile__DOT__dcache__DOT__rdata[3U];
    }
    if (vlTOPp->Tile__DOT__dcache_io_cpu_resp_valid) {
        VL_EXTEND_WI(287,32, __Vtemp4, vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2);
        VL_SHIFTL_WWI(287,287,8, __Vtemp5, __Vtemp4, 
                      ((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                 << 3U)) | (8U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                                  << 3U))));
        vlTOPp->Tile__DOT__dcache__DOT__cpu_data = 
            __Vtemp5[0U];
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__dcache__DOT__d[0U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__d[1U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__d[2U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__d[3U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__d[4U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__d[5U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__d[6U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__d[7U] = 0U;
    } else {
        if (vlTOPp->Tile__DOT__dcache__DOT__wen) {
            vlTOPp->Tile__DOT__dcache__DOT__d[0U] = 
                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__dcache__DOT___d_T_4[0U])
                  : vlTOPp->Tile__DOT__dcache__DOT___d_T_2[0U]);
            vlTOPp->Tile__DOT__dcache__DOT__d[1U] = 
                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__dcache__DOT___d_T_4[1U])
                  : vlTOPp->Tile__DOT__dcache__DOT___d_T_2[1U]);
            vlTOPp->Tile__DOT__dcache__DOT__d[2U] = 
                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__dcache__DOT___d_T_4[2U])
                  : vlTOPp->Tile__DOT__dcache__DOT___d_T_2[2U]);
            vlTOPp->Tile__DOT__dcache__DOT__d[3U] = 
                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__dcache__DOT___d_T_4[3U])
                  : vlTOPp->Tile__DOT__dcache__DOT___d_T_2[3U]);
            vlTOPp->Tile__DOT__dcache__DOT__d[4U] = 
                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__dcache__DOT___d_T_4[4U])
                  : vlTOPp->Tile__DOT__dcache__DOT___d_T_2[4U]);
            vlTOPp->Tile__DOT__dcache__DOT__d[5U] = 
                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__dcache__DOT___d_T_4[5U])
                  : vlTOPp->Tile__DOT__dcache__DOT___d_T_2[5U]);
            vlTOPp->Tile__DOT__dcache__DOT__d[6U] = 
                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__dcache__DOT___d_T_4[6U])
                  : vlTOPp->Tile__DOT__dcache__DOT___d_T_2[6U]);
            vlTOPp->Tile__DOT__dcache__DOT__d[7U] = 
                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                  ? (~ vlTOPp->Tile__DOT__dcache__DOT___d_T_4[7U])
                  : vlTOPp->Tile__DOT__dcache__DOT___d_T_2[7U]);
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE = 0U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
                if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_182;
                }
            }
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE = 0U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
                if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_183;
                }
            }
        }
    }
    if (vlTOPp->reset) {
        __Vdly__Tile__DOT__icache__DOT__state = 0U;
    } else {
        if ((0U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))) {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
                __Vdly__Tile__DOT__icache__DOT__state = 1U;
            }
        } else {
            __Vdly__Tile__DOT__icache__DOT__state = 
                ((1U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                  ? ((IData)(vlTOPp->Tile__DOT__icache__DOT__hit)
                      ? ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                          ? 0U : 1U) : (IData)(vlTOPp->Tile__DOT__icache__DOT___GEN_107))
                  : ((2U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                      ? ((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T)
                          ? 0U : (IData)(vlTOPp->Tile__DOT__icache__DOT___GEN_107))
                      : (IData)(vlTOPp->Tile__DOT__icache__DOT___GEN_128)));
        }
    }
    vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg = 
        ((6U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
         & (IData)(vlTOPp->Tile__DOT__icache__DOT__read_wrap_out));
    vlTOPp->Tile__DOT__arb__DOT__state = ((IData)(vlTOPp->reset)
                                           ? 0U : (
                                                   (0U 
                                                    == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                                    ? 
                                                   (((IData)(vlTOPp->Tile__DOT__arb_io_dcache_aw_ready) 
                                                     & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_aw_valid))
                                                     ? 3U
                                                     : 
                                                    (((IData)(vlTOPp->Tile__DOT__arb_io_dcache_ar_ready) 
                                                      & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid))
                                                      ? 2U
                                                      : (IData)(vlTOPp->Tile__DOT__arb__DOT___GEN_0)))
                                                    : 
                                                   ((1U 
                                                     == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                                     ? (IData)(vlTOPp->Tile__DOT__arb__DOT___GEN_3)
                                                     : 
                                                    ((2U 
                                                      == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                                      ? (IData)(vlTOPp->Tile__DOT__arb__DOT___GEN_3)
                                                      : (IData)(vlTOPp->Tile__DOT__arb__DOT___GEN_8)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle 
        = ((IData)(vlTOPp->reset) ? 0U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                                           ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___cycle_T_1
                                           : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                                               ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___cycle_T_1
                                               : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                                                   ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___cycle_T_1
                                                   : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_193))));
    if (((IData)(vlTOPp->Tile__DOT__icache__DOT___ren_T_2) 
         & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
        vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_addr_pipe_0 
            = (0xffU & (IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT__next_pc 
                                >> 4U)));
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__icache__DOT__v[0U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__v[1U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__v[2U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__v[3U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__v[4U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__v[5U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__v[6U] = 0U;
        vlTOPp->Tile__DOT__icache__DOT__v[7U] = 0U;
    } else {
        if (vlTOPp->Tile__DOT__icache__DOT__wen) {
            vlTOPp->Tile__DOT__icache__DOT__v[0U] = 
                vlTOPp->Tile__DOT__icache__DOT___v_T_1[0U];
            vlTOPp->Tile__DOT__icache__DOT__v[1U] = 
                vlTOPp->Tile__DOT__icache__DOT___v_T_1[1U];
            vlTOPp->Tile__DOT__icache__DOT__v[2U] = 
                vlTOPp->Tile__DOT__icache__DOT___v_T_1[2U];
            vlTOPp->Tile__DOT__icache__DOT__v[3U] = 
                vlTOPp->Tile__DOT__icache__DOT___v_T_1[3U];
            vlTOPp->Tile__DOT__icache__DOT__v[4U] = 
                vlTOPp->Tile__DOT__icache__DOT___v_T_1[4U];
            vlTOPp->Tile__DOT__icache__DOT__v[5U] = 
                vlTOPp->Tile__DOT__icache__DOT___v_T_1[5U];
            vlTOPp->Tile__DOT__icache__DOT__v[6U] = 
                vlTOPp->Tile__DOT__icache__DOT___v_T_1[6U];
            vlTOPp->Tile__DOT__icache__DOT__v[7U] = 
                vlTOPp->Tile__DOT__icache__DOT___v_T_1[7U];
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP = 0U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
                if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_180;
                }
            }
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP = 0U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
                if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_181;
                }
            }
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost = 0U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
                if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_191;
                }
            }
        }
    }
    if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                if (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_165;
                }
            }
        }
    }
    if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                if (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_166;
                }
            }
        }
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 8U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_0__v0 
            = (0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[2U]);
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_0__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_0__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 0xeU))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                        >> 0x10U));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_2__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 7U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_3__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                         << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                   >> 0x18U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_3__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 0xdU))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                        >> 8U));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_1__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 6U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_2__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                         << 0x10U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                      >> 0x10U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_2__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 0xcU))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_0__v0 
            = (0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[3U]);
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_0__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_0__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 5U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_1__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                         << 0x18U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                                      >> 8U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_1__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 0xbU))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_3__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                         << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                   >> 0x18U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_3__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 4U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_0__v0 
            = (0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[1U]);
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_0__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_0__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 0xaU))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_2__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                         << 0x10U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                      >> 0x10U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_2__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & vlTOPp->Tile__DOT__icache__DOT__wmask)) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_0__v0 
            = (0xffU & vlTOPp->Tile__DOT__icache__DOT__wdata[0U]);
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_0__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_0__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 1U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_1__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                         << 0x18U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                      >> 8U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_1__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 9U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_1__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                         << 0x18U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[2U] 
                                      >> 8U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_1__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 2U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_2__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                         << 0x10U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                      >> 0x10U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_2__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 3U))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_3__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__icache__DOT__wdata[1U] 
                         << 8U) | (vlTOPp->Tile__DOT__icache__DOT__wdata[0U] 
                                   >> 0x18U)));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_3__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__icache__DOT__wmask >> 0xfU))) {
        __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__wdata[3U] 
                        >> 0x18U));
        __Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_3__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_ 
        = ((IData)(vlTOPp->reset) ? 0U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                                           ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___time_T_1
                                           : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                                               ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___time_T_1
                                               : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                                                   ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___time_T_1
                                                   : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_184))));
    if (((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc_check = 0U;
    } else {
        if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                   & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc_check 
                = (1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel));
        }
    }
    if (((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type = 0U;
    } else {
        if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                   & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type 
                = vlTOPp->Tile__DOT__core__DOT__ctrl_io_st_type;
        }
    }
    if (vlTOPp->reset) {
        __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE = 0U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE 
                = ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)) 
                   & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                       ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1)
                       : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_179)));
        }
    }
    if (vlTOPp->reset) {
        __Vdly__Tile__DOT__dcache__DOT__state = 0U;
    } else {
        if ((0U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))) {
            if (vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid) {
                __Vdly__Tile__DOT__dcache__DOT__state 
                    = ((0U != (0xfU & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T_10)))
                        ? 2U : 1U);
            }
        } else {
            __Vdly__Tile__DOT__dcache__DOT__state = 
                ((1U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                  ? ((IData)(vlTOPp->Tile__DOT__dcache__DOT__hit)
                      ? ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid)
                          ? ((0U != (0xfU & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T_10)))
                              ? 2U : 1U) : 0U) : (IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_108))
                  : ((2U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                      ? (((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T) 
                          | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))
                          ? 0U : (IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_108))
                      : (IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_128)));
        }
    }
    vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg = 
        ((6U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
         & (IData)(vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out));
    if (((IData)(vlTOPp->Tile__DOT__icache__DOT__wen) 
         & (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc))) {
        __Vdlyvval__Tile__DOT__icache__DOT__metaMem_tag__v0 
            = (0xfffffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                           >> 0xcU));
        __Vdlyvset__Tile__DOT__icache__DOT__metaMem_tag__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__icache__DOT__metaMem_tag__v0 
            = (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                        >> 4U));
    }
    if (vlTOPp->reset) {
        __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1 = 3U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1 
                = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                    ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV)
                    : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                        ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_176)));
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc = VL_ULL(0x1fc);
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc 
                = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                    ? (QData)((IData)(((IData)(0x100U) 
                                       + ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                          << 6U))))
                    : ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel))
                        ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT___next_pc_T_9));
        }
    }
    if (((IData)(vlTOPp->Tile__DOT__dcache__DOT___ren_T_2) 
         & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid))) {
        vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0 
            = (0xffU & (IData)((VL_ULL(0xfffffffffffffff) 
                                & ((QData)((IData)(
                                                   (0x3fffffffU 
                                                    & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___daddr_T 
                                                       >> 2U)))) 
                                   >> 2U))));
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__dcache__DOT__v[0U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__v[1U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__v[2U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__v[3U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__v[4U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__v[5U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__v[6U] = 0U;
        vlTOPp->Tile__DOT__dcache__DOT__v[7U] = 0U;
    } else {
        if (vlTOPp->Tile__DOT__dcache__DOT__wen) {
            vlTOPp->Tile__DOT__dcache__DOT__v[0U] = 
                vlTOPp->Tile__DOT__dcache__DOT___v_T_1[0U];
            vlTOPp->Tile__DOT__dcache__DOT__v[1U] = 
                vlTOPp->Tile__DOT__dcache__DOT___v_T_1[1U];
            vlTOPp->Tile__DOT__dcache__DOT__v[2U] = 
                vlTOPp->Tile__DOT__dcache__DOT___v_T_1[2U];
            vlTOPp->Tile__DOT__dcache__DOT__v[3U] = 
                vlTOPp->Tile__DOT__dcache__DOT___v_T_1[3U];
            vlTOPp->Tile__DOT__dcache__DOT__v[4U] = 
                vlTOPp->Tile__DOT__dcache__DOT___v_T_1[4U];
            vlTOPp->Tile__DOT__dcache__DOT__v[5U] = 
                vlTOPp->Tile__DOT__dcache__DOT___v_T_1[5U];
            vlTOPp->Tile__DOT__dcache__DOT__v[6U] = 
                vlTOPp->Tile__DOT__dcache__DOT___v_T_1[6U];
            vlTOPp->Tile__DOT__dcache__DOT__v[7U] = 
                vlTOPp->Tile__DOT__dcache__DOT___v_T_1[7U];
        }
    }
    if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
        if (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause 
                = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid)
                    ? 0U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid)
                             ? 4U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid)
                                      ? 6U : (0xfU 
                                              & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall)
                                                  ? 
                                                 ((IData)(8U) 
                                                  + (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV))
                                                  : 
                                                 ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak)
                                                   ? 3U
                                                   : 2U))))));
        } else {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                if (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_168;
                }
            }
        }
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 8U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_0__v0 
            = (0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[2U]);
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_0__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_0__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 0xeU))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                        >> 0x10U));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_2__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 7U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_3__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                         << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                   >> 0x18U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_3__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 0xdU))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                        >> 8U));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_1__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 6U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_2__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                         << 0x10U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                      >> 0x10U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_2__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 0xcU))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_0__v0 
            = (0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[3U]);
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_0__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_0__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 5U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_1__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                         << 0x18U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                                      >> 8U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_1__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 0xbU))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_3__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                         << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                   >> 0x18U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_3__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 4U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_0__v0 
            = (0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[1U]);
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_0__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_0__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 0xaU))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_2__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                         << 0x10U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                      >> 0x10U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_2__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & vlTOPp->Tile__DOT__dcache__DOT__wmask)) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_0__v0 
            = (0xffU & vlTOPp->Tile__DOT__dcache__DOT__wdata[0U]);
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_0__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_0__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 1U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_1__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                         << 0x18U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                      >> 8U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_1__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 9U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_1__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                         << 0x18U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] 
                                      >> 8U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_1__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_1__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 2U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_2__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                         << 0x10U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                      >> 0x10U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_2__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_2__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 3U))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_3__v0 
            = (0xffU & ((vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] 
                         << 8U) | (vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] 
                                   >> 0x18U)));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_3__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T_3) 
          | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)) 
         & (vlTOPp->Tile__DOT__dcache__DOT__wmask >> 0xfU))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] 
                        >> 0x18U));
        __Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_3__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_3__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in = 0U;
    } else {
        if ((1U & (~ ((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                                & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))))) {
            if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                       & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
                vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in 
                    = ((6U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen_io_out
                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1);
            }
        }
    }
    if (((IData)(vlTOPp->Tile__DOT__dcache__DOT__wen) 
         & (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc))) {
        __Vdlyvval__Tile__DOT__dcache__DOT__metaMem_tag__v0 
            = (0xfffffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                           >> 0xcU));
        __Vdlyvset__Tile__DOT__dcache__DOT__metaMem_tag__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__dcache__DOT__metaMem_tag__v0 
            = (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                        >> 4U));
    }
    if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
        if (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt) {
            if ((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid) 
                  | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid)) 
                 | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid))) {
                vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr 
                    = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu;
            }
        } else {
            if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)))) {
                if (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen) {
                    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr 
                        = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_169;
                }
            }
        }
    }
    if (((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__illegal = 0U;
    } else {
        if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                   & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__illegal 
                = ((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                   & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                      & ((0x6fU != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                         & ((0x67U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                            & ((0x63U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                               & ((0x1063U != (0x707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                  & ((0x4063U != (0x707fU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                     & ((0x5063U != 
                                         (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                        & ((0x6063U 
                                            != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                           & ((0x7063U 
                                               != (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                              & ((3U 
                                                  != 
                                                  (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                 & ((0x1003U 
                                                     != 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                    & ((0x2003U 
                                                        != 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                       & ((0x4003U 
                                                           != 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                          & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_723)))))))))))))));
        }
    }
    if (((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd = 0U;
    } else {
        if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                   & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd 
                = ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                    ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                             ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_686)));
        }
    }
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh 
        = ((IData)(vlTOPp->reset) ? 0U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                                           ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                           : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                                               ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                               : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                                                   ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                   : 
                                                  ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                                                    ? 
                                                   ((0x300U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                     : 
                                                    ((0x344U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                      : 
                                                     ((0x304U 
                                                       == 
                                                       (0xfffU 
                                                        & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                           >> 0x14U)))
                                                       ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                       : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_121)))
                                                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth 
        = ((IData)(vlTOPp->reset) ? 0U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                                           ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                           : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                                               ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                               : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                                                   ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                   : 
                                                  ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                                                    ? 
                                                   ((0x300U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                     : 
                                                    ((0x344U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                      : 
                                                     ((0x304U 
                                                       == 
                                                       (0xfffU 
                                                        & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                           >> 0x14U)))
                                                       ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                       : 
                                                      ((0x701U 
                                                        == 
                                                        (0xfffU 
                                                         & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                            >> 0x14U)))
                                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                        : 
                                                       ((0x741U 
                                                         == 
                                                         (0xfffU 
                                                          & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                             >> 0x14U)))
                                                         ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                         : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_96)))))
                                                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret 
        = ((IData)(vlTOPp->reset) ? 0U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                                           ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                           : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                                               ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                               : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                                                   ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                   : 
                                                  ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                                                    ? 
                                                   ((0x300U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                     : 
                                                    ((0x344U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_135))
                                                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
            : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                    : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                        ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                            : ((0x344U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                : ((0x304U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                    : ((0x701U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                        : ((0x741U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                            : ((0x321U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                                : (
                                                   (0x340U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                                    : 
                                                   ((0x341U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                                     : 
                                                    ((0x342U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                                      : 
                                                     ((0x343U 
                                                       == 
                                                       (0xfffU 
                                                        & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                           >> 0x14U)))
                                                       ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                                       : 
                                                      ((0x780U 
                                                        == 
                                                        (0xfffU 
                                                         & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                            >> 0x14U)))
                                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0
                                                        : 
                                                       ((0x781U 
                                                         == 
                                                         (0xfffU 
                                                          & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                             >> 0x14U)))
                                                         ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                         : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0))))))))))))
                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh 
        = ((IData)(vlTOPp->reset) ? 0U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                                           ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                           : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                                               ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                               : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                                                   ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                   : 
                                                  ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                                                    ? 
                                                   ((0x300U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                     : 
                                                    ((0x344U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                      : 
                                                     ((0x304U 
                                                       == 
                                                       (0xfffU 
                                                        & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                           >> 0x14U)))
                                                       ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                       : 
                                                      ((0x701U 
                                                        == 
                                                        (0xfffU 
                                                         & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                            >> 0x14U)))
                                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_97))))
                                                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1)))));
    if (((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall))) 
          & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))) 
         & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                            >> 7U))))) {
        __Vdlyvval__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0 
            = (IData)(((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                        ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out))
                        : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                            ? (QData)((IData)(((IData)(4U) 
                                               + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc)))
                            : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel))
                                ? ((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                    ? (QData)((IData)(
                                                      (0xffU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift)))
                                    : ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                        ? (QData)((IData)(
                                                          (0xffffU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift)))
                                        : ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                            ? (((QData)((IData)(
                                                                (0x1ffffffU 
                                                                 & VL_NEGATE_I((IData)(
                                                                                (1U 
                                                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
                                                                                >> 7U))))))) 
                                                << 8U) 
                                               | (QData)((IData)(
                                                                 (0xffU 
                                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift))))
                                            : ((2U 
                                                == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                                                ? (
                                                   ((QData)((IData)(
                                                                    (0x1ffffU 
                                                                     & VL_NEGATE_I((IData)(
                                                                                (1U 
                                                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
                                                                                >> 0xfU))))))) 
                                                    << 0x10U) 
                                                   | (QData)((IData)(
                                                                     (0xffffU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift))))
                                                : (QData)((IData)(vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data))))))
                                : (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu))))));
        __Vdlyvset__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0 = 1U;
        __Vdlyvdim0__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0 
            = (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                        >> 7U));
    }
    vlTOPp->Tile__DOT__dcache__DOT__write_count = __Vdly__Tile__DOT__dcache__DOT__write_count;
    vlTOPp->Tile__DOT__icache__DOT__read_count = __Vdly__Tile__DOT__icache__DOT__read_count;
    vlTOPp->Tile__DOT__dcache__DOT__read_count = __Vdly__Tile__DOT__dcache__DOT__read_count;
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_0__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_0__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_0__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_2__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_2__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_2__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_3__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_3__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_3__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_1__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_1__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_1__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_2__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_1_2[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_2__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_2__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_0__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_0__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_0__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_1__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_1_1[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_1__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_1__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_3__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_3__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_3__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_1_0__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_1_0[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_1_0__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_1_0__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_2__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_2__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_2__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_0__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_0_0[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_0__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_0__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_1__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_0_1[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_1__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_1__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_2_1__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_2_1__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_2_1__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_2__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_0_2[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_2__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_2__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_0_3__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_0_3[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_0_3__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_0_3__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__dataMem_3_3__v0) {
        vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3[__Vdlyvdim0__Tile__DOT__icache__DOT__dataMem_3_3__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__dataMem_3_3__v0;
    }
    if (__Vdlyvset__Tile__DOT__icache__DOT__metaMem_tag__v0) {
        vlTOPp->Tile__DOT__icache__DOT__metaMem_tag[__Vdlyvdim0__Tile__DOT__icache__DOT__metaMem_tag__v0] 
            = __Vdlyvval__Tile__DOT__icache__DOT__metaMem_tag__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_0__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_0__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_0__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_2__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_2__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_2__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_3__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_3[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_3__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_3__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_1__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_1__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_1__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_2__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_2[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_2__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_2__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_0__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_0__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_0__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_1__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_1[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_1__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_1__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_3__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_3__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_3__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_1_0__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_0[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_1_0__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_1_0__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_2__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_2__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_2__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_0__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_0[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_0__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_0__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_1__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_1[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_1__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_1__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_2_1__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_2_1__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_2_1__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_2__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_2[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_2__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_2__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_0_3__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_3[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_0_3__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_0_3__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__dataMem_3_3__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3[__Vdlyvdim0__Tile__DOT__dcache__DOT__dataMem_3_3__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__dataMem_3_3__v0;
    }
    if (__Vdlyvset__Tile__DOT__dcache__DOT__metaMem_tag__v0) {
        vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag[__Vdlyvdim0__Tile__DOT__dcache__DOT__metaMem_tag__v0] 
            = __Vdlyvval__Tile__DOT__dcache__DOT__metaMem_tag__v0;
    }
    if (__Vdlyvset__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[__Vdlyvdim0__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0] 
            = __Vdlyvval__Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs__v0;
    }
    vlTOPp->Tile__DOT__icache__DOT__ren_reg = (((~ (IData)(vlTOPp->Tile__DOT__icache__DOT__wen)) 
                                                & ((0U 
                                                    == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                   | (1U 
                                                      == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)))) 
                                               & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__dcache__DOT__ren_reg = (((~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__wen)) 
                                                & ((0U 
                                                    == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                   | (1U 
                                                      == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)))) 
                                               & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___cycle_T_1 
        = ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle);
    vlTOPp->io_host_tohost = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost;
    vlTOPp->Tile__DOT__icache__DOT__rdata[0U] = ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_3
                                                  [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_2
                                                     [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_1
                                                        [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__icache__DOT__dataMem_0_0
                                                       [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0])));
    vlTOPp->Tile__DOT__icache__DOT__rdata[1U] = ((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3
                                                  [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_2
                                                     [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_1
                                                        [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__icache__DOT__dataMem_1_0
                                                       [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0])));
    vlTOPp->Tile__DOT__icache__DOT__rdata[2U] = (IData)(
                                                        (((QData)((IData)(
                                                                          ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3
                                                                            [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                            << 0x18U) 
                                                                           | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2
                                                                               [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                               << 0x10U) 
                                                                              | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]))))) 
                                                          << 0x20U) 
                                                         | (QData)((IData)(
                                                                           ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3
                                                                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                             << 0x18U) 
                                                                            | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                               | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0])))))));
    vlTOPp->Tile__DOT__icache__DOT__rdata[3U] = (IData)(
                                                        ((((QData)((IData)(
                                                                           ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3
                                                                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                             << 0x18U) 
                                                                            | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                               | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]))))) 
                                                           << 0x20U) 
                                                          | (QData)((IData)(
                                                                            ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3
                                                                              [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                              << 0x18U) 
                                                                             | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                                | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0])))))) 
                                                         >> 0x20U));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___time_T_1 
        = ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_);
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1 = 0U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1 
                = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                    ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE)
                    : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_200));
        }
    }
    vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_data 
        = vlTOPp->Tile__DOT__icache__DOT__metaMem_tag
        [vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_addr_pipe_0];
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc 
        = (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_239);
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV = 3U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV 
                = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                    ? 3U : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                             ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1)
                             : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_178)));
        }
    }
    vlTOPp->Tile__DOT__dcache__DOT__rdata[0U] = ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_3
                                                  [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_2
                                                     [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_1
                                                        [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_0
                                                       [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0])));
    vlTOPp->Tile__DOT__dcache__DOT__rdata[1U] = ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_3
                                                  [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_2
                                                     [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_1
                                                        [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_0
                                                       [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0])));
    vlTOPp->Tile__DOT__dcache__DOT__rdata[2U] = (IData)(
                                                        (((QData)((IData)(
                                                                          ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3
                                                                            [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                            << 0x18U) 
                                                                           | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2
                                                                               [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                               << 0x10U) 
                                                                              | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]))))) 
                                                          << 0x20U) 
                                                         | (QData)((IData)(
                                                                           ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3
                                                                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                             << 0x18U) 
                                                                            | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                               | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0])))))));
    vlTOPp->Tile__DOT__dcache__DOT__rdata[3U] = (IData)(
                                                        ((((QData)((IData)(
                                                                           ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3
                                                                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                             << 0x18U) 
                                                                            | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                               | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]))))) 
                                                           << 0x20U) 
                                                          | (QData)((IData)(
                                                                            ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3
                                                                              [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                              << 0x18U) 
                                                                             | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                                | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0])))))) 
                                                         >> 0x20U));
    vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data 
        = vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag
        [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0];
    if (vlTOPp->Tile__DOT__dcache_io_cpu_resp_valid) {
        vlTOPp->Tile__DOT__dcache__DOT__addr_reg = (IData)(
                                                           ((QData)((IData)(
                                                                            (0x3fffffffU 
                                                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT___daddr_T 
                                                                                >> 2U)))) 
                                                            << 2U));
    }
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2 
        = ((0xffffffffU == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1 
        = ((0xffffffffU == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh);
    if (((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type = 0U;
    } else {
        if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                   & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type 
                = vlTOPp->Tile__DOT__core__DOT__ctrl_io_ld_type;
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc = 0U;
    } else {
        if ((1U & (~ ((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                                & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))))) {
            if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                       & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
                vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc 
                    = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc;
            }
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu = 0U;
    } else {
        if ((1U & (~ ((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                                & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))))) {
            if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                       & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
                vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                    = (((0U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)) 
                        | (1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum
                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___out_T_25);
            }
        }
    }
    if ((1U & (~ ((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                            & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))))) {
        if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                   & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel 
                = ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                    ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                             ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_588)));
        }
    }
    if (((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en = 0U;
    } else {
        if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                   & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en 
                = ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                   | ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                      | ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                         | ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                            | ((0x63U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                               & ((0x1063U != (0x707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                  & ((0x4063U != (0x707fU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                     & ((0x5063U != 
                                         (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                        & ((0x6063U 
                                            != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                           & ((0x7063U 
                                               != (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                              & ((3U 
                                                  == 
                                                  (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                 | ((0x1003U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                    | ((0x2003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                       | ((0x4003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                          | ((0x5003U 
                                                              == 
                                                              (0x707fU 
                                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                             | ((0x23U 
                                                                 != 
                                                                 (0x707fU 
                                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                & ((0x1023U 
                                                                    != 
                                                                    (0x707fU 
                                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_622))))))))))))))))));
        }
    }
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst = 0x13U;
    } else {
        if ((1U & (~ ((IData)(vlTOPp->reset) | ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                                                & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)))))) {
            if ((1U & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
                       & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))))) {
                vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                    = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst;
            }
        }
    }
    vlTOPp->Tile__DOT__icache__DOT__state = __Vdly__Tile__DOT__icache__DOT__state;
    vlTOPp->Tile__DOT__dcache__DOT__state = __Vdly__Tile__DOT__dcache__DOT__state;
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE 
        = __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE;
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1 
        = __Vdly__Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1;
    vlTOPp->Tile__DOT__dcache__DOT__read[0U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg)
                                                 ? (IData)(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0)
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata[0U]
                                                  : 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[0U]));
    vlTOPp->Tile__DOT__dcache__DOT__read[1U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg)
                                                 ? (IData)(
                                                           (vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0 
                                                            >> 0x20U))
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata[1U]
                                                  : 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[1U]));
    vlTOPp->Tile__DOT__dcache__DOT__read[2U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg)
                                                 ? (IData)(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_1)
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata[2U]
                                                  : 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[2U]));
    vlTOPp->Tile__DOT__dcache__DOT__read[3U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg)
                                                 ? (IData)(
                                                           (vlTOPp->Tile__DOT__dcache__DOT__refill_buf_1 
                                                            >> 0x20U))
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata[3U]
                                                  : 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[3U]));
    vlTOPp->Tile__DOT__arb_io_nasti_r_ready = (((6U 
                                                 == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                & (1U 
                                                   == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))) 
                                               | ((6U 
                                                   == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                  & (2U 
                                                     == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))));
    vlTOPp->Tile__DOT__dcache_io_nasti_b_ready = ((0U 
                                                   != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                  & ((1U 
                                                      != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                     & ((2U 
                                                         != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                        & ((3U 
                                                            != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                           & (4U 
                                                              == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))))));
    vlTOPp->Tile__DOT__dcache_io_nasti_w_valid = ((0U 
                                                   != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                  & ((1U 
                                                      != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                     & ((2U 
                                                         != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                        & (3U 
                                                           == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)))));
    vlTOPp->io_nasti_aw_bits_addr = ((vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data 
                                      << 0xcU) | (0xff0U 
                                                  & vlTOPp->Tile__DOT__dcache__DOT__addr_reg));
    __Vtemp17[0U] = 1U;
    __Vtemp17[1U] = 0U;
    __Vtemp17[2U] = 0U;
    __Vtemp17[3U] = 0U;
    __Vtemp17[4U] = 0U;
    __Vtemp17[5U] = 0U;
    __Vtemp17[6U] = 0U;
    __Vtemp17[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp18, __Vtemp17, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[0U] = (vlTOPp->Tile__DOT__dcache__DOT__v[0U] 
                                                  | __Vtemp18[0U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[1U] = (vlTOPp->Tile__DOT__dcache__DOT__v[1U] 
                                                  | __Vtemp18[1U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[2U] = (vlTOPp->Tile__DOT__dcache__DOT__v[2U] 
                                                  | __Vtemp18[2U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[3U] = (vlTOPp->Tile__DOT__dcache__DOT__v[3U] 
                                                  | __Vtemp18[3U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[4U] = (vlTOPp->Tile__DOT__dcache__DOT__v[4U] 
                                                  | __Vtemp18[4U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[5U] = (vlTOPp->Tile__DOT__dcache__DOT__v[5U] 
                                                  | __Vtemp18[5U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[6U] = (vlTOPp->Tile__DOT__dcache__DOT__v[6U] 
                                                  | __Vtemp18[6U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[7U] = (vlTOPp->Tile__DOT__dcache__DOT__v[7U] 
                                                  | __Vtemp18[7U]);
    __Vtemp20[0U] = 1U;
    __Vtemp20[1U] = 0U;
    __Vtemp20[2U] = 0U;
    __Vtemp20[3U] = 0U;
    __Vtemp20[4U] = 0U;
    __Vtemp20[5U] = 0U;
    __Vtemp20[6U] = 0U;
    __Vtemp20[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp21, __Vtemp20, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[0U] = (vlTOPp->Tile__DOT__dcache__DOT__d[0U] 
                                                  | __Vtemp21[0U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[1U] = (vlTOPp->Tile__DOT__dcache__DOT__d[1U] 
                                                  | __Vtemp21[1U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[2U] = (vlTOPp->Tile__DOT__dcache__DOT__d[2U] 
                                                  | __Vtemp21[2U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[3U] = (vlTOPp->Tile__DOT__dcache__DOT__d[3U] 
                                                  | __Vtemp21[3U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[4U] = (vlTOPp->Tile__DOT__dcache__DOT__d[4U] 
                                                  | __Vtemp21[4U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[5U] = (vlTOPp->Tile__DOT__dcache__DOT__d[5U] 
                                                  | __Vtemp21[5U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[6U] = (vlTOPp->Tile__DOT__dcache__DOT__d[6U] 
                                                  | __Vtemp21[6U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[7U] = (vlTOPp->Tile__DOT__dcache__DOT__d[7U] 
                                                  | __Vtemp21[7U]);
    __Vtemp24[0U] = 1U;
    __Vtemp24[1U] = 0U;
    __Vtemp24[2U] = 0U;
    __Vtemp24[3U] = 0U;
    __Vtemp24[4U] = 0U;
    __Vtemp24[5U] = 0U;
    __Vtemp24[6U] = 0U;
    __Vtemp24[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp25, __Vtemp24, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[0U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[0U]) 
                                                  | __Vtemp25[0U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[1U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[1U]) 
                                                  | __Vtemp25[1U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[2U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[2U]) 
                                                  | __Vtemp25[2U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[3U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[3U]) 
                                                  | __Vtemp25[3U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[4U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[4U]) 
                                                  | __Vtemp25[4U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[5U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[5U]) 
                                                  | __Vtemp25[5U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[6U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[6U]) 
                                                  | __Vtemp25[6U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[7U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[7U]) 
                                                  | __Vtemp25[7U]);
    VL_SHIFTR_WWI(256,256,8, __Vtemp27, vlTOPp->Tile__DOT__dcache__DOT__v, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[0U] = __Vtemp27[0U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[1U] = __Vtemp27[1U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[2U] = __Vtemp27[2U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[3U] = __Vtemp27[3U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[4U] = __Vtemp27[4U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[5U] = __Vtemp27[5U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[6U] = __Vtemp27[6U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[7U] = __Vtemp27[7U];
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc 
        = (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___GEN_31);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc_check) 
           & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
              >> 1U));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid 
        = (1U & ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                  ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
                  : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
                      : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type)) 
                         & (0U != (3U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid 
        = (1U & ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type))
                  ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
                  : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type)) 
                     & (0U != (3U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret 
        = (((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
            & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                  >> 0x14U))) & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x1cU));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_68 
        = ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
            : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_
                : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh
                    : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                        : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc
                            : ((0x342U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                                : ((0x343U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                    : ((0x344U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP) 
                                            << 7U) 
                                           | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP) 
                                              << 3U))
                                        : ((0x780U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                            : ((0x781U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost
                                                : (
                                                   (0x300U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? 
                                                   (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1) 
                                                     << 4U) 
                                                    | (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1) 
                                                        << 3U) 
                                                       | (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                                           << 1U) 
                                                          | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE))))
                                                    : 0U)))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__csrValid 
        = (((((((((((((((((((((((((((((0xc00U == (0xfffU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                     >> 0x14U))) 
                                      | (0xc01U == 
                                         (0xfffU & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))) 
                                     | (0xc02U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))) 
                                    | (0xc80U == (0xfffU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                     >> 0x14U)))) 
                                   | (0xc81U == (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))) 
                                  | (0xc82U == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))) 
                                 | (0x900U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))) 
                                | (0x901U == (0xfffU 
                                              & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))) 
                               | (0x902U == (0xfffU 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                >> 0x14U)))) 
                              | (0x980U == (0xfffU 
                                            & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))) 
                             | (0x981U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))) 
                            | (0x982U == (0xfffU & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))) 
                           | (0xf00U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))) 
                          | (0xf01U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))) 
                         | (0xf10U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))) 
                        | (0x301U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                >> 0x14U)))) 
                       | (0x302U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))) 
                      | (0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                              >> 0x14U)))) 
                     | (0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))) 
                    | (0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))) 
                   | (0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))) 
                  | (0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                          >> 0x14U)))) 
                 | (0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))) 
                | (0x342U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                        >> 0x14U)))) 
               | (0x343U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                       >> 0x14U)))) 
              | (0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                      >> 0x14U)))) 
             | (0x780U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U)))) | 
            (0x781U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                  >> 0x14U)))) | (0x300U 
                                                  == 
                                                  (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid 
        = ((3U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                  >> 0x1cU)) <= (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall 
        = (((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
            & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                  >> 0x14U))) & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                    >> 0x1cU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak 
        = (((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
            & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
               >> 0x14U)) & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                >> 0x1cU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen 
        = ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
           | (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd) 
               >> 1U) & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0xfU)))));
    if (vlTOPp->reset) {
        vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst = 0x13U;
    } else {
        if ((1U & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)))) {
            vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                = (((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__started) 
                      | (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_inst_kill)) 
                     | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond_io_taken)) 
                    | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))
                    ? 0x13U : ((3U == (3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                             >> 2U)))
                                ? vlTOPp->Tile__DOT__icache__DOT__read[3U]
                                : ((2U == (3U & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                 >> 2U)))
                                    ? vlTOPp->Tile__DOT__icache__DOT__read[2U]
                                    : ((1U == (3U & 
                                               (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                >> 2U)))
                                        ? vlTOPp->Tile__DOT__icache__DOT__read[1U]
                                        : vlTOPp->Tile__DOT__icache__DOT__read[0U]))));
        }
    }
    vlTOPp->io_nasti_w_bits_data = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count)
                                     ? (((QData)((IData)(
                                                         vlTOPp->Tile__DOT__dcache__DOT__read[3U])) 
                                         << 0x20U) 
                                        | (QData)((IData)(
                                                          vlTOPp->Tile__DOT__dcache__DOT__read[2U])))
                                     : (((QData)((IData)(
                                                         vlTOPp->Tile__DOT__dcache__DOT__read[1U])) 
                                         << 0x20U) 
                                        | (QData)((IData)(
                                                          vlTOPp->Tile__DOT__dcache__DOT__read[0U]))));
    vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data 
        = ((3U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                         >> 2U))) ? vlTOPp->Tile__DOT__dcache__DOT__read[3U]
            : ((2U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                             >> 2U))) ? vlTOPp->Tile__DOT__dcache__DOT__read[2U]
                : ((1U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                 >> 2U))) ? vlTOPp->Tile__DOT__dcache__DOT__read[1U]
                    : vlTOPp->Tile__DOT__dcache__DOT__read[0U])));
    vlTOPp->io_nasti_r_ready = vlTOPp->Tile__DOT__arb_io_nasti_r_ready;
    vlTOPp->Tile__DOT__arb_io_nasti_b_ready = ((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_b_ready) 
                                               & (4U 
                                                  == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->io_nasti_w_valid = ((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_valid) 
                                & (3U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    VL_SHIFTR_WWI(256,256,8, __Vtemp28, vlTOPp->Tile__DOT__dcache__DOT__d, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT__is_dirty = (1U 
                                                & (vlTOPp->Tile__DOT__dcache__DOT___hit_T[0U] 
                                                   & __Vtemp28[0U]));
    vlTOPp->Tile__DOT__dcache__DOT__hit = (vlTOPp->Tile__DOT__dcache__DOT___hit_T[0U] 
                                           & (vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data 
                                              == (0xfffffU 
                                                  & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                                     >> 0xcU))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_80 
        = ((0x900U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle
            : ((0x901U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_
                : ((0x902U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret
                    : ((0x980U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh
                        : ((0x981U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh
                            : ((0x982U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth
                                : ((0xf00U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? 0x100100U : (
                                                   (0xf01U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? 0U
                                                    : 
                                                   ((0xf10U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? 0U
                                                     : 
                                                    ((0x301U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? 0x100U
                                                      : 
                                                     ((0x302U 
                                                       == 
                                                       (0xfffU 
                                                        & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                           >> 0x14U)))
                                                       ? 0U
                                                       : 
                                                      ((0x304U 
                                                        == 
                                                        (0xfffU 
                                                         & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                            >> 0x14U)))
                                                        ? 
                                                       (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE) 
                                                         << 7U) 
                                                        | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE) 
                                                           << 3U))
                                                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_68))))))))))));
    vlTOPp->Tile__DOT__icache__DOT__read[0U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)
                                                 ? (IData)(vlTOPp->Tile__DOT__icache__DOT__refill_buf_0)
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__icache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata[0U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata_buf[0U]));
    vlTOPp->Tile__DOT__icache__DOT__read[1U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)
                                                 ? (IData)(
                                                           (vlTOPp->Tile__DOT__icache__DOT__refill_buf_0 
                                                            >> 0x20U))
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__icache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata[1U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata_buf[1U]));
    vlTOPp->Tile__DOT__icache__DOT__read[2U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)
                                                 ? (IData)(vlTOPp->Tile__DOT__icache__DOT__refill_buf_1)
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__icache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata[2U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata_buf[2U]));
    vlTOPp->Tile__DOT__icache__DOT__read[3U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)
                                                 ? (IData)(
                                                           (vlTOPp->Tile__DOT__icache__DOT__refill_buf_1 
                                                            >> 0x20U))
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__icache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata[3U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata_buf[3U]));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt 
        = (((((((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__illegal) 
                  | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid)) 
                 | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid)) 
                | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid)) 
               | ((0U != (3U & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))) 
                  & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__csrValid)) 
                     | (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid))))) 
              | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen) 
                 & (((3U == (3U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                   >> 0x1eU))) | (0x301U 
                                                  == 
                                                  (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))) 
                    | (0x302U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))))) 
             | ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
                & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid)))) 
            | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall)) 
           | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
        = ((0x1fU >= ((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                                << 3U)) | (8U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                                                 << 3U))))
            ? (vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data 
               >> ((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                             << 3U)) | (8U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                                              << 3U))))
            : 0U);
    vlTOPp->io_nasti_b_ready = vlTOPp->Tile__DOT__arb_io_nasti_b_ready;
    vlTOPp->Tile__DOT__dcache_io_cpu_resp_valid = (
                                                   ((0U 
                                                     == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                    | ((1U 
                                                        == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                       & (IData)(vlTOPp->Tile__DOT__dcache__DOT__hit))) 
                                                   | ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg) 
                                                      & (~ (IData)(
                                                                   (0U 
                                                                    != (IData)(vlTOPp->Tile__DOT__dcache__DOT__cpu_mask))))));
    vlTOPp->Tile__DOT__dcache__DOT___wen_T = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__hit) 
                                              | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out 
        = ((0xc00U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle
            : ((0xc01U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_
                : ((0xc02U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret
                    : ((0xc80U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh
                        : ((0xc81U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh
                            : ((0xc82U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth
                                : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_80))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__started 
        = vlTOPp->reset;
    vlTOPp->Tile__DOT__dcache__DOT___wen_T_3 = (((2U 
                                                  == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                 & ((IData)(vlTOPp->Tile__DOT__dcache__DOT__hit) 
                                                    | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg))) 
                                                & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)));
    if (vlTOPp->Tile__DOT__icache_io_cpu_resp_valid) {
        vlTOPp->Tile__DOT__icache__DOT__addr_reg = (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__next_pc);
    }
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_622 
        = ((0x2023U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x13U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              | ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 | ((0x3013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x4013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       | ((0x6013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          | ((0x7013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             | ((0x1013U == (0xfe00707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                | ((0x5013U == (0xfe00707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   | ((0x40005013U 
                                       == (0xfe00707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x33U == 
                                          (0xfe00707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         | ((0x40000033U 
                                             == (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            | ((0x1033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               | ((0x2033U 
                                                   == 
                                                   (0xfe00707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  | ((0x3033U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     | ((0x4033U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        | ((0x5033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           | ((0x40005033U 
                                                               == 
                                                               (0xfe00707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              | ((0x6033U 
                                                                  == 
                                                                  (0xfe00707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                 | ((0x7033U 
                                                                     == 
                                                                     (0xfe00707fU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                    | ((0xfU 
                                                                        != 
                                                                        (0xf00fffffU 
                                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                       & ((0x100fU 
                                                                           != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                                          & ((0x1073U 
                                                                              == 
                                                                              (0x707fU 
                                                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                             | ((0x2073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x3073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x5073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x6073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | (0x7073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)))))))))))))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_706 
        = ((0x3033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x4033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x5033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x40005033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    & ((0x6033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x7033U != (0xfe00707fU 
                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0xfU != (0xf00fffffU 
                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x100fU != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                & ((0x1073U != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x2073U != (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x3073U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x5073U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x6073U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x7073U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x73U 
                                                      != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                     & ((0x100073U 
                                                         != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                        & ((0x10000073U 
                                                            != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                           & ((0x10200073U 
                                                               != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                              & (0x2007033U 
                                                                 != 
                                                                 (0xfe00707fU 
                                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_ld_type = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 0U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                            ? 0U : ((0x67U == (0x707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                     ? 0U : ((0x63U 
                                              == (0x707fU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                              ? 0U : 
                                             ((0x1063U 
                                               == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                               ? 0U
                                               : ((0x4063U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                   ? 0U
                                                   : 
                                                  ((0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 3U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 2U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 5U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 4U
                                                           : 0U)))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_414 
        = ((0x1033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x2033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x3033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x4033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    & ((0x5033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x40005033U != (0xfe00707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0x6033U != (0xfe00707fU 
                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x7033U != (0xfe00707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0xfU != (0xf00fffffU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x100fU == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                      | ((0x1073U == 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         | ((0x2073U 
                                             == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            | ((0x3073U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               | ((0x5073U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  | ((0x6073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     | ((0x7073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        | ((0x73U 
                                                            != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                           & ((0x100073U 
                                                               != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                              & (0x10000073U 
                                                                 == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_558 
        = ((0x4033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x5033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x40005033U == (0xfe00707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x6033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x7033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0xfU 
                                                    == 
                                                    (0xf00fffffU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x100fU 
                                                     == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                     ? 0U
                                                     : 
                                                    ((0x1073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 3U
                                                      : 
                                                     ((0x2073U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 3U
                                                       : 
                                                      ((0x3073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 3U
                                                        : 
                                                       ((0x5073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 3U
                                                         : 
                                                        ((0x6073U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 3U
                                                          : 
                                                         ((0x7073U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 3U
                                                           : 
                                                          ((0x73U 
                                                            == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                            ? 3U
                                                            : 
                                                           ((0x100073U 
                                                             == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                             ? 3U
                                                             : 
                                                            ((0x10000073U 
                                                              == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                              ? 3U
                                                              : 0U))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_656 
        = ((0x4033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x5033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x40005033U == (0xfe00707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x6033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x7033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0xfU 
                                                    == 
                                                    (0xf00fffffU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x100fU 
                                                     == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                     ? 0U
                                                     : 
                                                    ((0x1073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 1U
                                                      : 
                                                     ((0x2073U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 2U
                                                       : 
                                                      ((0x3073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 3U
                                                        : 
                                                       ((0x5073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x6073U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 2U
                                                          : 
                                                         ((0x7073U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 3U
                                                           : 
                                                          ((0x73U 
                                                            == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                            ? 4U
                                                            : 
                                                           ((0x100073U 
                                                             == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                             ? 4U
                                                             : 
                                                            ((0x10000073U 
                                                              == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                              ? 4U
                                                              : 0U))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_489 
        = ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x1063U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x4063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x5063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((3U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x1003U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x2003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x4003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x5003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x23U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 3U
                                                           : 
                                                          ((0x1023U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 2U
                                                            : 
                                                           ((0x2023U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 1U
                                                             : 0U)))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 0U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                            ? 0U : ((0x67U == (0x707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                     ? 0U : ((0x63U 
                                              == (0x707fU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                              ? 3U : 
                                             ((0x1063U 
                                               == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                               ? 6U
                                               : ((0x4063U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                   ? 2U
                                                   : 
                                                  ((0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 5U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 1U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 4U
                                                      : 0U))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_117 
        = ((0x4033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x5033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x40005033U == (0xfe00707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x6033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x7033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0xfU 
                                                    == 
                                                    (0xf00fffffU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x100fU 
                                                     == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                     ? 2U
                                                     : 
                                                    ((0x1073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 2U
                                                      : 
                                                     ((0x2073U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 2U
                                                       : 
                                                      ((0x3073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 2U
                                                        : 
                                                       ((0x5073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 2U
                                                         : 
                                                        ((0x6073U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 2U
                                                          : 
                                                         ((0x7073U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 2U
                                                           : 
                                                          ((0x73U 
                                                            == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                            ? 0U
                                                            : 
                                                           ((0x100073U 
                                                             == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                             ? 0U
                                                             : 
                                                            ((0x10000073U 
                                                              == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                              ? 3U
                                                              : 0U))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm 
        = ((0x100000U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                         >> 0xbU)) | ((0xff000U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                      | ((0x800U & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                           >> 9U)) 
                                         | ((0x7e0U 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                >> 0x14U)) 
                                            | (0x1eU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                  >> 0x14U))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata2 
        = ((0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                            >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
           [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                      >> 0x14U))] : 0U);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2hazard 
        = (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
            & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                               >> 0x14U)))) & ((0x1fU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                   >> 0x14U)) 
                                               == (0x1fU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 7U))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_311 
        = ((0x40005033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 9U : ((0x6033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 3U : ((0x7033U == (0xfe00707fU 
                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 2U : ((0xfU == (0xf00fffffU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0xfU : ((0x100fU 
                                                  == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                  ? 0xfU
                                                  : 
                                                 ((0x1073U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                   ? 0xaU
                                                   : 
                                                  ((0x2073U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0xaU
                                                    : 
                                                   ((0x3073U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0xaU
                                                     : 
                                                    ((0x5073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0xfU
                                                      : 
                                                     ((0x6073U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0xfU
                                                       : 
                                                      ((0x7073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0xfU
                                                        : 
                                                       ((0x73U 
                                                         == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                         ? 0xfU
                                                         : 
                                                        ((0x100073U 
                                                          == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                          ? 0xfU
                                                          : 
                                                         ((0x10000073U 
                                                           == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                           ? 0xfU
                                                           : 
                                                          ((0x10200073U 
                                                            == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                            ? 0xfU
                                                            : 
                                                           ((0x2007033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0xcU
                                                             : 0xfU))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata1 
        = ((0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                            >> 0xfU))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
           [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                      >> 0xfU))] : 0U);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1hazard 
        = (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
            & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                               >> 0xfU)))) & ((0x1fU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                  >> 0xfU)) 
                                              == (0x1fU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                     >> 7U))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_156 
        = ((0x5073U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x6073U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x7073U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x73U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                    & ((0x100073U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                       & ((0x10000073U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                          & ((0x10200073U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                             & (0x2007033U == (0xfe00707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_266 
        = ((0x2033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x3033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x4033U == (0xfe00707fU 
                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x5033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x40005033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6033U 
                                                    == 
                                                    (0xfe00707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7033U 
                                                     == 
                                                     (0xfe00707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0xfU 
                                                      == 
                                                      (0xf00fffffU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x100fU 
                                                       == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                       ? 0U
                                                       : 
                                                      ((0x1073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x2073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x3073U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x5073U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 6U
                                                           : 
                                                          ((0x6073U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 6U
                                                            : 
                                                           ((0x7073U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 6U
                                                             : 0U)))))))))))))));
    vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid = (
                                                   (0U 
                                                    != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                   & ((1U 
                                                       == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                       ? 
                                                      ((~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__hit)) 
                                                       & (~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_dirty)))
                                                       : 
                                                      ((2U 
                                                        == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                        ? 
                                                       ((~ 
                                                         ((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T) 
                                                          | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))) 
                                                        & (~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_dirty)))
                                                        : 
                                                       ((3U 
                                                         != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                        & ((4U 
                                                            != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                           & (5U 
                                                              == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)))))));
    vlTOPp->Tile__DOT__dcache_io_nasti_aw_valid = (
                                                   (0U 
                                                    != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                   & ((1U 
                                                       == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                       ? 
                                                      ((~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__hit)) 
                                                       & (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_dirty))
                                                       : 
                                                      ((2U 
                                                        == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T) 
                                                            | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))) 
                                                          & (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_dirty)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
        = ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))
            ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out 
               & (~ vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in))
            : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))
                ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out 
                   | vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in)
                : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in
                    : 0U)));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_723 
        = ((0x5003U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x23U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x1023U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x2023U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    & ((0x13U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x2013U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0x3013U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x4013U != (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x6013U != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x7013U != (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x1013U != 
                                          (0xfe00707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x5013U 
                                             != (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x40005013U 
                                                != 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x33U 
                                                   != 
                                                   (0xfe00707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x40000033U 
                                                      != 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & ((0x1033U 
                                                         != 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((0x2033U 
                                                            != 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_706))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_434 
        = ((0x7063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((3U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              | ((0x1003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 | ((0x2003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x4003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       | ((0x5003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          | ((0x23U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x1023U != (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x2023U != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x13U != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x2013U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x3013U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x4013U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x6013U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x7013U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & ((0x1013U 
                                                         != 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((0x5013U 
                                                            != 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & ((0x40005013U 
                                                               != 
                                                               (0xfe00707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              & ((0x33U 
                                                                  != 
                                                                  (0xfe00707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                 & ((0x40000033U 
                                                                     != 
                                                                     (0xfe00707fU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                    & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_414)))))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_573 
        = ((0x2023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x13U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x3013U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6013U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7013U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x1013U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x5013U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x40005013U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x33U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x40000033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x1033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x2033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x3033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_558))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_671 
        = ((0x2023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x13U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x3013U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6013U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7013U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x1013U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x5013U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x40005013U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x33U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x40000033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x1033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x2033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x3033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_656))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_st_type = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 0U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                            ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_489))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_132 
        = ((0x2023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x13U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x3013U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6013U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7013U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x1013U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x5013U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x40005013U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x33U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x40000033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x1033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x2033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x3033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_117))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2 = 
        (((0U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel)) 
          & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2hazard))
          ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
          : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata2);
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_326 
        = ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 5U : ((0x3013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 7U : ((0x4013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 4U : ((0x6013U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 3U : ((0x7013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 2U
                                                : (
                                                   (0x1013U 
                                                    == 
                                                    (0xfe00707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 6U
                                                    : 
                                                   ((0x5013U 
                                                     == 
                                                     (0xfe00707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 8U
                                                     : 
                                                    ((0x40005013U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 9U
                                                      : 
                                                     ((0x33U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x40000033U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 1U
                                                        : 
                                                       ((0x1033U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 6U
                                                         : 
                                                        ((0x2033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 5U
                                                          : 
                                                         ((0x3033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 7U
                                                           : 
                                                          ((0x4033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 4U
                                                            : 
                                                           ((0x5033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 8U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_311))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1 = 
        (((0U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel)) 
          & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1hazard))
          ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
          : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata1);
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_223 
        = ((0x1013U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x5013U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x40005013U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x33U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x40000033U == (0xfe00707fU 
                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       | ((0x1033U == (0xfe00707fU 
                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          | ((0x2033U == (0xfe00707fU 
                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             | ((0x3033U == (0xfe00707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                | ((0x4033U == (0xfe00707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   | ((0x5033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x40005033U 
                                          == (0xfe00707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         | ((0x6033U 
                                             == (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            | ((0x7033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               | ((0xfU 
                                                   != 
                                                   (0xf00fffffU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x100fU 
                                                      != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                     & ((0x1073U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((0x2073U 
                                                            != 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & ((0x3073U 
                                                               != 
                                                               (0x707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_156)))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_189 
        = ((0x7063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((3U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              | ((0x1003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 | ((0x2003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x4003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       | ((0x5003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          | ((0x23U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             | ((0x1023U == (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                | ((0x2023U == (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   | ((0x13U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x2013U == 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         | ((0x3013U 
                                             == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            | ((0x4013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               | ((0x6013U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  | ((0x7013U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     | ((0x1013U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        | ((0x5013U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           | ((0x40005013U 
                                                               == 
                                                               (0xfe00707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              | ((0x33U 
                                                                  == 
                                                                  (0xfe00707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                 | ((0x40000033U 
                                                                     == 
                                                                     (0xfe00707fU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                    | ((0x1033U 
                                                                        == 
                                                                        (0xfe00707fU 
                                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                       | ((0x2033U 
                                                                           == 
                                                                           (0xfe00707fU 
                                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                          | ((0x3033U 
                                                                              == 
                                                                              (0xfe00707fU 
                                                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                             | ((0x4033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x5033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x40005033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x6033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x7033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0xfU 
                                                                                != 
                                                                                (0xf00fffffU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                & ((0x100fU 
                                                                                != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                                                & ((0x1073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x2073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x3073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_156))))))))))))))))))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_281 
        = ((0x23U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 2U : ((0x1023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 2U : ((0x2023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 2U : ((0x13U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 1U : ((0x2013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 1U
                                                : (
                                                   (0x3013U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 1U
                                                    : 
                                                   ((0x4013U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 1U
                                                     : 
                                                    ((0x6013U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 1U
                                                      : 
                                                     ((0x7013U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 1U
                                                       : 
                                                      ((0x1013U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 1U
                                                        : 
                                                       ((0x5013U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x40005013U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 1U
                                                          : 
                                                         ((0x33U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x40000033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x1033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_266))))))))))))))));
    vlTOPp->Tile__DOT__arb_io_nasti_aw_valid = ((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_aw_valid) 
                                                & (0U 
                                                   == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_97 
        = ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
            : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                    : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                        : ((0x342U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                            : ((0x343U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                : ((0x780U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                    : ((0x781U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                        : ((0x900U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                            : ((0x901U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                : (
                                                   (0x902U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                    : 
                                                   ((0x980U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                     : 
                                                    ((0x981U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1)))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_121 
        = ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
            : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                    : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                        : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                            : ((0x342U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                : ((0x343U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                    : ((0x780U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                        : ((0x781U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                            : ((0x900U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                : (
                                                   (0x901U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                    : 
                                                   ((0x902U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                     : 
                                                    ((0x980U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2)))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_165 
        = ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
            : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
                : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
                    : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
                        : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
                            : ((0x321U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_166 
        = ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
            : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                    : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                        : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                            : ((0x321U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                                : ((0x340U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch)))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_168 
        = ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
            : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                    : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                        : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                            : ((0x321U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                                : ((0x340U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                                    : ((0x341U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                                        : ((0x342U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? (0x8000000fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata)
                                            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause)))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_169 
        = ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
            : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                    : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                        : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                            : ((0x321U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                : ((0x340U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                    : ((0x341U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                        : ((0x342U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                            : ((0x343U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_176 
        = (3U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                         >> 4U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_178 
        = (3U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                         >> 1U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_179 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                      : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_180 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP)
                      : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))
                          ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                             >> 7U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP)))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_181 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP)
                      : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))
                          ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                             >> 3U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP)))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_182 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE)
                      : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))
                          ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE)
                          : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                              ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                                 >> 7U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE))))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_183 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE)
                      : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))
                          ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE)
                          : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                              ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                                 >> 3U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE))))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_191 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
            ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                    : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                        : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                            : ((0x741U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                : ((0x321U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                    : ((0x340U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                        : ((0x341U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                            : ((0x342U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                                : (
                                                   (0x343U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                                    : 
                                                   ((0x780U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                     : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost)))))))))))
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_200 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret) 
                 | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                     ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                              >> 0x14U)))
                         ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                            >> 3U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1))
                     : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_110 
        = ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
            : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? 
               ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                    : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                        : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                            : ((0x342U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                : ((0x343U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? ((IData)(1U) 
                                       + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                    : ((0x780U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? ((IData)(1U) 
                                           + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                        : ((0x781U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? ((IData)(1U) 
                                               + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                            : ((0x900U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? ((IData)(1U) 
                                                   + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                                : (
                                                   (0x901U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                    : 
                                                   ((IData)(1U) 
                                                    + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_134 
        = ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? ((IData)(1U) 
                                                + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
            : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? 
               ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                    : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                        : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                            : ((0x341U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                : ((0x342U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? ((IData)(1U) 
                                       + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                    : ((0x343U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? ((IData)(1U) 
                                           + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                        : ((0x780U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? ((IData)(1U) 
                                               + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                            : ((0x781U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? ((IData)(1U) 
                                                   + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                                : (
                                                   (0x900U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                    : 
                                                   ((IData)(1U) 
                                                    + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle))))))))))));
    __Vtemp32[0U] = 1U;
    __Vtemp32[1U] = 0U;
    __Vtemp32[2U] = 0U;
    __Vtemp32[3U] = 0U;
    __Vtemp32[4U] = 0U;
    __Vtemp32[5U] = 0U;
    __Vtemp32[6U] = 0U;
    __Vtemp32[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp33, __Vtemp32, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[0U] = (vlTOPp->Tile__DOT__icache__DOT__v[0U] 
                                                  | __Vtemp33[0U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[1U] = (vlTOPp->Tile__DOT__icache__DOT__v[1U] 
                                                  | __Vtemp33[1U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[2U] = (vlTOPp->Tile__DOT__icache__DOT__v[2U] 
                                                  | __Vtemp33[2U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[3U] = (vlTOPp->Tile__DOT__icache__DOT__v[3U] 
                                                  | __Vtemp33[3U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[4U] = (vlTOPp->Tile__DOT__icache__DOT__v[4U] 
                                                  | __Vtemp33[4U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[5U] = (vlTOPp->Tile__DOT__icache__DOT__v[5U] 
                                                  | __Vtemp33[5U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[6U] = (vlTOPp->Tile__DOT__icache__DOT__v[6U] 
                                                  | __Vtemp33[6U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[7U] = (vlTOPp->Tile__DOT__icache__DOT__v[7U] 
                                                  | __Vtemp33[7U]);
    __Vtemp35[0U] = 1U;
    __Vtemp35[1U] = 0U;
    __Vtemp35[2U] = 0U;
    __Vtemp35[3U] = 0U;
    __Vtemp35[4U] = 0U;
    __Vtemp35[5U] = 0U;
    __Vtemp35[6U] = 0U;
    __Vtemp35[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp36, __Vtemp35, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[0U] = (vlTOPp->Tile__DOT__icache__DOT__d[0U] 
                                                  | __Vtemp36[0U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[1U] = (vlTOPp->Tile__DOT__icache__DOT__d[1U] 
                                                  | __Vtemp36[1U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[2U] = (vlTOPp->Tile__DOT__icache__DOT__d[2U] 
                                                  | __Vtemp36[2U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[3U] = (vlTOPp->Tile__DOT__icache__DOT__d[3U] 
                                                  | __Vtemp36[3U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[4U] = (vlTOPp->Tile__DOT__icache__DOT__d[4U] 
                                                  | __Vtemp36[4U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[5U] = (vlTOPp->Tile__DOT__icache__DOT__d[5U] 
                                                  | __Vtemp36[5U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[6U] = (vlTOPp->Tile__DOT__icache__DOT__d[6U] 
                                                  | __Vtemp36[6U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[7U] = (vlTOPp->Tile__DOT__icache__DOT__d[7U] 
                                                  | __Vtemp36[7U]);
    __Vtemp39[0U] = 1U;
    __Vtemp39[1U] = 0U;
    __Vtemp39[2U] = 0U;
    __Vtemp39[3U] = 0U;
    __Vtemp39[4U] = 0U;
    __Vtemp39[5U] = 0U;
    __Vtemp39[6U] = 0U;
    __Vtemp39[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp40, __Vtemp39, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[0U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[0U]) 
                                                  | __Vtemp40[0U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[1U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[1U]) 
                                                  | __Vtemp40[1U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[2U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[2U]) 
                                                  | __Vtemp40[2U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[3U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[3U]) 
                                                  | __Vtemp40[3U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[4U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[4U]) 
                                                  | __Vtemp40[4U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[5U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[5U]) 
                                                  | __Vtemp40[5U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[6U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[6U]) 
                                                  | __Vtemp40[6U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[7U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[7U]) 
                                                  | __Vtemp40[7U]);
    vlTOPp->io_nasti_ar_bits_addr = ((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid)
                                      ? (0xfffffff0U 
                                         & vlTOPp->Tile__DOT__dcache__DOT__addr_reg)
                                      : (0xfffffff0U 
                                         & vlTOPp->Tile__DOT__icache__DOT__addr_reg));
    VL_SHIFTR_WWI(256,256,8, __Vtemp42, vlTOPp->Tile__DOT__icache__DOT__v, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT___hit_T[0U] = __Vtemp42[0U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[1U] = __Vtemp42[1U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[2U] = __Vtemp42[2U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[3U] = __Vtemp42[3U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[4U] = __Vtemp42[4U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[5U] = __Vtemp42[5U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[6U] = __Vtemp42[6U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[7U] = __Vtemp42[7U];
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_inst_kill 
        = ((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 | ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x63U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x1063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0x4063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x5063U != (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x6063U != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_434))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_588 
        = ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 2U : ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 2U : ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x1063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 1U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 1U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 1U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 1U
                                                           : 
                                                          ((0x23U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x1023U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_573))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_686 
        = ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x1063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x23U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x1023U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_671))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_147 
        = ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 1U : ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 1U : ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x1063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 2U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 2U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 2U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 2U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 2U
                                                           : 
                                                          ((0x23U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x1023U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_132))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_341 
        = ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x1063U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x4063U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x5063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x6063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x7063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((3U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x1003U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x2003U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x4003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x5003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x23U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x1023U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x2023U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x13U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_326))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign 
        = ((1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1 
                  >> 0x1fU)) == (1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2 
                                       >> 0x1fU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff 
        = (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1 
           - vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2);
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_240 
        = ((0x5063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x6063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x7063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((3U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    & ((0x1003U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x2003U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0x4003U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x5003U != (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x23U != (0x707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x1023U != (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x2023U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x13U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x2013U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x3013U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x4013U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & ((0x6013U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((0x7013U 
                                                            != 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_223))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
        = (((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
            & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
               & ((0x6fU != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                  & ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                     | ((0x63U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                        & ((0x1063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                           & ((0x4063U != (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                              & ((0x5063U != (0x707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                 & ((0x6063U != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                    & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_189))))))))))
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc);
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 3U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 3U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                            ? 4U : ((0x67U == (0x707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                     ? 1U : ((0x63U 
                                              == (0x707fU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                              ? 5U : 
                                             ((0x1063U 
                                               == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                               ? 5U
                                               : ((0x4063U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                   ? 5U
                                                   : 
                                                  ((0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 5U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 5U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 5U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 1U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 1U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 1U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 1U
                                                           : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_281))))))))))))))));
    vlTOPp->io_nasti_aw_valid = vlTOPp->Tile__DOT__arb_io_nasti_aw_valid;
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_184 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
            ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? 
               ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                    : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_110)))
            : ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_193 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
            ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? 
               ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_134))
            : ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle));
    VL_SHIFTR_WWI(256,256,8, __Vtemp43, vlTOPp->Tile__DOT__icache__DOT__d, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT__is_dirty = (1U 
                                                & (vlTOPp->Tile__DOT__icache__DOT___hit_T[0U] 
                                                   & __Vtemp43[0U]));
    vlTOPp->Tile__DOT__icache__DOT__hit = (vlTOPp->Tile__DOT__icache__DOT___hit_T[0U] 
                                           & (vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_data 
                                              == (0xfffffU 
                                                  & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                     >> 0xcU))));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_147)));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0xbU : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x67U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_341)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign)
                  ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff 
                     >> 0x1fU) : (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1 
                                  >> 0x1fU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign)
                  ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff 
                     >> 0x1fU) : (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2 
                                  >> 0x1fU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_9 
        = ((0xffffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                       >> 0x10U)) | (0xffff0000U & 
                                     (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                                      << 0x10U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_5 
        = (0xfffU & ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                      ? ((0xfe0U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                    >> 0x14U)) | (0x1fU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                     >> 7U)))
                      : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                          ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                             >> 0x14U) : (0xffeU & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                           >> 0x14U)))));
    vlTOPp->Tile__DOT__icache__DOT___wen_T_3 = ((2U 
                                                 == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                & ((IData)(vlTOPp->Tile__DOT__icache__DOT__hit) 
                                                   | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)));
    vlTOPp->Tile__DOT__icache__DOT___wen_T = ((IData)(vlTOPp->Tile__DOT__icache__DOT__hit) 
                                              | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg));
    vlTOPp->Tile__DOT__icache_io_cpu_resp_valid = (
                                                   ((0U 
                                                     == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                    | ((1U 
                                                        == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                       & (IData)(vlTOPp->Tile__DOT__icache__DOT__hit))) 
                                                   | ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg) 
                                                      & (~ (IData)(
                                                                   (0U 
                                                                    != (IData)(vlTOPp->Tile__DOT__icache__DOT__cpu_mask))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond_io_taken 
        = (((((((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
                & (~ (IData)((0U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff)))) 
               | ((6U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
                  & (0U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff))) 
              | ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
                 & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt))) 
             | ((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
                & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt)))) 
            | ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
               & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu))) 
           | ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
              & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_19 
        = ((0xff00ffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_9 
                         >> 8U)) | (0xff00ff00U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_9 
                                                   << 8U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_7 
        = ((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
            ? ((0x1000U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                           >> 0x13U)) | ((0x800U & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                           << 4U)) 
                                         | ((0x7e0U 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                >> 0x14U)) 
                                            | (0x1eU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                  >> 7U)))))
            : ((0x1000U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_5) 
                           << 1U)) | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_5)));
    vlTOPp->Tile__DOT__icache_io_nasti_ar_valid = (
                                                   (0U 
                                                    != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                   & ((1U 
                                                       == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                       ? 
                                                      ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT__hit)) 
                                                       & (~ (IData)(vlTOPp->Tile__DOT__icache__DOT__is_dirty)))
                                                       : 
                                                      ((2U 
                                                        == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                        ? 
                                                       ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T)) 
                                                        & (~ (IData)(vlTOPp->Tile__DOT__icache__DOT__is_dirty)))
                                                        : 
                                                       ((3U 
                                                         != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                        & ((4U 
                                                            != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                           & (5U 
                                                              == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall 
        = (1U & ((~ (IData)(vlTOPp->Tile__DOT__icache_io_cpu_resp_valid)) 
                 | (~ (IData)(vlTOPp->Tile__DOT__dcache_io_cpu_resp_valid))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_29 
        = ((0xf0f0f0fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_19 
                          >> 4U)) | (0xf0f0f0f0U & 
                                     (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_19 
                                      << 4U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen_io_out 
        = ((6U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
            ? (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                        >> 0xfU)) : ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                                      ? ((0xffe00000U 
                                          & (VL_NEGATE_I((IData)(
                                                                 (1U 
                                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm 
                                                                     >> 0x14U)))) 
                                             << 0x15U)) 
                                         | vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm)
                                      : ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                                          ? (0xfffff000U 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                          : ((0xffffe000U 
                                              & (VL_NEGATE_I((IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_7) 
                                                                         >> 0xcU)))) 
                                                 << 0xdU)) 
                                             | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_7)))));
    vlTOPp->io_nasti_ar_valid = ((((IData)(vlTOPp->Tile__DOT__icache_io_nasti_ar_valid) 
                                   | (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid)) 
                                  & (~ (IData)(vlTOPp->Tile__DOT__arb_io_nasti_aw_valid))) 
                                 & (0U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid 
        = ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
           & ((0U != (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_st_type)) 
              | (0U != (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_ld_type))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_239 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
            : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                ? (QData)((IData)((0xfffffffcU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc)))
                : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                    ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                    : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                        ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                            : ((0x344U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                : ((0x304U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                    : ((0x701U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                        : ((0x741U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                            : ((0x321U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                                : (
                                                   (0x340U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                                    : 
                                                   ((0x341U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? 
                                                    ((QData)((IData)(
                                                                     (0x3fffffffU 
                                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                                                                         >> 2U)))) 
                                                     << 2U)
                                                     : (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))))))))))
                        : (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type)
            : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_st_type));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet 
        = (((0x13U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst) 
            & (((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)) 
                | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall)) 
               | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak))) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_39 
        = ((0x33333333U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_29 
                           >> 2U)) | (0xccccccccU & 
                                      (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_29 
                                       << 2U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B 
        = (((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
            & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
               & ((0x6fU != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                  & ((0x67U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                     & ((0x63U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                        & ((0x1063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                           & ((0x4063U != (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                              & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_240))))))))
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen_io_out);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet)
            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4 
        = (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet) 
            & (0xffffffffU == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret))
            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin 
        = ((8U & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A
            : ((0x55555555U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_39 
                               >> 1U)) | (0xaaaaaaaaU 
                                          & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_39 
                                             << 1U))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___sum_T_3 
        = ((1U & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
            ? VL_NEGATE_I(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_135 
        = ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
            : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                    : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                        : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                            : ((0x341U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                : ((0x342U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                    : ((0x343U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                        : ((0x780U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                            : ((0x781U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                : (
                                                   (0x900U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                    : 
                                                   ((0x901U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                     : 
                                                    ((0x902U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3)))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_96 
        = ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
            : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                    : ((0x342U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                        : ((0x343U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                            : ((0x780U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                : ((0x781U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                    : ((0x900U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                        : ((0x901U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                            : ((0x902U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                : (
                                                   (0x980U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                    : 
                                                   ((0x981U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                     : 
                                                    ((0x982U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4)))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5 
        = (VL_ULL(0x1ffffffff) & VL_SHIFTRS_QQI(33,33,5, 
                                                (((QData)((IData)(
                                                                  (1U 
                                                                   & ((IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op) 
                                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin 
                                                                         >> 0x1fU))))) 
                                                  << 0x20U) 
                                                 | (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin))), 
                                                (0x1fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
        = (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
           + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___sum_T_3);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_8 
        = ((0xffffU & (IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5 
                               >> 0x10U))) | (0xffff0000U 
                                              & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5) 
                                                 << 0x10U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T_10 
        = (0x1fU & ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T))
                     ? (0xfU & ((IData)(1U) << (3U 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum)))
                     : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T))
                         ? ((IData)(3U) << (3U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum))
                         : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T))
                             ? 0xfU : 0U))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___daddr_T 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___next_pc_T_9 
        = (VL_ULL(0x1ffffffff) & (((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel)) 
                                   | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond_io_taken))
                                   ? ((QData)((IData)(
                                                      (0x7fffffffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                                          >> 1U)))) 
                                      << 1U) : ((2U 
                                                 == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel))
                                                 ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc
                                                 : 
                                                (VL_ULL(4) 
                                                 + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_18 
        = ((0xff00ffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_8 
                         >> 8U)) | (0xff00ff00U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_8 
                                                   << 8U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__next_pc 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc
            : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                ? (QData)((IData)(((IData)(0x100U) 
                                   + ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                      << 6U)))) : (
                                                   (3U 
                                                    == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel))
                                                    ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT___next_pc_T_9)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_28 
        = ((0xf0f0f0fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_18 
                          >> 4U)) | (0xf0f0f0f0U & 
                                     (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_18 
                                      << 4U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 
        = ((0x33333333U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_28 
                           >> 2U)) | (0xccccccccU & 
                                      (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_28 
                                       << 2U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___out_T_25 
        = (((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)) 
            | (7U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)))
            ? (1U & (((1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                             >> 0x1fU)) == (1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B 
                                                  >> 0x1fU)))
                      ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                         >> 0x1fU) : ((2U & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                       ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B 
                                          >> 0x1fU)
                                       : (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                                          >> 0x1fU))))
            : (((9U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)) 
                | (8U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)))
                ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5)
                : ((6U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                    ? ((0x55555555U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 
                                       >> 1U)) | (0xaaaaaaaaU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 
                                                     << 1U)))
                    : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                        ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)
                        : ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                            ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                               | vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)
                            : ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                                   ^ vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)
                                : ((0xcU == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                    ? ((0xffff0000U 
                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A) 
                                       | (0xffffU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B))
                                    : ((0xaU == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A
                                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B))))))));
}

void VTile::_settle__TOP__3(VTile__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_settle__TOP__3\n"); );
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    // Begin mtask footprint all: 
    WData/*255:0*/ __Vtemp48[8];
    WData/*255:0*/ __Vtemp49[8];
    WData/*255:0*/ __Vtemp51[8];
    WData/*255:0*/ __Vtemp52[8];
    WData/*255:0*/ __Vtemp55[8];
    WData/*255:0*/ __Vtemp56[8];
    WData/*255:0*/ __Vtemp58[8];
    WData/*255:0*/ __Vtemp59[8];
    WData/*255:0*/ __Vtemp60[8];
    WData/*255:0*/ __Vtemp62[8];
    WData/*255:0*/ __Vtemp63[8];
    WData/*255:0*/ __Vtemp66[8];
    WData/*255:0*/ __Vtemp67[8];
    WData/*255:0*/ __Vtemp69[8];
    WData/*255:0*/ __Vtemp76[8];
    WData/*255:0*/ __Vtemp77[8];
    // Body
    vlTOPp->io_host_tohost = vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost;
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___time_T_1 
        = ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___cycle_T_1 
        = ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0 
        = ((IData)(vlTOPp->io_host_fromhost_valid) ? vlTOPp->io_host_fromhost_bits
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1 
        = ((0xffffffffU == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2 
        = ((0xffffffffU == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh);
    vlTOPp->Tile__DOT__arb_io_dcache_aw_ready = ((IData)(vlTOPp->io_nasti_aw_ready) 
                                                 & (0U 
                                                    == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__icache__DOT__rdata[0U] = ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_3
                                                  [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_2
                                                     [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_0_1
                                                        [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__icache__DOT__dataMem_0_0
                                                       [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0])));
    vlTOPp->Tile__DOT__icache__DOT__rdata[1U] = ((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3
                                                  [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_2
                                                     [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_1_1
                                                        [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__icache__DOT__dataMem_1_0
                                                       [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0])));
    vlTOPp->Tile__DOT__icache__DOT__rdata[2U] = (IData)(
                                                        (((QData)((IData)(
                                                                          ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3
                                                                            [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                            << 0x18U) 
                                                                           | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2
                                                                               [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                               << 0x10U) 
                                                                              | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]))))) 
                                                          << 0x20U) 
                                                         | (QData)((IData)(
                                                                           ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3
                                                                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                             << 0x18U) 
                                                                            | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                               | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0])))))));
    vlTOPp->Tile__DOT__icache__DOT__rdata[3U] = (IData)(
                                                        ((((QData)((IData)(
                                                                           ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_3
                                                                             [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                             << 0x18U) 
                                                                            | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_2
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                               | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_3_1
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__icache__DOT__dataMem_3_0
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0]))))) 
                                                           << 0x20U) 
                                                          | (QData)((IData)(
                                                                            ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_3
                                                                              [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                              << 0x18U) 
                                                                             | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_2
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                                | ((vlTOPp->Tile__DOT__icache__DOT__dataMem_2_1
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__icache__DOT__dataMem_2_0
                                                                                [vlTOPp->Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0])))))) 
                                                         >> 0x20U));
    vlTOPp->Tile__DOT__dcache__DOT__rdata[0U] = ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_3
                                                  [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_2
                                                     [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_1
                                                        [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__dcache__DOT__dataMem_0_0
                                                       [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0])));
    vlTOPp->Tile__DOT__dcache__DOT__rdata[1U] = ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_3
                                                  [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                  << 0x18U) 
                                                 | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_2
                                                     [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                     << 0x10U) 
                                                    | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_1
                                                        [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                        << 8U) 
                                                       | vlTOPp->Tile__DOT__dcache__DOT__dataMem_1_0
                                                       [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0])));
    vlTOPp->Tile__DOT__dcache__DOT__rdata[2U] = (IData)(
                                                        (((QData)((IData)(
                                                                          ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3
                                                                            [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                            << 0x18U) 
                                                                           | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2
                                                                               [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                               << 0x10U) 
                                                                              | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]))))) 
                                                          << 0x20U) 
                                                         | (QData)((IData)(
                                                                           ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3
                                                                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                             << 0x18U) 
                                                                            | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                               | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0])))))));
    vlTOPp->Tile__DOT__dcache__DOT__rdata[3U] = (IData)(
                                                        ((((QData)((IData)(
                                                                           ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_3
                                                                             [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                             << 0x18U) 
                                                                            | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_2
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                               | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_1
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__dcache__DOT__dataMem_3_0
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0]))))) 
                                                           << 0x20U) 
                                                          | (QData)((IData)(
                                                                            ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_3
                                                                              [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                              << 0x18U) 
                                                                             | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_2
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 0x10U) 
                                                                                | ((vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_1
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0] 
                                                                                << 8U) 
                                                                                | vlTOPp->Tile__DOT__dcache__DOT__dataMem_2_0
                                                                                [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0])))))) 
                                                         >> 0x20U));
    vlTOPp->Tile__DOT__arb_io_dcache_w_ready = ((IData)(vlTOPp->io_nasti_w_ready) 
                                                & (3U 
                                                   == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_data 
        = vlTOPp->Tile__DOT__icache__DOT__metaMem_tag
        [vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_addr_pipe_0];
    vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data 
        = vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag
        [vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0];
    __Vtemp48[0U] = 1U;
    __Vtemp48[1U] = 0U;
    __Vtemp48[2U] = 0U;
    __Vtemp48[3U] = 0U;
    __Vtemp48[4U] = 0U;
    __Vtemp48[5U] = 0U;
    __Vtemp48[6U] = 0U;
    __Vtemp48[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp49, __Vtemp48, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[0U] = (vlTOPp->Tile__DOT__dcache__DOT__v[0U] 
                                                  | __Vtemp49[0U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[1U] = (vlTOPp->Tile__DOT__dcache__DOT__v[1U] 
                                                  | __Vtemp49[1U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[2U] = (vlTOPp->Tile__DOT__dcache__DOT__v[2U] 
                                                  | __Vtemp49[2U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[3U] = (vlTOPp->Tile__DOT__dcache__DOT__v[3U] 
                                                  | __Vtemp49[3U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[4U] = (vlTOPp->Tile__DOT__dcache__DOT__v[4U] 
                                                  | __Vtemp49[4U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[5U] = (vlTOPp->Tile__DOT__dcache__DOT__v[5U] 
                                                  | __Vtemp49[5U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[6U] = (vlTOPp->Tile__DOT__dcache__DOT__v[6U] 
                                                  | __Vtemp49[6U]);
    vlTOPp->Tile__DOT__dcache__DOT___v_T_1[7U] = (vlTOPp->Tile__DOT__dcache__DOT__v[7U] 
                                                  | __Vtemp49[7U]);
    __Vtemp51[0U] = 1U;
    __Vtemp51[1U] = 0U;
    __Vtemp51[2U] = 0U;
    __Vtemp51[3U] = 0U;
    __Vtemp51[4U] = 0U;
    __Vtemp51[5U] = 0U;
    __Vtemp51[6U] = 0U;
    __Vtemp51[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp52, __Vtemp51, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[0U] = (vlTOPp->Tile__DOT__dcache__DOT__d[0U] 
                                                  | __Vtemp52[0U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[1U] = (vlTOPp->Tile__DOT__dcache__DOT__d[1U] 
                                                  | __Vtemp52[1U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[2U] = (vlTOPp->Tile__DOT__dcache__DOT__d[2U] 
                                                  | __Vtemp52[2U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[3U] = (vlTOPp->Tile__DOT__dcache__DOT__d[3U] 
                                                  | __Vtemp52[3U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[4U] = (vlTOPp->Tile__DOT__dcache__DOT__d[4U] 
                                                  | __Vtemp52[4U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[5U] = (vlTOPp->Tile__DOT__dcache__DOT__d[5U] 
                                                  | __Vtemp52[5U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[6U] = (vlTOPp->Tile__DOT__dcache__DOT__d[6U] 
                                                  | __Vtemp52[6U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_2[7U] = (vlTOPp->Tile__DOT__dcache__DOT__d[7U] 
                                                  | __Vtemp52[7U]);
    __Vtemp55[0U] = 1U;
    __Vtemp55[1U] = 0U;
    __Vtemp55[2U] = 0U;
    __Vtemp55[3U] = 0U;
    __Vtemp55[4U] = 0U;
    __Vtemp55[5U] = 0U;
    __Vtemp55[6U] = 0U;
    __Vtemp55[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp56, __Vtemp55, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[0U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[0U]) 
                                                  | __Vtemp56[0U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[1U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[1U]) 
                                                  | __Vtemp56[1U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[2U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[2U]) 
                                                  | __Vtemp56[2U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[3U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[3U]) 
                                                  | __Vtemp56[3U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[4U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[4U]) 
                                                  | __Vtemp56[4U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[5U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[5U]) 
                                                  | __Vtemp56[5U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[6U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[6U]) 
                                                  | __Vtemp56[6U]);
    vlTOPp->Tile__DOT__dcache__DOT___d_T_4[7U] = ((~ 
                                                   vlTOPp->Tile__DOT__dcache__DOT__d[7U]) 
                                                  | __Vtemp56[7U]);
    vlTOPp->Tile__DOT__arb_io_nasti_r_ready = (((6U 
                                                 == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                & (1U 
                                                   == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))) 
                                               | ((6U 
                                                   == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                  & (2U 
                                                     == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret 
        = (((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
            & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                  >> 0x14U))) & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x1cU));
    vlTOPp->Tile__DOT__dcache_io_nasti_b_ready = ((0U 
                                                   != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                  & ((1U 
                                                      != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                     & ((2U 
                                                         != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                        & ((3U 
                                                            != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                           & (4U 
                                                              == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))))));
    vlTOPp->Tile__DOT__dcache_io_nasti_w_valid = ((0U 
                                                   != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                  & ((1U 
                                                      != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                     & ((2U 
                                                         != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                        & (3U 
                                                           == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)))));
    vlTOPp->Tile__DOT__icache__DOT___T = ((6U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                          & ((IData)(vlTOPp->io_nasti_r_valid) 
                                             & (1U 
                                                == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))));
    vlTOPp->Tile__DOT__dcache__DOT___T = ((6U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                          & ((IData)(vlTOPp->io_nasti_r_valid) 
                                             & (2U 
                                                == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_68 
        = ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
            : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_
                : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh
                    : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                        : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc
                            : ((0x342U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                                : ((0x343U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                    : ((0x344U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP) 
                                            << 7U) 
                                           | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP) 
                                              << 3U))
                                        : ((0x780U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                            : ((0x781U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost
                                                : (
                                                   (0x300U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? 
                                                   (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1) 
                                                     << 4U) 
                                                    | (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1) 
                                                        << 3U) 
                                                       | (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                                           << 1U) 
                                                          | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE))))
                                                    : 0U)))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__csrValid 
        = (((((((((((((((((((((((((((((0xc00U == (0xfffU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                     >> 0x14U))) 
                                      | (0xc01U == 
                                         (0xfffU & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))) 
                                     | (0xc02U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))) 
                                    | (0xc80U == (0xfffU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                     >> 0x14U)))) 
                                   | (0xc81U == (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))) 
                                  | (0xc82U == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))) 
                                 | (0x900U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))) 
                                | (0x901U == (0xfffU 
                                              & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))) 
                               | (0x902U == (0xfffU 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                >> 0x14U)))) 
                              | (0x980U == (0xfffU 
                                            & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))) 
                             | (0x981U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))) 
                            | (0x982U == (0xfffU & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))) 
                           | (0xf00U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))) 
                          | (0xf01U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))) 
                         | (0xf10U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))) 
                        | (0x301U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                >> 0x14U)))) 
                       | (0x302U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))) 
                      | (0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                              >> 0x14U)))) 
                     | (0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))) 
                    | (0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))) 
                   | (0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))) 
                  | (0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                          >> 0x14U)))) 
                 | (0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))) 
                | (0x342U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                        >> 0x14U)))) 
               | (0x343U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                       >> 0x14U)))) 
              | (0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                      >> 0x14U)))) 
             | (0x780U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U)))) | 
            (0x781U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                  >> 0x14U)))) | (0x300U 
                                                  == 
                                                  (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid 
        = ((3U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                  >> 0x1cU)) <= (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc_check) 
           & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
              >> 1U));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid 
        = (1U & ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                  ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
                  : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type))
                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
                      : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ld_type)) 
                         & (0U != (3U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid 
        = (1U & ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type))
                  ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
                  : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type)) 
                     & (0U != (3U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall 
        = (((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
            & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                  >> 0x14U))) & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                    >> 0x1cU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak 
        = (((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
            & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
               >> 0x14U)) & (~ (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                >> 0x1cU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen 
        = ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
           | (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd) 
               >> 1U) & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0xfU)))));
    VL_SHIFTR_WWI(256,256,8, __Vtemp58, vlTOPp->Tile__DOT__dcache__DOT__v, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[0U] = __Vtemp58[0U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[1U] = __Vtemp58[1U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[2U] = __Vtemp58[2U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[3U] = __Vtemp58[3U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[4U] = __Vtemp58[4U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[5U] = __Vtemp58[5U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[6U] = __Vtemp58[6U];
    vlTOPp->Tile__DOT__dcache__DOT___hit_T[7U] = __Vtemp58[7U];
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_622 
        = ((0x2023U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x13U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              | ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 | ((0x3013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x4013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       | ((0x6013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          | ((0x7013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             | ((0x1013U == (0xfe00707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                | ((0x5013U == (0xfe00707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   | ((0x40005013U 
                                       == (0xfe00707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x33U == 
                                          (0xfe00707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         | ((0x40000033U 
                                             == (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            | ((0x1033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               | ((0x2033U 
                                                   == 
                                                   (0xfe00707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  | ((0x3033U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     | ((0x4033U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        | ((0x5033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           | ((0x40005033U 
                                                               == 
                                                               (0xfe00707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              | ((0x6033U 
                                                                  == 
                                                                  (0xfe00707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                 | ((0x7033U 
                                                                     == 
                                                                     (0xfe00707fU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                    | ((0xfU 
                                                                        != 
                                                                        (0xf00fffffU 
                                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                       & ((0x100fU 
                                                                           != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                                          & ((0x1073U 
                                                                              == 
                                                                              (0x707fU 
                                                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                             | ((0x2073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x3073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x5073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x6073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | (0x7073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)))))))))))))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_706 
        = ((0x3033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x4033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x5033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x40005033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    & ((0x6033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x7033U != (0xfe00707fU 
                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0xfU != (0xf00fffffU 
                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x100fU != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                & ((0x1073U != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x2073U != (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x3073U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x5073U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x6073U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x7073U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x73U 
                                                      != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                     & ((0x100073U 
                                                         != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                        & ((0x10000073U 
                                                            != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                           & ((0x10200073U 
                                                               != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                              & (0x2007033U 
                                                                 != 
                                                                 (0xfe00707fU 
                                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_ld_type = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 0U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                            ? 0U : ((0x67U == (0x707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                     ? 0U : ((0x63U 
                                              == (0x707fU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                              ? 0U : 
                                             ((0x1063U 
                                               == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                               ? 0U
                                               : ((0x4063U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                   ? 0U
                                                   : 
                                                  ((0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 3U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 2U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 5U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 4U
                                                           : 0U)))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_414 
        = ((0x1033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x2033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x3033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x4033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    & ((0x5033U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x40005033U != (0xfe00707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0x6033U != (0xfe00707fU 
                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x7033U != (0xfe00707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0xfU != (0xf00fffffU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x100fU == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                      | ((0x1073U == 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         | ((0x2073U 
                                             == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            | ((0x3073U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               | ((0x5073U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  | ((0x6073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     | ((0x7073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        | ((0x73U 
                                                            != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                           & ((0x100073U 
                                                               != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                              & (0x10000073U 
                                                                 == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_558 
        = ((0x4033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x5033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x40005033U == (0xfe00707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x6033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x7033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0xfU 
                                                    == 
                                                    (0xf00fffffU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x100fU 
                                                     == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                     ? 0U
                                                     : 
                                                    ((0x1073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 3U
                                                      : 
                                                     ((0x2073U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 3U
                                                       : 
                                                      ((0x3073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 3U
                                                        : 
                                                       ((0x5073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 3U
                                                         : 
                                                        ((0x6073U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 3U
                                                          : 
                                                         ((0x7073U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 3U
                                                           : 
                                                          ((0x73U 
                                                            == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                            ? 3U
                                                            : 
                                                           ((0x100073U 
                                                             == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                             ? 3U
                                                             : 
                                                            ((0x10000073U 
                                                              == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                              ? 3U
                                                              : 0U))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_656 
        = ((0x4033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x5033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x40005033U == (0xfe00707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x6033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x7033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0xfU 
                                                    == 
                                                    (0xf00fffffU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x100fU 
                                                     == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                     ? 0U
                                                     : 
                                                    ((0x1073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 1U
                                                      : 
                                                     ((0x2073U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 2U
                                                       : 
                                                      ((0x3073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 3U
                                                        : 
                                                       ((0x5073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x6073U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 2U
                                                          : 
                                                         ((0x7073U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 3U
                                                           : 
                                                          ((0x73U 
                                                            == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                            ? 4U
                                                            : 
                                                           ((0x100073U 
                                                             == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                             ? 4U
                                                             : 
                                                            ((0x10000073U 
                                                              == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                              ? 4U
                                                              : 0U))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_489 
        = ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x1063U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x4063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x5063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((3U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x1003U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x2003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x4003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x5003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x23U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 3U
                                                           : 
                                                          ((0x1023U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 2U
                                                            : 
                                                           ((0x2023U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 1U
                                                             : 0U)))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 0U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                            ? 0U : ((0x67U == (0x707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                     ? 0U : ((0x63U 
                                              == (0x707fU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                              ? 3U : 
                                             ((0x1063U 
                                               == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                               ? 6U
                                               : ((0x4063U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                   ? 2U
                                                   : 
                                                  ((0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 5U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 1U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 4U
                                                      : 0U))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_117 
        = ((0x4033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x5033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x40005033U == (0xfe00707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x6033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x7033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0xfU 
                                                    == 
                                                    (0xf00fffffU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x100fU 
                                                     == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                     ? 2U
                                                     : 
                                                    ((0x1073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 2U
                                                      : 
                                                     ((0x2073U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 2U
                                                       : 
                                                      ((0x3073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 2U
                                                        : 
                                                       ((0x5073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 2U
                                                         : 
                                                        ((0x6073U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 2U
                                                          : 
                                                         ((0x7073U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 2U
                                                           : 
                                                          ((0x73U 
                                                            == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                            ? 0U
                                                            : 
                                                           ((0x100073U 
                                                             == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                             ? 0U
                                                             : 
                                                            ((0x10000073U 
                                                              == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                              ? 3U
                                                              : 0U))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm 
        = ((0x100000U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                         >> 0xbU)) | ((0xff000U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                      | ((0x800U & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                           >> 9U)) 
                                         | ((0x7e0U 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                >> 0x14U)) 
                                            | (0x1eU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                  >> 0x14U))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata2 
        = ((0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                            >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
           [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                      >> 0x14U))] : 0U);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2hazard 
        = (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
            & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                               >> 0x14U)))) & ((0x1fU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                   >> 0x14U)) 
                                               == (0x1fU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 7U))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_311 
        = ((0x40005033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 9U : ((0x6033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 3U : ((0x7033U == (0xfe00707fU 
                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 2U : ((0xfU == (0xf00fffffU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0xfU : ((0x100fU 
                                                  == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                  ? 0xfU
                                                  : 
                                                 ((0x1073U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                   ? 0xaU
                                                   : 
                                                  ((0x2073U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0xaU
                                                    : 
                                                   ((0x3073U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0xaU
                                                     : 
                                                    ((0x5073U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0xfU
                                                      : 
                                                     ((0x6073U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0xfU
                                                       : 
                                                      ((0x7073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0xfU
                                                        : 
                                                       ((0x73U 
                                                         == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                         ? 0xfU
                                                         : 
                                                        ((0x100073U 
                                                          == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                          ? 0xfU
                                                          : 
                                                         ((0x10000073U 
                                                           == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                           ? 0xfU
                                                           : 
                                                          ((0x10200073U 
                                                            == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                            ? 0xfU
                                                            : 
                                                           ((0x2007033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0xcU
                                                             : 0xfU))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata1 
        = ((0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                            >> 0xfU))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs
           [(0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                      >> 0xfU))] : 0U);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1hazard 
        = (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_en) 
            & (0U != (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                               >> 0xfU)))) & ((0x1fU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                  >> 0xfU)) 
                                              == (0x1fU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                     >> 7U))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_156 
        = ((0x5073U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x6073U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x7073U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x73U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                    & ((0x100073U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                       & ((0x10000073U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                          & ((0x10200073U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                             & (0x2007033U == (0xfe00707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_266 
        = ((0x2033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x3033U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x4033U == (0xfe00707fU 
                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x5033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x40005033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6033U 
                                                    == 
                                                    (0xfe00707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7033U 
                                                     == 
                                                     (0xfe00707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0xfU 
                                                      == 
                                                      (0xf00fffffU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x100fU 
                                                       == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                                       ? 0U
                                                       : 
                                                      ((0x1073U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x2073U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x3073U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x5073U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 6U
                                                           : 
                                                          ((0x6073U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 6U
                                                            : 
                                                           ((0x7073U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 6U
                                                             : 0U)))))))))))))));
    __Vtemp59[0U] = 1U;
    __Vtemp59[1U] = 0U;
    __Vtemp59[2U] = 0U;
    __Vtemp59[3U] = 0U;
    __Vtemp59[4U] = 0U;
    __Vtemp59[5U] = 0U;
    __Vtemp59[6U] = 0U;
    __Vtemp59[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp60, __Vtemp59, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[0U] = (vlTOPp->Tile__DOT__icache__DOT__v[0U] 
                                                  | __Vtemp60[0U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[1U] = (vlTOPp->Tile__DOT__icache__DOT__v[1U] 
                                                  | __Vtemp60[1U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[2U] = (vlTOPp->Tile__DOT__icache__DOT__v[2U] 
                                                  | __Vtemp60[2U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[3U] = (vlTOPp->Tile__DOT__icache__DOT__v[3U] 
                                                  | __Vtemp60[3U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[4U] = (vlTOPp->Tile__DOT__icache__DOT__v[4U] 
                                                  | __Vtemp60[4U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[5U] = (vlTOPp->Tile__DOT__icache__DOT__v[5U] 
                                                  | __Vtemp60[5U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[6U] = (vlTOPp->Tile__DOT__icache__DOT__v[6U] 
                                                  | __Vtemp60[6U]);
    vlTOPp->Tile__DOT__icache__DOT___v_T_1[7U] = (vlTOPp->Tile__DOT__icache__DOT__v[7U] 
                                                  | __Vtemp60[7U]);
    __Vtemp62[0U] = 1U;
    __Vtemp62[1U] = 0U;
    __Vtemp62[2U] = 0U;
    __Vtemp62[3U] = 0U;
    __Vtemp62[4U] = 0U;
    __Vtemp62[5U] = 0U;
    __Vtemp62[6U] = 0U;
    __Vtemp62[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp63, __Vtemp62, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[0U] = (vlTOPp->Tile__DOT__icache__DOT__d[0U] 
                                                  | __Vtemp63[0U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[1U] = (vlTOPp->Tile__DOT__icache__DOT__d[1U] 
                                                  | __Vtemp63[1U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[2U] = (vlTOPp->Tile__DOT__icache__DOT__d[2U] 
                                                  | __Vtemp63[2U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[3U] = (vlTOPp->Tile__DOT__icache__DOT__d[3U] 
                                                  | __Vtemp63[3U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[4U] = (vlTOPp->Tile__DOT__icache__DOT__d[4U] 
                                                  | __Vtemp63[4U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[5U] = (vlTOPp->Tile__DOT__icache__DOT__d[5U] 
                                                  | __Vtemp63[5U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[6U] = (vlTOPp->Tile__DOT__icache__DOT__d[6U] 
                                                  | __Vtemp63[6U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_2[7U] = (vlTOPp->Tile__DOT__icache__DOT__d[7U] 
                                                  | __Vtemp63[7U]);
    __Vtemp66[0U] = 1U;
    __Vtemp66[1U] = 0U;
    __Vtemp66[2U] = 0U;
    __Vtemp66[3U] = 0U;
    __Vtemp66[4U] = 0U;
    __Vtemp66[5U] = 0U;
    __Vtemp66[6U] = 0U;
    __Vtemp66[7U] = 0U;
    VL_SHIFTL_WWI(256,256,8, __Vtemp67, __Vtemp66, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[0U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[0U]) 
                                                  | __Vtemp67[0U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[1U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[1U]) 
                                                  | __Vtemp67[1U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[2U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[2U]) 
                                                  | __Vtemp67[2U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[3U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[3U]) 
                                                  | __Vtemp67[3U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[4U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[4U]) 
                                                  | __Vtemp67[4U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[5U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[5U]) 
                                                  | __Vtemp67[5U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[6U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[6U]) 
                                                  | __Vtemp67[6U]);
    vlTOPp->Tile__DOT__icache__DOT___d_T_4[7U] = ((~ 
                                                   vlTOPp->Tile__DOT__icache__DOT__d[7U]) 
                                                  | __Vtemp67[7U]);
    VL_SHIFTR_WWI(256,256,8, __Vtemp69, vlTOPp->Tile__DOT__icache__DOT__v, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT___hit_T[0U] = __Vtemp69[0U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[1U] = __Vtemp69[1U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[2U] = __Vtemp69[2U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[3U] = __Vtemp69[3U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[4U] = __Vtemp69[4U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[5U] = __Vtemp69[5U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[6U] = __Vtemp69[6U];
    vlTOPp->Tile__DOT__icache__DOT___hit_T[7U] = __Vtemp69[7U];
    vlTOPp->Tile__DOT__icache__DOT__read[0U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)
                                                 ? (IData)(vlTOPp->Tile__DOT__icache__DOT__refill_buf_0)
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__icache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata[0U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata_buf[0U]));
    vlTOPp->Tile__DOT__icache__DOT__read[1U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)
                                                 ? (IData)(
                                                           (vlTOPp->Tile__DOT__icache__DOT__refill_buf_0 
                                                            >> 0x20U))
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__icache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata[1U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata_buf[1U]));
    vlTOPp->Tile__DOT__icache__DOT__read[2U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)
                                                 ? (IData)(vlTOPp->Tile__DOT__icache__DOT__refill_buf_1)
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__icache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata[2U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata_buf[2U]));
    vlTOPp->Tile__DOT__icache__DOT__read[3U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)
                                                 ? (IData)(
                                                           (vlTOPp->Tile__DOT__icache__DOT__refill_buf_1 
                                                            >> 0x20U))
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__icache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata[3U]
                                                  : 
                                                 vlTOPp->Tile__DOT__icache__DOT__rdata_buf[3U]));
    vlTOPp->Tile__DOT__dcache__DOT__read[0U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg)
                                                 ? (IData)(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0)
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata[0U]
                                                  : 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[0U]));
    vlTOPp->Tile__DOT__dcache__DOT__read[1U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg)
                                                 ? (IData)(
                                                           (vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0 
                                                            >> 0x20U))
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata[1U]
                                                  : 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[1U]));
    vlTOPp->Tile__DOT__dcache__DOT__read[2U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg)
                                                 ? (IData)(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_1)
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata[2U]
                                                  : 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[2U]));
    vlTOPp->Tile__DOT__dcache__DOT__read[3U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg)
                                                 ? (IData)(
                                                           (vlTOPp->Tile__DOT__dcache__DOT__refill_buf_1 
                                                            >> 0x20U))
                                                 : 
                                                ((IData)(vlTOPp->Tile__DOT__dcache__DOT__ren_reg)
                                                  ? 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata[3U]
                                                  : 
                                                 vlTOPp->Tile__DOT__dcache__DOT__rdata_buf[3U]));
    vlTOPp->io_nasti_aw_bits_addr = ((vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data 
                                      << 0xcU) | (0xff0U 
                                                  & vlTOPp->Tile__DOT__dcache__DOT__addr_reg));
    vlTOPp->io_nasti_r_ready = vlTOPp->Tile__DOT__arb_io_nasti_r_ready;
    vlTOPp->Tile__DOT__arb__DOT___GEN_3 = ((((IData)(vlTOPp->Tile__DOT__arb_io_nasti_r_ready) 
                                             & (IData)(vlTOPp->io_nasti_r_valid)) 
                                            & (IData)(vlTOPp->io_nasti_r_bits_last))
                                            ? 0U : (IData)(vlTOPp->Tile__DOT__arb__DOT__state));
    vlTOPp->Tile__DOT__arb_io_nasti_b_ready = ((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_b_ready) 
                                               & (4U 
                                                  == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->io_nasti_w_valid = ((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_valid) 
                                & (3U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__dcache__DOT___T_1 = ((IData)(vlTOPp->Tile__DOT__arb_io_dcache_w_ready) 
                                            & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_valid));
    vlTOPp->Tile__DOT__icache__DOT__read_wrap_out = 
        ((IData)(vlTOPp->Tile__DOT__icache__DOT___T) 
         & (IData)(vlTOPp->Tile__DOT__icache__DOT__read_count));
    vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out = 
        ((IData)(vlTOPp->Tile__DOT__dcache__DOT___T) 
         & (IData)(vlTOPp->Tile__DOT__dcache__DOT__read_count));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_80 
        = ((0x900U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle
            : ((0x901U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_
                : ((0x902U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret
                    : ((0x980U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh
                        : ((0x981U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh
                            : ((0x982U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth
                                : ((0xf00U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? 0x100100U : (
                                                   (0xf01U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? 0U
                                                    : 
                                                   ((0xf10U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? 0U
                                                     : 
                                                    ((0x301U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? 0x100U
                                                      : 
                                                     ((0x302U 
                                                       == 
                                                       (0xfffU 
                                                        & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                           >> 0x14U)))
                                                       ? 0U
                                                       : 
                                                      ((0x304U 
                                                        == 
                                                        (0xfffU 
                                                         & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                            >> 0x14U)))
                                                        ? 
                                                       (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE) 
                                                         << 7U) 
                                                        | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE) 
                                                           << 3U))
                                                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_68))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt 
        = (((((((((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__illegal) 
                  | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid)) 
                 | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid)) 
                | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid)) 
               | ((0U != (3U & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))) 
                  & ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__csrValid)) 
                     | (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid))))) 
              | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen) 
                 & (((3U == (3U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                   >> 0x1eU))) | (0x301U 
                                                  == 
                                                  (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))) 
                    | (0x302U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))))) 
             | ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd)) 
                & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid)))) 
            | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall)) 
           | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak));
    VL_SHIFTR_WWI(256,256,8, __Vtemp76, vlTOPp->Tile__DOT__dcache__DOT__d, 
                  (0xffU & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__dcache__DOT__is_dirty = (1U 
                                                & (vlTOPp->Tile__DOT__dcache__DOT___hit_T[0U] 
                                                   & __Vtemp76[0U]));
    vlTOPp->Tile__DOT__dcache__DOT__hit = (vlTOPp->Tile__DOT__dcache__DOT___hit_T[0U] 
                                           & (vlTOPp->Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data 
                                              == (0xfffffU 
                                                  & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                                     >> 0xcU))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_723 
        = ((0x5003U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x23U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x1023U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x2023U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    & ((0x13U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x2013U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0x3013U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x4013U != (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x6013U != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x7013U != (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x1013U != 
                                          (0xfe00707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x5013U 
                                             != (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x40005013U 
                                                != 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x33U 
                                                   != 
                                                   (0xfe00707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x40000033U 
                                                      != 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & ((0x1033U 
                                                         != 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((0x2033U 
                                                            != 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_706))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_434 
        = ((0x7063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((3U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              | ((0x1003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 | ((0x2003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x4003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       | ((0x5003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          | ((0x23U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x1023U != (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x2023U != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x13U != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x2013U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x3013U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x4013U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x6013U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x7013U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & ((0x1013U 
                                                         != 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((0x5013U 
                                                            != 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & ((0x40005013U 
                                                               != 
                                                               (0xfe00707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              & ((0x33U 
                                                                  != 
                                                                  (0xfe00707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                 & ((0x40000033U 
                                                                     != 
                                                                     (0xfe00707fU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                    & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_414)))))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_573 
        = ((0x2023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x13U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x3013U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6013U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7013U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x1013U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x5013U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x40005013U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x33U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x40000033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x1033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x2033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x3033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_558))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_671 
        = ((0x2023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x13U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x3013U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6013U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7013U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x1013U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x5013U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x40005013U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x33U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x40000033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x1033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x2033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x3033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_656))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_st_type = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 0U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                            ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_489))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_132 
        = ((0x2023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x13U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x3013U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x6013U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x7013U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x1013U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x5013U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x40005013U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x33U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x40000033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x1033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x2033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x3033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_117))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2 = 
        (((0U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel)) 
          & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2hazard))
          ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
          : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata2);
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_326 
        = ((0x2013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 5U : ((0x3013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 7U : ((0x4013U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 4U : ((0x6013U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 3U : ((0x7013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 2U
                                                : (
                                                   (0x1013U 
                                                    == 
                                                    (0xfe00707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 6U
                                                    : 
                                                   ((0x5013U 
                                                     == 
                                                     (0xfe00707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 8U
                                                     : 
                                                    ((0x40005013U 
                                                      == 
                                                      (0xfe00707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 9U
                                                      : 
                                                     ((0x33U 
                                                       == 
                                                       (0xfe00707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x40000033U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 1U
                                                        : 
                                                       ((0x1033U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 6U
                                                         : 
                                                        ((0x2033U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 5U
                                                          : 
                                                         ((0x3033U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 7U
                                                           : 
                                                          ((0x4033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 4U
                                                            : 
                                                           ((0x5033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 8U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_311))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1 = 
        (((0U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__wb_sel)) 
          & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1hazard))
          ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
          : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata1);
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_223 
        = ((0x1013U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x5013U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x40005013U != (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((0x33U == (0xfe00707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x40000033U == (0xfe00707fU 
                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       | ((0x1033U == (0xfe00707fU 
                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          | ((0x2033U == (0xfe00707fU 
                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             | ((0x3033U == (0xfe00707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                | ((0x4033U == (0xfe00707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   | ((0x5033U == (0xfe00707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x40005033U 
                                          == (0xfe00707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         | ((0x6033U 
                                             == (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            | ((0x7033U 
                                                == 
                                                (0xfe00707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               | ((0xfU 
                                                   != 
                                                   (0xf00fffffU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x100fU 
                                                      != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                     & ((0x1073U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((0x2073U 
                                                            != 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & ((0x3073U 
                                                               != 
                                                               (0x707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_156)))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_189 
        = ((0x7063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((3U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              | ((0x1003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 | ((0x2003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x4003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       | ((0x5003U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          | ((0x23U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             | ((0x1023U == (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                | ((0x2023U == (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   | ((0x13U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      | ((0x2013U == 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         | ((0x3013U 
                                             == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            | ((0x4013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               | ((0x6013U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  | ((0x7013U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     | ((0x1013U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        | ((0x5013U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           | ((0x40005013U 
                                                               == 
                                                               (0xfe00707fU 
                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                              | ((0x33U 
                                                                  == 
                                                                  (0xfe00707fU 
                                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                 | ((0x40000033U 
                                                                     == 
                                                                     (0xfe00707fU 
                                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                    | ((0x1033U 
                                                                        == 
                                                                        (0xfe00707fU 
                                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                       | ((0x2033U 
                                                                           == 
                                                                           (0xfe00707fU 
                                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                          | ((0x3033U 
                                                                              == 
                                                                              (0xfe00707fU 
                                                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                             | ((0x4033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x5033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x40005033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x6033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x7033U 
                                                                                == 
                                                                                (0xfe00707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0xfU 
                                                                                != 
                                                                                (0xf00fffffU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                & ((0x100fU 
                                                                                != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst) 
                                                                                & ((0x1073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x2073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | ((0x3073U 
                                                                                == 
                                                                                (0x707fU 
                                                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                                                | (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_156))))))))))))))))))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_281 
        = ((0x23U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 2U : ((0x1023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 2U : ((0x2023U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 2U : ((0x13U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 1U : ((0x2013U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 1U
                                                : (
                                                   (0x3013U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 1U
                                                    : 
                                                   ((0x4013U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 1U
                                                     : 
                                                    ((0x6013U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 1U
                                                      : 
                                                     ((0x7013U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 1U
                                                       : 
                                                      ((0x1013U 
                                                        == 
                                                        (0xfe00707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 1U
                                                        : 
                                                       ((0x5013U 
                                                         == 
                                                         (0xfe00707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x40005013U 
                                                          == 
                                                          (0xfe00707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 1U
                                                          : 
                                                         ((0x33U 
                                                           == 
                                                           (0xfe00707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x40000033U 
                                                            == 
                                                            (0xfe00707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x1033U 
                                                             == 
                                                             (0xfe00707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_266))))))))))))))));
    VL_SHIFTR_WWI(256,256,8, __Vtemp77, vlTOPp->Tile__DOT__icache__DOT__d, 
                  (0xffU & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                            >> 4U)));
    vlTOPp->Tile__DOT__icache__DOT__is_dirty = (1U 
                                                & (vlTOPp->Tile__DOT__icache__DOT___hit_T[0U] 
                                                   & __Vtemp77[0U]));
    vlTOPp->Tile__DOT__icache__DOT__hit = (vlTOPp->Tile__DOT__icache__DOT___hit_T[0U] 
                                           & (vlTOPp->Tile__DOT__icache__DOT__metaMem_tag_rmeta_data 
                                              == (0xfffffU 
                                                  & (vlTOPp->Tile__DOT__icache__DOT__addr_reg 
                                                     >> 0xcU))));
    vlTOPp->io_nasti_w_bits_data = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count)
                                     ? (((QData)((IData)(
                                                         vlTOPp->Tile__DOT__dcache__DOT__read[3U])) 
                                         << 0x20U) 
                                        | (QData)((IData)(
                                                          vlTOPp->Tile__DOT__dcache__DOT__read[2U])))
                                     : (((QData)((IData)(
                                                         vlTOPp->Tile__DOT__dcache__DOT__read[1U])) 
                                         << 0x20U) 
                                        | (QData)((IData)(
                                                          vlTOPp->Tile__DOT__dcache__DOT__read[0U]))));
    vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data 
        = ((3U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                         >> 2U))) ? vlTOPp->Tile__DOT__dcache__DOT__read[3U]
            : ((2U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                             >> 2U))) ? vlTOPp->Tile__DOT__dcache__DOT__read[2U]
                : ((1U == (3U & (vlTOPp->Tile__DOT__dcache__DOT__addr_reg 
                                 >> 2U))) ? vlTOPp->Tile__DOT__dcache__DOT__read[1U]
                    : vlTOPp->Tile__DOT__dcache__DOT__read[0U])));
    vlTOPp->io_nasti_b_ready = vlTOPp->Tile__DOT__arb_io_nasti_b_ready;
    vlTOPp->Tile__DOT__dcache_io_nasti_w_bits_last 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___T_1) 
           & (IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count));
    vlTOPp->Tile__DOT__icache__DOT__is_alloc = ((6U 
                                                 == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                & (IData)(vlTOPp->Tile__DOT__icache__DOT__read_wrap_out));
    vlTOPp->Tile__DOT__dcache__DOT__is_alloc = ((6U 
                                                 == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                & (IData)(vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out 
        = ((0xc00U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle
            : ((0xc01U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_
                : ((0xc02U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret
                    : ((0xc80U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh
                        : ((0xc81U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh
                            : ((0xc82U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth
                                : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_80))))));
    vlTOPp->Tile__DOT__dcache__DOT___wen_T_3 = (((2U 
                                                  == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                 & ((IData)(vlTOPp->Tile__DOT__dcache__DOT__hit) 
                                                    | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg))) 
                                                & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)));
    vlTOPp->Tile__DOT__dcache_io_cpu_resp_valid = (
                                                   ((0U 
                                                     == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                    | ((1U 
                                                        == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                       & (IData)(vlTOPp->Tile__DOT__dcache__DOT__hit))) 
                                                   | ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg) 
                                                      & (~ (IData)(
                                                                   (0U 
                                                                    != (IData)(vlTOPp->Tile__DOT__dcache__DOT__cpu_mask))))));
    vlTOPp->Tile__DOT__dcache__DOT___wen_T = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__hit) 
                                              | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_inst_kill 
        = ((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 | ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    | ((0x63U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x1063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0x4063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x5063U != (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x6063U != (0x707fU 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_434))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_588 
        = ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 2U : ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 2U : ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x1063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 1U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 1U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 1U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 1U
                                                           : 
                                                          ((0x23U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x1023U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_573))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_686 
        = ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x1063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x23U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x1023U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_671))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_147 
        = ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 1U : ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 1U : ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x1063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x4063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 2U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 2U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 2U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 2U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 2U
                                                           : 
                                                          ((0x23U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x1023U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_132))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_341 
        = ((0x63U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
            ? 0U : ((0x1063U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x4063U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x5063U == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : ((0x6063U 
                                                == 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                ? 0U
                                                : (
                                                   (0x7063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 0U
                                                    : 
                                                   ((3U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 0U
                                                     : 
                                                    ((0x1003U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 0U
                                                      : 
                                                     ((0x2003U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 0U
                                                       : 
                                                      ((0x4003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 0U
                                                        : 
                                                       ((0x5003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 0U
                                                         : 
                                                        ((0x23U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 0U
                                                          : 
                                                         ((0x1023U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 0U
                                                           : 
                                                          ((0x2023U 
                                                            == 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                            ? 0U
                                                            : 
                                                           ((0x13U 
                                                             == 
                                                             (0x707fU 
                                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                             ? 0U
                                                             : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_326))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign 
        = ((1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1 
                  >> 0x1fU)) == (1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2 
                                       >> 0x1fU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff 
        = (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1 
           - vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2);
    vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_240 
        = ((0x5063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
           & ((0x6063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
              & ((0x7063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                 & ((3U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                    & ((0x1003U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                       & ((0x2003U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                          & ((0x4003U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                             & ((0x5003U != (0x707fU 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                & ((0x23U != (0x707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                   & ((0x1023U != (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                      & ((0x2023U != 
                                          (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                         & ((0x13U 
                                             != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                            & ((0x2013U 
                                                != 
                                                (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                               & ((0x3013U 
                                                   != 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                  & ((0x4013U 
                                                      != 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                     & ((0x6013U 
                                                         != 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                        & ((0x7013U 
                                                            != 
                                                            (0x707fU 
                                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                                           & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_223))))))))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
        = (((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
            & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
               & ((0x6fU != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                  & ((0x67U == (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                     | ((0x63U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                        & ((0x1063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                           & ((0x4063U != (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                              & ((0x5063U != (0x707fU 
                                              & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                 & ((0x6063U != (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                                    & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_189))))))))))
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc);
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 3U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 3U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                            ? 4U : ((0x67U == (0x707fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                     ? 1U : ((0x63U 
                                              == (0x707fU 
                                                  & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                              ? 5U : 
                                             ((0x1063U 
                                               == (0x707fU 
                                                   & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                               ? 5U
                                               : ((0x4063U 
                                                   == 
                                                   (0x707fU 
                                                    & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                   ? 5U
                                                   : 
                                                  ((0x5063U 
                                                    == 
                                                    (0x707fU 
                                                     & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                    ? 5U
                                                    : 
                                                   ((0x6063U 
                                                     == 
                                                     (0x707fU 
                                                      & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                     ? 5U
                                                     : 
                                                    ((0x7063U 
                                                      == 
                                                      (0x707fU 
                                                       & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                      ? 5U
                                                      : 
                                                     ((3U 
                                                       == 
                                                       (0x707fU 
                                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                       ? 1U
                                                       : 
                                                      ((0x1003U 
                                                        == 
                                                        (0x707fU 
                                                         & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                        ? 1U
                                                        : 
                                                       ((0x2003U 
                                                         == 
                                                         (0x707fU 
                                                          & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                         ? 1U
                                                         : 
                                                        ((0x4003U 
                                                          == 
                                                          (0x707fU 
                                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                          ? 1U
                                                          : 
                                                         ((0x5003U 
                                                           == 
                                                           (0x707fU 
                                                            & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                                           ? 1U
                                                           : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_281))))))))))))))));
    vlTOPp->Tile__DOT__icache__DOT___wen_T_3 = ((2U 
                                                 == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                & ((IData)(vlTOPp->Tile__DOT__icache__DOT__hit) 
                                                   | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg)));
    vlTOPp->Tile__DOT__icache__DOT___wen_T = ((IData)(vlTOPp->Tile__DOT__icache__DOT__hit) 
                                              | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg));
    vlTOPp->Tile__DOT__icache_io_cpu_resp_valid = (
                                                   ((0U 
                                                     == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                    | ((1U 
                                                        == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                       & (IData)(vlTOPp->Tile__DOT__icache__DOT__hit))) 
                                                   | ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg) 
                                                      & (~ (IData)(
                                                                   (0U 
                                                                    != (IData)(vlTOPp->Tile__DOT__icache__DOT__cpu_mask))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__lshift 
        = ((0x1fU >= ((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                                << 3U)) | (8U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                                                 << 3U))))
            ? (vlTOPp->Tile__DOT__dcache_io_cpu_resp_bits_data 
               >> ((0x10U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                             << 3U)) | (8U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu 
                                              << 3U))))
            : 0U);
    vlTOPp->io_nasti_w_bits_last = vlTOPp->Tile__DOT__dcache_io_nasti_w_bits_last;
    vlTOPp->Tile__DOT__arb__DOT___GEN_8 = ((3U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                            ? ((((IData)(vlTOPp->Tile__DOT__arb_io_dcache_w_ready) 
                                                 & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_valid)) 
                                                & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_bits_last))
                                                ? 4U
                                                : (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                            : ((4U 
                                                == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                                ? (
                                                   ((IData)(vlTOPp->Tile__DOT__arb_io_nasti_b_ready) 
                                                    & (IData)(vlTOPp->io_nasti_b_valid))
                                                    ? 0U
                                                    : (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                                : (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__icache__DOT__wdata[0U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                                  ? (IData)(vlTOPp->Tile__DOT__icache__DOT__refill_buf_0)
                                                  : vlTOPp->Tile__DOT__icache__DOT__cpu_data);
    vlTOPp->Tile__DOT__icache__DOT__wdata[1U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                                  ? (IData)(
                                                            (vlTOPp->Tile__DOT__icache__DOT__refill_buf_0 
                                                             >> 0x20U))
                                                  : vlTOPp->Tile__DOT__icache__DOT__cpu_data);
    vlTOPp->Tile__DOT__icache__DOT__wdata[2U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                                  ? (IData)(vlTOPp->io_nasti_r_bits_data)
                                                  : vlTOPp->Tile__DOT__icache__DOT__cpu_data);
    vlTOPp->Tile__DOT__icache__DOT__wdata[3U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                                  ? (IData)(
                                                            (vlTOPp->io_nasti_r_bits_data 
                                                             >> 0x20U))
                                                  : vlTOPp->Tile__DOT__icache__DOT__cpu_data);
    vlTOPp->Tile__DOT__icache__DOT__wmask = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                              ? 0xfffffU
                                              : (0x7ffffU 
                                                 & ((IData)(vlTOPp->Tile__DOT__icache__DOT__cpu_mask) 
                                                    << 
                                                    (0xcU 
                                                     & vlTOPp->Tile__DOT__icache__DOT__addr_reg))));
    vlTOPp->Tile__DOT__icache__DOT__wen = (((2U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                            & ((IData)(vlTOPp->Tile__DOT__icache__DOT__hit) 
                                               | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg))) 
                                           | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc));
    vlTOPp->Tile__DOT__dcache__DOT__wmask = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                              ? 0xfffffU
                                              : (0x7ffffU 
                                                 & ((IData)(vlTOPp->Tile__DOT__dcache__DOT__cpu_mask) 
                                                    << 
                                                    (0xcU 
                                                     & vlTOPp->Tile__DOT__dcache__DOT__addr_reg))));
    vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                                  ? (IData)(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0)
                                                  : vlTOPp->Tile__DOT__dcache__DOT__cpu_data);
    vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                                  ? (IData)(
                                                            (vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0 
                                                             >> 0x20U))
                                                  : vlTOPp->Tile__DOT__dcache__DOT__cpu_data);
    vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                                  ? (IData)(vlTOPp->io_nasti_r_bits_data)
                                                  : vlTOPp->Tile__DOT__dcache__DOT__cpu_data);
    vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                                  ? (IData)(
                                                            (vlTOPp->io_nasti_r_bits_data 
                                                             >> 0x20U))
                                                  : vlTOPp->Tile__DOT__dcache__DOT__cpu_data);
    vlTOPp->Tile__DOT__dcache__DOT__wen = ((((2U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                             & ((IData)(vlTOPp->Tile__DOT__dcache__DOT__hit) 
                                                | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg))) 
                                            & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))) 
                                           | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
        = ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))
            ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out 
               & (~ vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in))
            : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))
                ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_out 
                   | vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in)
                : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_cmd))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in
                    : 0U)));
    vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid = (
                                                   (0U 
                                                    != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                   & ((1U 
                                                       == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                       ? 
                                                      ((~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__hit)) 
                                                       & (~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_dirty)))
                                                       : 
                                                      ((2U 
                                                        == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                        ? 
                                                       ((~ 
                                                         ((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T) 
                                                          | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))) 
                                                        & (~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_dirty)))
                                                        : 
                                                       ((3U 
                                                         != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                        & ((4U 
                                                            != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                           & (5U 
                                                              == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)))))));
    vlTOPp->Tile__DOT__dcache_io_nasti_aw_valid = (
                                                   (0U 
                                                    != (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                   & ((1U 
                                                       == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                       ? 
                                                      ((~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__hit)) 
                                                       & (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_dirty))
                                                       : 
                                                      ((2U 
                                                        == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                       & ((~ 
                                                           ((IData)(vlTOPp->Tile__DOT__dcache__DOT___wen_T) 
                                                            | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))) 
                                                          & (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_dirty)))));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0U : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                   ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_147)));
    vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op = 
        ((0x37U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
          ? 0xbU : ((0x17U == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                     ? 0U : ((0x6fU == (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                              ? 0U : ((0x67U == (0x707fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst))
                                       ? 0U : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_341)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign)
                  ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff 
                     >> 0x1fU) : (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs1 
                                  >> 0x1fU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign)
                  ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff 
                     >> 0x1fU) : (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2 
                                  >> 0x1fU)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_9 
        = ((0xffffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                       >> 0x10U)) | (0xffff0000U & 
                                     (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                                      << 0x10U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_5 
        = (0xfffU & ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                      ? ((0xfe0U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                    >> 0x14U)) | (0x1fU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                     >> 7U)))
                      : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                          ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                             >> 0x14U) : (0xffeU & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                           >> 0x14U)))));
    vlTOPp->Tile__DOT__icache_io_nasti_ar_valid = (
                                                   (0U 
                                                    != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                   & ((1U 
                                                       == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                       ? 
                                                      ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT__hit)) 
                                                       & (~ (IData)(vlTOPp->Tile__DOT__icache__DOT__is_dirty)))
                                                       : 
                                                      ((2U 
                                                        == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                        ? 
                                                       ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT___wen_T)) 
                                                        & (~ (IData)(vlTOPp->Tile__DOT__icache__DOT__is_dirty)))
                                                        : 
                                                       ((3U 
                                                         != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                        & ((4U 
                                                            != (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                           & (5U 
                                                              == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall 
        = (1U & ((~ (IData)(vlTOPp->Tile__DOT__icache_io_cpu_resp_valid)) 
                 | (~ (IData)(vlTOPp->Tile__DOT__dcache_io_cpu_resp_valid))));
    vlTOPp->Tile__DOT__icache__DOT___ren_T_2 = ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT__wen)) 
                                                & ((0U 
                                                    == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                   | (1U 
                                                      == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
    vlTOPp->Tile__DOT__dcache__DOT___ren_T_2 = ((~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__wen)) 
                                                & ((0U 
                                                    == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                   | (1U 
                                                      == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_97 
        = ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
            : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                    : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                        : ((0x342U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                            : ((0x343U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                : ((0x780U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                    : ((0x781U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                        : ((0x900U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                            : ((0x901U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                : (
                                                   (0x902U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                    : 
                                                   ((0x980U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1
                                                     : 
                                                    ((0x981U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1)))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_121 
        = ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
            : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                    : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                        : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                            : ((0x342U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                : ((0x343U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                    : ((0x780U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                        : ((0x781U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                            : ((0x900U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                : (
                                                   (0x901U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                    : 
                                                   ((0x902U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2
                                                     : 
                                                    ((0x980U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2)))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_165 
        = ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
            : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
                : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
                    : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
                        : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp
                            : ((0x321U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_166 
        = ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
            : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                    : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                        : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                            : ((0x321U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch
                                : ((0x340U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch)))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_168 
        = ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
            : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                    : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                        : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                            : ((0x321U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                                : ((0x340U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                                    : ((0x341U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause
                                        : ((0x342U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? (0x8000000fU 
                                               & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata)
                                            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause)))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_169 
        = ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
            : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                    : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                        : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                            : ((0x321U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                : ((0x340U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                    : ((0x341U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                        : ((0x342U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr
                                            : ((0x343U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_176 
        = (3U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                         >> 4U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_178 
        = (3U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                         >> 1U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_179 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                      : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_180 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP)
                      : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))
                          ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                             >> 7U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP)))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_181 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP)
                      : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))
                          ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                             >> 3U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP)))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_182 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE)
                      : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))
                          ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE)
                          : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                              ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                                 >> 7U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE))))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_183 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                  ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                           >> 0x14U)))
                      ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE)
                      : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                               >> 0x14U)))
                          ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE)
                          : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                              ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                                 >> 3U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE))))
                  : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_191 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
            ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                    : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                        : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                            : ((0x741U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                : ((0x321U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                    : ((0x340U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                        : ((0x341U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                            : ((0x342U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                                : (
                                                   (0x343U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost
                                                    : 
                                                   ((0x780U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                     : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost)))))))))))
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_200 
        = (1U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret) 
                 | ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                     ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                              >> 0x14U)))
                         ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                            >> 3U) : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1))
                     : (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_110 
        = ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
            : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? 
               ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                    : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                        : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                            : ((0x342U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                : ((0x343U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? ((IData)(1U) 
                                       + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                    : ((0x780U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? ((IData)(1U) 
                                           + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                        : ((0x781U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? ((IData)(1U) 
                                               + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                            : ((0x900U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? ((IData)(1U) 
                                                   + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                                                : (
                                                   (0x901U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                    : 
                                                   ((IData)(1U) 
                                                    + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_134 
        = ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? ((IData)(1U) 
                                                + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
            : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? 
               ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                    : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                        : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                            : ((0x341U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                : ((0x342U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? ((IData)(1U) 
                                       + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                    : ((0x343U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? ((IData)(1U) 
                                           + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                        : ((0x780U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? ((IData)(1U) 
                                               + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                            : ((0x781U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? ((IData)(1U) 
                                                   + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                                                : (
                                                   (0x900U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                    : 
                                                   ((IData)(1U) 
                                                    + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle))))))))))));
    vlTOPp->io_nasti_ar_bits_addr = ((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid)
                                      ? (0xfffffff0U 
                                         & vlTOPp->Tile__DOT__dcache__DOT__addr_reg)
                                      : (0xfffffff0U 
                                         & vlTOPp->Tile__DOT__icache__DOT__addr_reg));
    vlTOPp->Tile__DOT__arb_io_nasti_aw_valid = ((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_aw_valid) 
                                                & (0U 
                                                   == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond_io_taken 
        = (((((((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
                & (~ (IData)((0U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff)))) 
               | ((6U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
                  & (0U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff))) 
              | ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
                 & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt))) 
             | ((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
                & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt)))) 
            | ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
               & (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu))) 
           | ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_br_type)) 
              & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_19 
        = ((0xff00ffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_9 
                         >> 8U)) | (0xff00ff00U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_9 
                                                   << 8U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_7 
        = ((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
            ? ((0x1000U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                           >> 0x13U)) | ((0x800U & 
                                          (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                           << 4U)) 
                                         | ((0x7e0U 
                                             & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                >> 0x14U)) 
                                            | (0x1eU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                                                  >> 7U)))))
            : ((0x1000U & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_5) 
                           << 1U)) | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_5)));
    vlTOPp->Tile__DOT__core__DOT__dpath_io_dcache_req_valid 
        = ((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)) 
           & ((0U != (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_st_type)) 
              | (0U != (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_ld_type))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___GEN_31 
        = ((IData)(vlTOPp->reset) ? VL_ULL(0) : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                                                  ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc))
                                                  : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_239 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
            : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                ? (QData)((IData)((0xfffffffcU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc)))
                : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret)
                    ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                    : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
                        ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                            : ((0x344U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                : ((0x304U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                    : ((0x701U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                        : ((0x741U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                            : ((0x321U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                                : (
                                                   (0x340U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                                    : 
                                                   ((0x341U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? 
                                                    ((QData)((IData)(
                                                                     (0x3fffffffU 
                                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata 
                                                                         >> 2U)))) 
                                                     << 2U)
                                                     : (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))))))))))
                        : (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__st_type)
            : (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_st_type));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet 
        = (((0x13U != vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst) 
            & (((~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)) 
                | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall)) 
               | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak))) 
           & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_184 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
            ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? 
               ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                    : ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_)
                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_110)))
            : ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_193 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen)
            ? ((0x300U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? 
               ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                : ((0x344U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle)
                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_134))
            : ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle));
    vlTOPp->io_nasti_aw_valid = vlTOPp->Tile__DOT__arb_io_nasti_aw_valid;
    vlTOPp->Tile__DOT__arb_io_dcache_ar_ready = (((IData)(vlTOPp->io_nasti_ar_ready) 
                                                  & (~ (IData)(vlTOPp->Tile__DOT__arb_io_nasti_aw_valid))) 
                                                 & (0U 
                                                    == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->io_nasti_ar_valid = ((((IData)(vlTOPp->Tile__DOT__icache_io_nasti_ar_valid) 
                                   | (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid)) 
                                  & (~ (IData)(vlTOPp->Tile__DOT__arb_io_nasti_aw_valid))) 
                                 & (0U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_29 
        = ((0xf0f0f0fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_19 
                          >> 4U)) | (0xf0f0f0f0U & 
                                     (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_19 
                                      << 4U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen_io_out 
        = ((6U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
            ? (0x1fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst 
                        >> 0xfU)) : ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                                      ? ((0xffe00000U 
                                          & (VL_NEGATE_I((IData)(
                                                                 (1U 
                                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm 
                                                                     >> 0x14U)))) 
                                             << 0x15U)) 
                                         | vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm)
                                      : ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_imm_sel))
                                          ? (0xfffff000U 
                                             & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)
                                          : ((0xffffe000U 
                                              & (VL_NEGATE_I((IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_7) 
                                                                         >> 0xcU)))) 
                                                 << 0xdU)) 
                                             | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_7)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet)
            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4 
        = (((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet) 
            & (0xffffffffU == vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret))
            ? ((IData)(1U) + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth);
    vlTOPp->Tile__DOT__dcache__DOT___GEN_107 = (((IData)(vlTOPp->Tile__DOT__arb_io_dcache_ar_ready) 
                                                 & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid))
                                                 ? 6U
                                                 : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state));
    vlTOPp->Tile__DOT__arb_io_icache_ar_ready = ((IData)(vlTOPp->Tile__DOT__arb_io_dcache_ar_ready) 
                                                 & (~ (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_39 
        = ((0x33333333U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_29 
                           >> 2U)) | (0xccccccccU & 
                                      (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_29 
                                       << 2U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B 
        = (((0x37U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
            & ((0x17U != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
               & ((0x6fU != (0x7fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                  & ((0x67U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                     & ((0x63U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                        & ((0x1063U != (0x707fU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                           & ((0x4063U != (0x707fU 
                                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst)) 
                              & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_240))))))))
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__rs2
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__immGen_io_out);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_135 
        = ((0x304U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
            : ((0x701U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                : ((0x741U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                    : ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                        : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                            : ((0x341U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                : ((0x342U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                    : ((0x343U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                        : ((0x780U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                            : ((0x781U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                : (
                                                   (0x900U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                    : 
                                                   ((0x901U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3
                                                     : 
                                                    ((0x902U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3)))))))))))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_96 
        = ((0x321U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                 >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
            : ((0x340U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                     >> 0x14U))) ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                : ((0x341U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                         >> 0x14U)))
                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                    : ((0x342U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                             >> 0x14U)))
                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                        : ((0x343U == (0xfffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                 >> 0x14U)))
                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                            : ((0x780U == (0xfffU & 
                                           (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                            >> 0x14U)))
                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                : ((0x781U == (0xfffU 
                                               & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                  >> 0x14U)))
                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                    : ((0x900U == (0xfffU 
                                                   & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                      >> 0x14U)))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                        : ((0x901U 
                                            == (0xfffU 
                                                & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                   >> 0x14U)))
                                            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                            : ((0x902U 
                                                == 
                                                (0xfffU 
                                                 & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                    >> 0x14U)))
                                                ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                : (
                                                   (0x980U 
                                                    == 
                                                    (0xfffU 
                                                     & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                        >> 0x14U)))
                                                    ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                    : 
                                                   ((0x981U 
                                                     == 
                                                     (0xfffU 
                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                         >> 0x14U)))
                                                     ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4
                                                     : 
                                                    ((0x982U 
                                                      == 
                                                      (0xfffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst 
                                                          >> 0x14U)))
                                                      ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata
                                                      : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4)))))))))))));
    vlTOPp->Tile__DOT__dcache__DOT___GEN_108 = (((IData)(vlTOPp->Tile__DOT__arb_io_dcache_aw_ready) 
                                                 & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_aw_valid))
                                                 ? 3U
                                                 : (IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_107));
    vlTOPp->Tile__DOT__dcache__DOT___GEN_128 = ((3U 
                                                 == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                 ? 
                                                (((IData)(vlTOPp->Tile__DOT__dcache__DOT___T_1) 
                                                  & (IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count))
                                                  ? 4U
                                                  : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                 : 
                                                ((4U 
                                                  == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                  ? 
                                                 (((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_b_ready) 
                                                   & ((IData)(vlTOPp->io_nasti_b_valid) 
                                                      & (4U 
                                                         == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))))
                                                   ? 5U
                                                   : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                  : 
                                                 ((5U 
                                                   == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                   ? (IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_107)
                                                   : 
                                                  ((6U 
                                                    == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                    ? 
                                                   ((IData)(vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out)
                                                     ? 
                                                    ((0U 
                                                      != (IData)(vlTOPp->Tile__DOT__dcache__DOT__cpu_mask))
                                                      ? 2U
                                                      : 0U)
                                                     : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                    : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)))));
    vlTOPp->Tile__DOT__arb__DOT___GEN_0 = (((IData)(vlTOPp->Tile__DOT__arb_io_icache_ar_ready) 
                                            & (IData)(vlTOPp->Tile__DOT__icache_io_nasti_ar_valid))
                                            ? 1U : (IData)(vlTOPp->Tile__DOT__arb__DOT__state));
    vlTOPp->Tile__DOT__icache__DOT___GEN_107 = (((IData)(vlTOPp->Tile__DOT__arb_io_icache_ar_ready) 
                                                 & (IData)(vlTOPp->Tile__DOT__icache_io_nasti_ar_valid))
                                                 ? 6U
                                                 : (IData)(vlTOPp->Tile__DOT__icache__DOT__state));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin 
        = ((8U & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A
            : ((0x55555555U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_39 
                               >> 1U)) | (0xaaaaaaaaU 
                                          & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_39 
                                             << 1U))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___sum_T_3 
        = ((1U & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
            ? VL_NEGATE_I(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B);
    vlTOPp->Tile__DOT__icache__DOT___GEN_128 = ((3U 
                                                 == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                 ? (IData)(vlTOPp->Tile__DOT__icache__DOT__state)
                                                 : 
                                                ((4U 
                                                  == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                  ? (IData)(vlTOPp->Tile__DOT__icache__DOT__state)
                                                  : 
                                                 ((5U 
                                                   == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                   ? (IData)(vlTOPp->Tile__DOT__icache__DOT___GEN_107)
                                                   : 
                                                  ((6U 
                                                    == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                    ? 
                                                   ((IData)(vlTOPp->Tile__DOT__icache__DOT__read_wrap_out)
                                                     ? 
                                                    ((0U 
                                                      != (IData)(vlTOPp->Tile__DOT__icache__DOT__cpu_mask))
                                                      ? 2U
                                                      : 0U)
                                                     : (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                    : (IData)(vlTOPp->Tile__DOT__icache__DOT__state)))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5 
        = (VL_ULL(0x1ffffffff) & VL_SHIFTRS_QQI(33,33,5, 
                                                (((QData)((IData)(
                                                                  (1U 
                                                                   & ((IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op) 
                                                                      & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin 
                                                                         >> 0x1fU))))) 
                                                  << 0x20U) 
                                                 | (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin))), 
                                                (0x1fU 
                                                 & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
        = (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
           + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___sum_T_3);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_8 
        = ((0xffffU & (IData)((vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5 
                               >> 0x10U))) | (0xffff0000U 
                                              & ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5) 
                                                 << 0x10U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T_10 
        = (0x1fU & ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T))
                     ? (0xfU & ((IData)(1U) << (3U 
                                                & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum)))
                     : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T))
                         ? ((IData)(3U) << (3U & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum))
                         : ((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T))
                             ? 0xfU : 0U))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___daddr_T 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum);
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___next_pc_T_9 
        = (VL_ULL(0x1ffffffff) & (((1U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel)) 
                                   | (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__brCond_io_taken))
                                   ? ((QData)((IData)(
                                                      (0x7fffffffU 
                                                       & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                                                          >> 1U)))) 
                                      << 1U) : ((2U 
                                                 == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel))
                                                 ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc
                                                 : 
                                                (VL_ULL(4) 
                                                 + vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc))));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_18 
        = ((0xff00ffU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_8 
                         >> 8U)) | (0xff00ff00U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_8 
                                                   << 8U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__next_pc 
        = ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
            ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc
            : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt)
                ? (QData)((IData)(((IData)(0x100U) 
                                   + ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV) 
                                      << 6U)))) : (
                                                   (3U 
                                                    == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_pc_sel))
                                                    ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc))
                                                    : vlTOPp->Tile__DOT__core__DOT__dpath__DOT___next_pc_T_9)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_28 
        = ((0xf0f0f0fU & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_18 
                          >> 4U)) | (0xf0f0f0f0U & 
                                     (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_18 
                                      << 4U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 
        = ((0x33333333U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_28 
                           >> 2U)) | (0xccccccccU & 
                                      (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_28 
                                       << 2U)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___out_T_25 
        = (((5U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)) 
            | (7U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)))
            ? (1U & (((1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                             >> 0x1fU)) == (1U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B 
                                                  >> 0x1fU)))
                      ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_sum 
                         >> 0x1fU) : ((2U & (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                       ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B 
                                          >> 0x1fU)
                                       : (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                                          >> 0x1fU))))
            : (((9U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)) 
                | (8U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op)))
                ? (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5)
                : ((6U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                    ? ((0x55555555U & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 
                                       >> 1U)) | (0xaaaaaaaaU 
                                                  & (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 
                                                     << 1U)))
                    : ((2U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                        ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                           & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)
                        : ((3U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                            ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                               | vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)
                            : ((4U == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                ? (vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A 
                                   ^ vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B)
                                : ((0xcU == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                    ? ((0xffff0000U 
                                        & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A) 
                                       | (0xffffU & vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B))
                                    : ((0xaU == (IData)(vlTOPp->Tile__DOT__core__DOT__ctrl_io_alu_op))
                                        ? vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_A
                                        : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__alu_io_B))))))));
}

VL_INLINE_OPT void VTile::_combo__TOP__4(VTile__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_combo__TOP__4\n"); );
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->Tile__DOT__arb_io_dcache_aw_ready = ((IData)(vlTOPp->io_nasti_aw_ready) 
                                                 & (0U 
                                                    == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__arb_io_dcache_w_ready = ((IData)(vlTOPp->io_nasti_w_ready) 
                                                & (3U 
                                                   == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0 
        = ((IData)(vlTOPp->io_host_fromhost_valid) ? vlTOPp->io_host_fromhost_bits
            : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost);
    vlTOPp->Tile__DOT__icache__DOT___T = ((6U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                          & ((IData)(vlTOPp->io_nasti_r_valid) 
                                             & (1U 
                                                == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))));
    vlTOPp->Tile__DOT__dcache__DOT___T = ((6U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                          & ((IData)(vlTOPp->io_nasti_r_valid) 
                                             & (2U 
                                                == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))));
    vlTOPp->Tile__DOT__arb__DOT___GEN_3 = ((((IData)(vlTOPp->Tile__DOT__arb_io_nasti_r_ready) 
                                             & (IData)(vlTOPp->io_nasti_r_valid)) 
                                            & (IData)(vlTOPp->io_nasti_r_bits_last))
                                            ? 0U : (IData)(vlTOPp->Tile__DOT__arb__DOT__state));
    vlTOPp->Tile__DOT__arb_io_dcache_ar_ready = (((IData)(vlTOPp->io_nasti_ar_ready) 
                                                  & (~ (IData)(vlTOPp->Tile__DOT__arb_io_nasti_aw_valid))) 
                                                 & (0U 
                                                    == (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__core__DOT__dpath__DOT___GEN_31 
        = ((IData)(vlTOPp->reset) ? VL_ULL(0) : ((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_stall)
                                                  ? (QData)((IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc))
                                                  : vlTOPp->Tile__DOT__core__DOT__dpath__DOT__pc));
    vlTOPp->Tile__DOT__dcache__DOT___T_1 = ((IData)(vlTOPp->Tile__DOT__arb_io_dcache_w_ready) 
                                            & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_valid));
    vlTOPp->Tile__DOT__icache__DOT__read_wrap_out = 
        ((IData)(vlTOPp->Tile__DOT__icache__DOT___T) 
         & (IData)(vlTOPp->Tile__DOT__icache__DOT__read_count));
    vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out = 
        ((IData)(vlTOPp->Tile__DOT__dcache__DOT___T) 
         & (IData)(vlTOPp->Tile__DOT__dcache__DOT__read_count));
    vlTOPp->Tile__DOT__dcache__DOT___GEN_107 = (((IData)(vlTOPp->Tile__DOT__arb_io_dcache_ar_ready) 
                                                 & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid))
                                                 ? 6U
                                                 : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state));
    vlTOPp->Tile__DOT__arb_io_icache_ar_ready = ((IData)(vlTOPp->Tile__DOT__arb_io_dcache_ar_ready) 
                                                 & (~ (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_ar_valid)));
    vlTOPp->Tile__DOT__dcache_io_nasti_w_bits_last 
        = ((IData)(vlTOPp->Tile__DOT__dcache__DOT___T_1) 
           & (IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count));
    vlTOPp->Tile__DOT__icache__DOT__is_alloc = ((6U 
                                                 == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                & (IData)(vlTOPp->Tile__DOT__icache__DOT__read_wrap_out));
    vlTOPp->Tile__DOT__dcache__DOT__is_alloc = ((6U 
                                                 == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                & (IData)(vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out));
    vlTOPp->Tile__DOT__dcache__DOT___GEN_108 = (((IData)(vlTOPp->Tile__DOT__arb_io_dcache_aw_ready) 
                                                 & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_aw_valid))
                                                 ? 3U
                                                 : (IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_107));
    vlTOPp->Tile__DOT__dcache__DOT___GEN_128 = ((3U 
                                                 == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                 ? 
                                                (((IData)(vlTOPp->Tile__DOT__dcache__DOT___T_1) 
                                                  & (IData)(vlTOPp->Tile__DOT__dcache__DOT__write_count))
                                                  ? 4U
                                                  : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                 : 
                                                ((4U 
                                                  == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                  ? 
                                                 (((IData)(vlTOPp->Tile__DOT__dcache_io_nasti_b_ready) 
                                                   & ((IData)(vlTOPp->io_nasti_b_valid) 
                                                      & (4U 
                                                         == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))))
                                                   ? 5U
                                                   : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                  : 
                                                 ((5U 
                                                   == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                   ? (IData)(vlTOPp->Tile__DOT__dcache__DOT___GEN_107)
                                                   : 
                                                  ((6U 
                                                    == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                    ? 
                                                   ((IData)(vlTOPp->Tile__DOT__dcache__DOT__read_wrap_out)
                                                     ? 
                                                    ((0U 
                                                      != (IData)(vlTOPp->Tile__DOT__dcache__DOT__cpu_mask))
                                                      ? 2U
                                                      : 0U)
                                                     : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))
                                                    : (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)))));
    vlTOPp->Tile__DOT__arb__DOT___GEN_0 = (((IData)(vlTOPp->Tile__DOT__arb_io_icache_ar_ready) 
                                            & (IData)(vlTOPp->Tile__DOT__icache_io_nasti_ar_valid))
                                            ? 1U : (IData)(vlTOPp->Tile__DOT__arb__DOT__state));
    vlTOPp->Tile__DOT__icache__DOT___GEN_107 = (((IData)(vlTOPp->Tile__DOT__arb_io_icache_ar_ready) 
                                                 & (IData)(vlTOPp->Tile__DOT__icache_io_nasti_ar_valid))
                                                 ? 6U
                                                 : (IData)(vlTOPp->Tile__DOT__icache__DOT__state));
    vlTOPp->io_nasti_w_bits_last = vlTOPp->Tile__DOT__dcache_io_nasti_w_bits_last;
    vlTOPp->Tile__DOT__arb__DOT___GEN_8 = ((3U == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                            ? ((((IData)(vlTOPp->Tile__DOT__arb_io_dcache_w_ready) 
                                                 & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_valid)) 
                                                & (IData)(vlTOPp->Tile__DOT__dcache_io_nasti_w_bits_last))
                                                ? 4U
                                                : (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                            : ((4U 
                                                == (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                                ? (
                                                   ((IData)(vlTOPp->Tile__DOT__arb_io_nasti_b_ready) 
                                                    & (IData)(vlTOPp->io_nasti_b_valid))
                                                    ? 0U
                                                    : (IData)(vlTOPp->Tile__DOT__arb__DOT__state))
                                                : (IData)(vlTOPp->Tile__DOT__arb__DOT__state)));
    vlTOPp->Tile__DOT__icache__DOT__wdata[0U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                                  ? (IData)(vlTOPp->Tile__DOT__icache__DOT__refill_buf_0)
                                                  : vlTOPp->Tile__DOT__icache__DOT__cpu_data);
    vlTOPp->Tile__DOT__icache__DOT__wdata[1U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                                  ? (IData)(
                                                            (vlTOPp->Tile__DOT__icache__DOT__refill_buf_0 
                                                             >> 0x20U))
                                                  : vlTOPp->Tile__DOT__icache__DOT__cpu_data);
    vlTOPp->Tile__DOT__icache__DOT__wdata[2U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                                  ? (IData)(vlTOPp->io_nasti_r_bits_data)
                                                  : vlTOPp->Tile__DOT__icache__DOT__cpu_data);
    vlTOPp->Tile__DOT__icache__DOT__wdata[3U] = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                                  ? (IData)(
                                                            (vlTOPp->io_nasti_r_bits_data 
                                                             >> 0x20U))
                                                  : vlTOPp->Tile__DOT__icache__DOT__cpu_data);
    vlTOPp->Tile__DOT__icache__DOT__wmask = ((IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc)
                                              ? 0xfffffU
                                              : (0x7ffffU 
                                                 & ((IData)(vlTOPp->Tile__DOT__icache__DOT__cpu_mask) 
                                                    << 
                                                    (0xcU 
                                                     & vlTOPp->Tile__DOT__icache__DOT__addr_reg))));
    vlTOPp->Tile__DOT__icache__DOT__wen = (((2U == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                            & ((IData)(vlTOPp->Tile__DOT__icache__DOT__hit) 
                                               | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc_reg))) 
                                           | (IData)(vlTOPp->Tile__DOT__icache__DOT__is_alloc));
    vlTOPp->Tile__DOT__dcache__DOT__wmask = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                              ? 0xfffffU
                                              : (0x7ffffU 
                                                 & ((IData)(vlTOPp->Tile__DOT__dcache__DOT__cpu_mask) 
                                                    << 
                                                    (0xcU 
                                                     & vlTOPp->Tile__DOT__dcache__DOT__addr_reg))));
    vlTOPp->Tile__DOT__dcache__DOT__wdata[0U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                                  ? (IData)(vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0)
                                                  : vlTOPp->Tile__DOT__dcache__DOT__cpu_data);
    vlTOPp->Tile__DOT__dcache__DOT__wdata[1U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                                  ? (IData)(
                                                            (vlTOPp->Tile__DOT__dcache__DOT__refill_buf_0 
                                                             >> 0x20U))
                                                  : vlTOPp->Tile__DOT__dcache__DOT__cpu_data);
    vlTOPp->Tile__DOT__dcache__DOT__wdata[2U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                                  ? (IData)(vlTOPp->io_nasti_r_bits_data)
                                                  : vlTOPp->Tile__DOT__dcache__DOT__cpu_data);
    vlTOPp->Tile__DOT__dcache__DOT__wdata[3U] = ((IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc)
                                                  ? (IData)(
                                                            (vlTOPp->io_nasti_r_bits_data 
                                                             >> 0x20U))
                                                  : vlTOPp->Tile__DOT__dcache__DOT__cpu_data);
    vlTOPp->Tile__DOT__dcache__DOT__wen = ((((2U == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                             & ((IData)(vlTOPp->Tile__DOT__dcache__DOT__hit) 
                                                | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc_reg))) 
                                            & (~ (IData)(vlTOPp->Tile__DOT__core__DOT__dpath__DOT__csr_io_expt))) 
                                           | (IData)(vlTOPp->Tile__DOT__dcache__DOT__is_alloc));
    vlTOPp->Tile__DOT__icache__DOT___GEN_128 = ((3U 
                                                 == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                 ? (IData)(vlTOPp->Tile__DOT__icache__DOT__state)
                                                 : 
                                                ((4U 
                                                  == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                  ? (IData)(vlTOPp->Tile__DOT__icache__DOT__state)
                                                  : 
                                                 ((5U 
                                                   == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                   ? (IData)(vlTOPp->Tile__DOT__icache__DOT___GEN_107)
                                                   : 
                                                  ((6U 
                                                    == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                    ? 
                                                   ((IData)(vlTOPp->Tile__DOT__icache__DOT__read_wrap_out)
                                                     ? 
                                                    ((0U 
                                                      != (IData)(vlTOPp->Tile__DOT__icache__DOT__cpu_mask))
                                                      ? 2U
                                                      : 0U)
                                                     : (IData)(vlTOPp->Tile__DOT__icache__DOT__state))
                                                    : (IData)(vlTOPp->Tile__DOT__icache__DOT__state)))));
    vlTOPp->Tile__DOT__icache__DOT___ren_T_2 = ((~ (IData)(vlTOPp->Tile__DOT__icache__DOT__wen)) 
                                                & ((0U 
                                                    == (IData)(vlTOPp->Tile__DOT__icache__DOT__state)) 
                                                   | (1U 
                                                      == (IData)(vlTOPp->Tile__DOT__icache__DOT__state))));
    vlTOPp->Tile__DOT__dcache__DOT___ren_T_2 = ((~ (IData)(vlTOPp->Tile__DOT__dcache__DOT__wen)) 
                                                & ((0U 
                                                    == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state)) 
                                                   | (1U 
                                                      == (IData)(vlTOPp->Tile__DOT__dcache__DOT__state))));
}

void VTile::_eval(VTile__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_eval\n"); );
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (((IData)(vlTOPp->clock) & (~ (IData)(vlTOPp->__Vclklast__TOP__clock)))) {
        vlTOPp->_sequent__TOP__2(vlSymsp);
        vlTOPp->__Vm_traceActivity = (2U | vlTOPp->__Vm_traceActivity);
    }
    vlTOPp->_combo__TOP__4(vlSymsp);
    vlTOPp->__Vm_traceActivity = (4U | vlTOPp->__Vm_traceActivity);
    // Final
    vlTOPp->__Vclklast__TOP__clock = vlTOPp->clock;
}

void VTile::_eval_initial(VTile__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_eval_initial\n"); );
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_initial__TOP__1(vlSymsp);
    vlTOPp->__Vclklast__TOP__clock = vlTOPp->clock;
}

void VTile::final() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::final\n"); );
    // Variables
    VTile__Syms* __restrict vlSymsp = this->__VlSymsp;
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
}

void VTile::_eval_settle(VTile__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_eval_settle\n"); );
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_settle__TOP__3(vlSymsp);
    vlTOPp->__Vm_traceActivity = (1U | vlTOPp->__Vm_traceActivity);
}

VL_INLINE_OPT QData VTile::_change_request(VTile__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_change_request\n"); );
    VTile* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    // Change detection
    QData __req = false;  // Logically a bool
    return __req;
}

#ifdef VL_DEBUG
void VTile::_eval_debug_assertions() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((clock & 0xfeU))) {
        Verilated::overWidthError("clock");}
    if (VL_UNLIKELY((reset & 0xfeU))) {
        Verilated::overWidthError("reset");}
    if (VL_UNLIKELY((io_host_fromhost_valid & 0xfeU))) {
        Verilated::overWidthError("io_host_fromhost_valid");}
    if (VL_UNLIKELY((io_nasti_aw_ready & 0xfeU))) {
        Verilated::overWidthError("io_nasti_aw_ready");}
    if (VL_UNLIKELY((io_nasti_w_ready & 0xfeU))) {
        Verilated::overWidthError("io_nasti_w_ready");}
    if (VL_UNLIKELY((io_nasti_b_valid & 0xfeU))) {
        Verilated::overWidthError("io_nasti_b_valid");}
    if (VL_UNLIKELY((io_nasti_b_bits_id & 0xe0U))) {
        Verilated::overWidthError("io_nasti_b_bits_id");}
    if (VL_UNLIKELY((io_nasti_b_bits_resp & 0xfcU))) {
        Verilated::overWidthError("io_nasti_b_bits_resp");}
    if (VL_UNLIKELY((io_nasti_ar_ready & 0xfeU))) {
        Verilated::overWidthError("io_nasti_ar_ready");}
    if (VL_UNLIKELY((io_nasti_r_valid & 0xfeU))) {
        Verilated::overWidthError("io_nasti_r_valid");}
    if (VL_UNLIKELY((io_nasti_r_bits_id & 0xe0U))) {
        Verilated::overWidthError("io_nasti_r_bits_id");}
    if (VL_UNLIKELY((io_nasti_r_bits_resp & 0xfcU))) {
        Verilated::overWidthError("io_nasti_r_bits_resp");}
    if (VL_UNLIKELY((io_nasti_r_bits_last & 0xfeU))) {
        Verilated::overWidthError("io_nasti_r_bits_last");}
}
#endif  // VL_DEBUG

void VTile::_ctor_var_reset() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTile::_ctor_var_reset\n"); );
    // Body
    clock = VL_RAND_RESET_I(1);
    reset = VL_RAND_RESET_I(1);
    io_host_fromhost_valid = VL_RAND_RESET_I(1);
    io_host_fromhost_bits = VL_RAND_RESET_I(32);
    io_host_tohost = VL_RAND_RESET_I(32);
    io_nasti_aw_ready = VL_RAND_RESET_I(1);
    io_nasti_aw_valid = VL_RAND_RESET_I(1);
    io_nasti_aw_bits_id = VL_RAND_RESET_I(5);
    io_nasti_aw_bits_addr = VL_RAND_RESET_I(32);
    io_nasti_aw_bits_len = VL_RAND_RESET_I(8);
    io_nasti_aw_bits_size = VL_RAND_RESET_I(3);
    io_nasti_aw_bits_burst = VL_RAND_RESET_I(2);
    io_nasti_aw_bits_lock = VL_RAND_RESET_I(1);
    io_nasti_aw_bits_cache = VL_RAND_RESET_I(4);
    io_nasti_aw_bits_prot = VL_RAND_RESET_I(3);
    io_nasti_aw_bits_qos = VL_RAND_RESET_I(4);
    io_nasti_w_ready = VL_RAND_RESET_I(1);
    io_nasti_w_valid = VL_RAND_RESET_I(1);
    io_nasti_w_bits_data = VL_RAND_RESET_Q(64);
    io_nasti_w_bits_strb = VL_RAND_RESET_I(8);
    io_nasti_w_bits_last = VL_RAND_RESET_I(1);
    io_nasti_b_ready = VL_RAND_RESET_I(1);
    io_nasti_b_valid = VL_RAND_RESET_I(1);
    io_nasti_b_bits_id = VL_RAND_RESET_I(5);
    io_nasti_b_bits_resp = VL_RAND_RESET_I(2);
    io_nasti_ar_ready = VL_RAND_RESET_I(1);
    io_nasti_ar_valid = VL_RAND_RESET_I(1);
    io_nasti_ar_bits_id = VL_RAND_RESET_I(5);
    io_nasti_ar_bits_addr = VL_RAND_RESET_I(32);
    io_nasti_ar_bits_len = VL_RAND_RESET_I(8);
    io_nasti_ar_bits_size = VL_RAND_RESET_I(3);
    io_nasti_ar_bits_burst = VL_RAND_RESET_I(2);
    io_nasti_ar_bits_lock = VL_RAND_RESET_I(1);
    io_nasti_ar_bits_cache = VL_RAND_RESET_I(4);
    io_nasti_ar_bits_prot = VL_RAND_RESET_I(3);
    io_nasti_ar_bits_qos = VL_RAND_RESET_I(4);
    io_nasti_r_ready = VL_RAND_RESET_I(1);
    io_nasti_r_valid = VL_RAND_RESET_I(1);
    io_nasti_r_bits_id = VL_RAND_RESET_I(5);
    io_nasti_r_bits_data = VL_RAND_RESET_Q(64);
    io_nasti_r_bits_resp = VL_RAND_RESET_I(2);
    io_nasti_r_bits_last = VL_RAND_RESET_I(1);
    Tile__DOT__icache_io_cpu_resp_valid = VL_RAND_RESET_I(1);
    Tile__DOT__icache_io_nasti_ar_valid = VL_RAND_RESET_I(1);
    Tile__DOT__dcache_io_cpu_resp_valid = VL_RAND_RESET_I(1);
    Tile__DOT__dcache_io_cpu_resp_bits_data = VL_RAND_RESET_I(32);
    Tile__DOT__dcache_io_nasti_aw_valid = VL_RAND_RESET_I(1);
    Tile__DOT__dcache_io_nasti_w_valid = VL_RAND_RESET_I(1);
    Tile__DOT__dcache_io_nasti_w_bits_last = VL_RAND_RESET_I(1);
    Tile__DOT__dcache_io_nasti_b_ready = VL_RAND_RESET_I(1);
    Tile__DOT__dcache_io_nasti_ar_valid = VL_RAND_RESET_I(1);
    Tile__DOT__arb_io_icache_ar_ready = VL_RAND_RESET_I(1);
    Tile__DOT__arb_io_dcache_aw_ready = VL_RAND_RESET_I(1);
    Tile__DOT__arb_io_dcache_w_ready = VL_RAND_RESET_I(1);
    Tile__DOT__arb_io_dcache_ar_ready = VL_RAND_RESET_I(1);
    Tile__DOT__arb_io_nasti_aw_valid = VL_RAND_RESET_I(1);
    Tile__DOT__arb_io_nasti_b_ready = VL_RAND_RESET_I(1);
    Tile__DOT__arb_io_nasti_r_ready = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath_io_dcache_req_valid = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl_io_pc_sel = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl_io_inst_kill = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl_io_imm_sel = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__ctrl_io_alu_op = VL_RAND_RESET_I(4);
    Tile__DOT__core__DOT__ctrl_io_br_type = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__ctrl_io_st_type = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl_io_ld_type = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__dpath__DOT__csr_io_stall = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr_io_out = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr_io_expt = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata1 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__regFile_io_rdata2 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu_io_A = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu_io_B = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu_io_sum = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__immGen_io_out = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__brCond_io_taken = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__fe_reg_inst = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__fe_reg_pc = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__ew_reg_inst = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__ew_reg_pc = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__ew_reg_alu = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__ew_reg_csr_in = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__st_type = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__dpath__DOT__ld_type = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__dpath__DOT__wb_sel = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__dpath__DOT__wb_en = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr_cmd = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__dpath__DOT__illegal = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__pc_check = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__started = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__pc = VL_RAND_RESET_Q(33);
    Tile__DOT__core__DOT__dpath__DOT___next_pc_T_9 = VL_RAND_RESET_Q(33);
    Tile__DOT__core__DOT__dpath__DOT__next_pc = VL_RAND_RESET_Q(33);
    Tile__DOT__core__DOT__dpath__DOT__rs1hazard = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__rs2hazard = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__rs1 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__rs2 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT___daddr_T = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__dpath__DOT___io_dcache_req_bits_mask_T_10 = VL_RAND_RESET_I(5);
    Tile__DOT__core__DOT__dpath__DOT__lshift = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT___GEN_31 = VL_RAND_RESET_Q(33);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__time_ = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__timeh = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycle = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__cycleh = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instret = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__instreth = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__PRV1 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__IE1 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIP = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MTIE = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIP = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__MSIE = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtimecmp = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mscratch = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mepc = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mcause = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mbadaddr = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mtohost = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__mfromhost = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_0 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_68 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___io_out_T_80 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__privValid = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEcall = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEbreak = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isEret = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__csrValid = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wen = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__wdata = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__iaddrInvalid = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__laddrInvalid = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__saddrInvalid = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___time_T_1 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_1 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___cycle_T_1 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_2 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT__isInstRet = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_3 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_4 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_96 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_97 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_110 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_121 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_134 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_135 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_165 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_166 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_168 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_169 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_176 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_178 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_179 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_180 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_181 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_182 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_183 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_184 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_191 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_193 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_200 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__csr__DOT___GEN_239 = VL_RAND_RESET_Q(35);
    { int __Vi0=0; for (; __Vi0<32; ++__Vi0) {
            Tile__DOT__core__DOT__dpath__DOT__regFile__DOT__regs[__Vi0] = VL_RAND_RESET_I(32);
    }}
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___sum_T_3 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_9 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_19 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_29 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shin_T_39 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT__shin = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftr_T_5 = VL_RAND_RESET_Q(33);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_8 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_18 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_28 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___shiftl_T_38 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__alu__DOT___out_T_25 = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__immGen__DOT__Jimm = VL_RAND_RESET_I(21);
    Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_5 = VL_RAND_RESET_I(12);
    Tile__DOT__core__DOT__dpath__DOT__immGen__DOT___io_out_T_7 = VL_RAND_RESET_I(13);
    Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__diff = VL_RAND_RESET_I(32);
    Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__isSameSign = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__lt = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__dpath__DOT__brCond__DOT__ltu = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_117 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_132 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_147 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_156 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_189 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_223 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_240 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_266 = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_281 = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_311 = VL_RAND_RESET_I(4);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_326 = VL_RAND_RESET_I(4);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_341 = VL_RAND_RESET_I(4);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_414 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_434 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_489 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_558 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_573 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_588 = VL_RAND_RESET_I(2);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_622 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_656 = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_671 = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_686 = VL_RAND_RESET_I(3);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_706 = VL_RAND_RESET_I(1);
    Tile__DOT__core__DOT__ctrl__DOT___ctrlSignals_T_723 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__metaMem_tag[__Vi0] = VL_RAND_RESET_I(20);
    }}
    Tile__DOT__icache__DOT__metaMem_tag_rmeta_data = VL_RAND_RESET_I(20);
    Tile__DOT__icache__DOT__metaMem_tag_rmeta_en_pipe_0 = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__metaMem_tag_rmeta_addr_pipe_0 = VL_RAND_RESET_I(8);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_0_0[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_0_0_rdata_MPORT_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_0_1[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_0_1_rdata_MPORT_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_0_2[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_0_2_rdata_MPORT_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_0_3[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_0_3_rdata_MPORT_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_1_0[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_1_0_rdata_MPORT_1_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_1_1[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_1_1_rdata_MPORT_1_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_1_2[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_1_2_rdata_MPORT_1_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_1_3[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_en_pipe_0 = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__dataMem_1_3_rdata_MPORT_1_addr_pipe_0 = VL_RAND_RESET_I(8);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_2_0[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_2_0_rdata_MPORT_2_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_2_1[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_2_1_rdata_MPORT_2_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_2_2[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_2_2_rdata_MPORT_2_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_2_3[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_2_3_rdata_MPORT_2_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_3_0[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_3_0_rdata_MPORT_3_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_3_1[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_3_1_rdata_MPORT_3_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_3_2[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_3_2_rdata_MPORT_3_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__icache__DOT__dataMem_3_3[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__icache__DOT__dataMem_3_3_rdata_MPORT_3_en_pipe_0 = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__state = VL_RAND_RESET_I(3);
    VL_RAND_RESET_W(256, Tile__DOT__icache__DOT__v);
    VL_RAND_RESET_W(256, Tile__DOT__icache__DOT__d);
    Tile__DOT__icache__DOT__addr_reg = VL_RAND_RESET_I(32);
    Tile__DOT__icache__DOT__cpu_data = VL_RAND_RESET_I(32);
    Tile__DOT__icache__DOT__cpu_mask = VL_RAND_RESET_I(4);
    Tile__DOT__icache__DOT___T = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__read_count = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__read_wrap_out = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__write_count = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__is_alloc = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__is_alloc_reg = VL_RAND_RESET_I(1);
    VL_RAND_RESET_W(256, Tile__DOT__icache__DOT___hit_T);
    Tile__DOT__icache__DOT__hit = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT___wen_T = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT___wen_T_3 = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__wen = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT___ren_T_2 = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT__ren_reg = VL_RAND_RESET_I(1);
    VL_RAND_RESET_W(128, Tile__DOT__icache__DOT__rdata);
    VL_RAND_RESET_W(128, Tile__DOT__icache__DOT__rdata_buf);
    Tile__DOT__icache__DOT__refill_buf_0 = VL_RAND_RESET_Q(64);
    Tile__DOT__icache__DOT__refill_buf_1 = VL_RAND_RESET_Q(64);
    VL_RAND_RESET_W(128, Tile__DOT__icache__DOT__read);
    Tile__DOT__icache__DOT__wmask = VL_RAND_RESET_I(20);
    VL_RAND_RESET_W(128, Tile__DOT__icache__DOT__wdata);
    VL_RAND_RESET_W(256, Tile__DOT__icache__DOT___v_T_1);
    VL_RAND_RESET_W(256, Tile__DOT__icache__DOT___d_T_2);
    VL_RAND_RESET_W(256, Tile__DOT__icache__DOT___d_T_4);
    Tile__DOT__icache__DOT__is_dirty = VL_RAND_RESET_I(1);
    Tile__DOT__icache__DOT___GEN_107 = VL_RAND_RESET_I(3);
    Tile__DOT__icache__DOT___GEN_128 = VL_RAND_RESET_I(3);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__metaMem_tag[__Vi0] = VL_RAND_RESET_I(20);
    }}
    Tile__DOT__dcache__DOT__metaMem_tag_rmeta_data = VL_RAND_RESET_I(20);
    Tile__DOT__dcache__DOT__metaMem_tag_rmeta_en_pipe_0 = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__metaMem_tag_rmeta_addr_pipe_0 = VL_RAND_RESET_I(8);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_0_0[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_0_0_rdata_MPORT_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_0_1[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_0_1_rdata_MPORT_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_0_2[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_0_2_rdata_MPORT_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_0_3[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_0_3_rdata_MPORT_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_1_0[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_1_0_rdata_MPORT_1_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_1_1[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_1_1_rdata_MPORT_1_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_1_2[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_1_2_rdata_MPORT_1_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_1_3[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_1_3_rdata_MPORT_1_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_2_0[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_2_0_rdata_MPORT_2_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_2_1[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_2_1_rdata_MPORT_2_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_2_2[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_2_2_rdata_MPORT_2_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_2_3[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_2_3_rdata_MPORT_2_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_3_0[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_3_0_rdata_MPORT_3_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_3_1[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_3_1_rdata_MPORT_3_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_3_2[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_3_2_rdata_MPORT_3_en_pipe_0 = VL_RAND_RESET_I(1);
    { int __Vi0=0; for (; __Vi0<256; ++__Vi0) {
            Tile__DOT__dcache__DOT__dataMem_3_3[__Vi0] = VL_RAND_RESET_I(8);
    }}
    Tile__DOT__dcache__DOT__dataMem_3_3_rdata_MPORT_3_en_pipe_0 = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__state = VL_RAND_RESET_I(3);
    VL_RAND_RESET_W(256, Tile__DOT__dcache__DOT__v);
    VL_RAND_RESET_W(256, Tile__DOT__dcache__DOT__d);
    Tile__DOT__dcache__DOT__addr_reg = VL_RAND_RESET_I(32);
    Tile__DOT__dcache__DOT__cpu_data = VL_RAND_RESET_I(32);
    Tile__DOT__dcache__DOT__cpu_mask = VL_RAND_RESET_I(4);
    Tile__DOT__dcache__DOT___T = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__read_count = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__read_wrap_out = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT___T_1 = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__write_count = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__is_alloc = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__is_alloc_reg = VL_RAND_RESET_I(1);
    VL_RAND_RESET_W(256, Tile__DOT__dcache__DOT___hit_T);
    Tile__DOT__dcache__DOT__hit = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT___wen_T = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT___wen_T_3 = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__wen = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT___ren_T_2 = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT__ren_reg = VL_RAND_RESET_I(1);
    VL_RAND_RESET_W(128, Tile__DOT__dcache__DOT__rdata);
    VL_RAND_RESET_W(128, Tile__DOT__dcache__DOT__rdata_buf);
    Tile__DOT__dcache__DOT__refill_buf_0 = VL_RAND_RESET_Q(64);
    Tile__DOT__dcache__DOT__refill_buf_1 = VL_RAND_RESET_Q(64);
    VL_RAND_RESET_W(128, Tile__DOT__dcache__DOT__read);
    Tile__DOT__dcache__DOT__wmask = VL_RAND_RESET_I(20);
    VL_RAND_RESET_W(128, Tile__DOT__dcache__DOT__wdata);
    VL_RAND_RESET_W(256, Tile__DOT__dcache__DOT___v_T_1);
    VL_RAND_RESET_W(256, Tile__DOT__dcache__DOT___d_T_2);
    VL_RAND_RESET_W(256, Tile__DOT__dcache__DOT___d_T_4);
    Tile__DOT__dcache__DOT__is_dirty = VL_RAND_RESET_I(1);
    Tile__DOT__dcache__DOT___GEN_107 = VL_RAND_RESET_I(3);
    Tile__DOT__dcache__DOT___GEN_108 = VL_RAND_RESET_I(3);
    Tile__DOT__dcache__DOT___GEN_128 = VL_RAND_RESET_I(3);
    Tile__DOT__arb__DOT__state = VL_RAND_RESET_I(3);
    Tile__DOT__arb__DOT___GEN_0 = VL_RAND_RESET_I(3);
    Tile__DOT__arb__DOT___GEN_3 = VL_RAND_RESET_I(3);
    Tile__DOT__arb__DOT___GEN_8 = VL_RAND_RESET_I(3);
    __Vm_traceActivity = 0;
}
