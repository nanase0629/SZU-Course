// See LICENSE for license details.
package mini

import org.scalatest.Tag

object IntegrationTest extends Tag("IntegrationTest")
