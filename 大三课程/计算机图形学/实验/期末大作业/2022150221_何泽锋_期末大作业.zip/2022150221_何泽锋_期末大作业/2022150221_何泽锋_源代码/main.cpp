#include <iostream>
#include <string>
#include "Angel.h"
#include "Camera.h"
#include "stb_image.h"
#include "MeshPainter.h"
#include "TriMesh.h"
#include <vector>
#include <string>
#include <Camera.h>
#include <cmath>
#include <chrono>
#include <thread>
#include <random>
using namespace std;

//控制相机视角随鼠标移动而移动
float pitch = -25;//俯仰角
float roll = 135;//偏航角

//控制点光源位置
float angle=20;		//表示初始点光源与原点连线在z = 0平面与x轴的夹角

//人物参数
float xx = 0.1;//x轴的位置
float yy = 3.5;
float zz= 0;//z轴的位置

//汽车参数
float car_x = 0;
float car_z = -26;
int car_d = 270;
bool car_control = 0;

glm::vec3 add(-25, 25, -25);//与相机位置有关参数

bool camera_view = 0;//相机视角

int State = 0;//人物动画关键帧参数

float mousensitivity = 0.7f; // 鼠标灵敏度


int WIDTH = 600;
int HEIGHT = 600;

MeshPainter* skybox_painter = new MeshPainter();
MeshPainter* skybox_painter2 = new MeshPainter();
MeshPainter* skybox_painter3 = new MeshPainter();
GLuint skyboxTexture;// 天空盒纹理
GLuint skyboxTexture2;
GLuint skyboxTexture3;

// 天空盒参数
unsigned int skyboxVAO, skyboxVBO;
unsigned int cubemapTexture;

int mainWindow;

Camera*  camera= new Camera();
Light* light = new Light();
MeshPainter* painter = new MeshPainter();
MeshPainter* painter2 = new MeshPainter();
int scene = 0;

std::vector<TriMesh*> meshes;


bool checkCharacterCollisions() {
	glm::vec3 characterPosition(xx, yy, zz); // 人物的当前位置
	for (auto mesh : meshes) {
		if (mesh->isPointInside(characterPosition.x, characterPosition.z)) {
			// 处理碰撞逻辑
			return false;
		}
	}
	return true;
}
struct Helicopter
{
	enum {
		Body,
		Fan
	};
	GLfloat theta[2] = {
		180.0,
		0.0
	};

};
Helicopter helicopter;
TriMesh* Body = new TriMesh();
TriMesh* Fan = new TriMesh();

openGLObject BodyObject;
openGLObject FanObject;
float fan_rotate = 0.0;//机翼旋转
float h_x = -15;// 飞机位置
float h_y = 3.5;
float h_z = 0;
bool helicopter_control = 0;

struct Robot
{

	// 关节角和菜单选项值
	enum {
		Torso,			// 躯干
		Head,			// 头部
		RightUpperArm,	// 右大臂
		RightLowerArm,	// 右小臂
		LeftUpperArm,	// 左大臂
		LeftLowerArm,	// 左小臂
		RightUpperLeg,	// 右大腿
		RightLowerLeg,	// 右小腿
		LeftUpperLeg,	// 左大腿
		LeftLowerLeg,	// 左小腿
		Phone           // 手机
	};

	// 关节角大小
	GLfloat theta[11] = {
		180.0,  // Torso
		0.0,    // Head
		0.0,    // RightUpperArm
		0.0,    // RightLowerArm
		0.0,    // LeftUpperArm
		0.0,    // LeftLowerArm
		0.0,    // RightUpperLeg
		0.0,    // RightLowerLeg
		0.0,    // LeftUpperLeg
		0.0,    // LeftLowerLeg
		0.0		// Phone
	};
};
Robot robot;
int Selected_mesh = robot.Torso;

TriMesh* Torso = new TriMesh();
TriMesh* Head = new TriMesh();
TriMesh* RightUpperArm = new TriMesh();
TriMesh* RightLowerArm = new TriMesh();
TriMesh* LeftUpperArm = new TriMesh();
TriMesh* LeftLowerArm = new TriMesh();
TriMesh* RightUpperLeg = new TriMesh();
TriMesh* RightLowerLeg = new TriMesh();
TriMesh* LeftUpperLeg = new TriMesh();
TriMesh* LeftLowerLeg = new TriMesh();
TriMesh* Phone = new TriMesh();

openGLObject TorsoObject;
openGLObject HeadObject;
openGLObject RightUpperArmObject;
openGLObject RightLowerArmObject; 
openGLObject LeftUpperArmObject;
openGLObject LeftLowerArmObject;
openGLObject RightUpperLegObject;
openGLObject RightLowerLegObject;
openGLObject LeftUpperLegObject;
openGLObject LeftLowerLegObject;
openGLObject PhoneObject;

TriMesh* car1 = new TriMesh();
TriMesh* fire1 = new TriMesh();
TriMesh* fire2 = new TriMesh();
TriMesh* fire3 = new TriMesh();
TriMesh* particle_fire1 = new TriMesh();
TriMesh* particle_fire2 = new TriMesh();
TriMesh* particle_fire3 = new TriMesh();
TriMesh* particle_fire4 = new TriMesh();
int fire1_y = 1.5;
int fire2_y = 1.5;
int fire3_y = 1.5;
float particle_fire1_y = 1.5;
float bias_fire1_x = 0;
float bias_fire1_z = 0;
float particle_fire2_y = 1;
float bias_fire2_x = 0;
float bias_fire2_z = 0;
float particle_fire3_y = 1.2;
float bias_fire3_x = 0;
float bias_fire3_z = 0;
float particle_fire4_y = 1.4;
float bias_fire4_x = 0;
float bias_fire4_z = 0;


 
//人物的动画
//实现在走路时摆动手臂和双腿的函数
void character_animation(int i) {
	if (i % 20 <= 5) {
		robot.theta[robot.RightUpperArm] = 0;
		robot.theta[robot.RightLowerArm] = 0;

		robot.theta[robot.LeftUpperArm] = 0;
		robot.theta[robot.LeftLowerArm] = 0;

		robot.theta[robot.LeftUpperLeg] = 0;
		robot.theta[robot.LeftLowerLeg] = 0;

		robot.theta[robot.RightUpperLeg] = 0;
		robot.theta[robot.RightLowerLeg] = 0;
	}
	if (i % 20 > 5 && i % 20 <= 10) {
		robot.theta[robot.RightUpperArm] = -15;
		robot.theta[robot.RightLowerArm] = -15;

		robot.theta[robot.LeftUpperArm] = 15;
		robot.theta[robot.LeftLowerArm] = -15;

		robot.theta[robot.LeftUpperLeg] = 15;
		robot.theta[robot.LeftLowerLeg] = 10;

		robot.theta[robot.RightUpperLeg] = -15;
		robot.theta[robot.RightLowerLeg] = 10;
	}
	if (i % 20 > 10 && i % 20 <= 15) {
		robot.theta[robot.RightUpperArm] = 0;
		robot.theta[robot.RightLowerArm] = 0;

		robot.theta[robot.LeftUpperArm] = 0;
		robot.theta[robot.LeftLowerArm] = 0;

		robot.theta[robot.LeftUpperLeg] = 0;
		robot.theta[robot.LeftLowerLeg] = 0;

		robot.theta[robot.RightUpperLeg] = 0;
		robot.theta[robot.RightLowerLeg] = 0;
	}
	if (i % 20 > 15 && i % 20 <= 20) {
		robot.theta[robot.RightUpperArm] = 15;
		robot.theta[robot.RightLowerArm] = -15;

		robot.theta[robot.LeftUpperArm] = -15;
		robot.theta[robot.LeftLowerArm] = -15;

		robot.theta[robot.LeftUpperLeg] = -15;
		robot.theta[robot.LeftLowerLeg] = 10;

		robot.theta[robot.RightUpperLeg] = 15;
		robot.theta[robot.RightLowerLeg] = 10;
	}

}



//动态光照
bool night = 0; //控制白天/夜晚
int change_light; //移动光源
int d = 1; //转向
void Dynamic_lighting(){
	if (!night) {
		if ((angle >= 160 && d == 1) || (angle <= 20 && d == -1))d = -d;
		change_light++;
		if (change_light > 200){
			change_light = 0;
			angle += d;
		}

		light->setAmbient(glm::vec4(0.6, 0.6, 0.6, 1.0));
		light->setTranslation(glm::vec3(100 * cos(glm::radians(angle)), 100 * sin(glm::radians(angle)), 0));
	}
	else if (night&&scene==0){
		light->setAmbient(glm::vec4(0.4, 0.4, 0.4, 1.0));
		light->setTranslation(glm::vec3(9.0, 10.0, 9.0));
	}
	else if (night && scene == 1) {
		light->setAmbient(glm::vec4(0.4, 0.4, 0.4, 1.0));
		light->setTranslation(glm::vec3(12.0, 9, -6.0));
	}
}

// 回收和删除创建的物体对象
std::vector<TriMesh*> meshList;

class MatrixStack {
	int		_index;
	int		_size;
	glm::mat4* _matrices;

public:
	MatrixStack(int numMatrices = 100) :_index(0), _size(numMatrices)
	{
		_matrices = new glm::mat4[numMatrices];
	}

	~MatrixStack()
	{
		delete[]_matrices;
	}

	void push(const glm::mat4& m) {
		assert(_index + 1 < _size);
		_matrices[_index++] = m;
	}

	glm::mat4& pop() {
		assert(_index - 1 >= 0);
		_index--;
		return _matrices[_index];
	}
};

void load_texture_STBImage(const std::string& file_name, GLuint& texture) {
	// 读取纹理图片，并将其传递给着色器

	int width, height, channels = 0;
	unsigned char* pixels = NULL;
	// 读取图片的时候先翻转一下图片，如果不设置的话显示出来是反过来的图片
	stbi_set_flip_vertically_on_load(true);
	// 读取图片数据
	pixels = stbi_load(file_name.c_str(), &width, &height, &channels, 0);

	// 调整行对齐格式
	if (width * channels % 4 != 0)
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	GLenum format = GL_RGB;
	// 设置通道格式
	switch (channels)
	{
	case 1:
		format = GL_RED;
		break;
	case 3:
		format = GL_RGB;
		break;
	case 4:
		format = GL_RGBA;
		break;
	default:
		format = GL_RGB;
		break;
	}

	// 绑定纹理对象
	glBindTexture(GL_TEXTURE_2D, texture);

	// 指定纹理的放大，缩小滤波，使用线性方式，即当图片放大的时候插值方式
	// 将图片的rgb数据上传给opengl
	glTexImage2D(
		GL_TEXTURE_2D,    // 指定目标纹理，这个值必须是GL_TEXTURE_2D
		0,                // 执行细节级别，0是最基本的图像级别，n表示第N级贴图细化级别
		format,           // 纹理数据的颜色格式(GPU显存)
		width,            // 宽度。早期的显卡不支持不规则的纹理，则宽度和高度必须是2^n
		height,           // 高度。早期的显卡不支持不规则的纹理，则宽度和高度必须是2^n
		0,                // 指定边框的宽度。必须为0
		format,           // 像素数据的颜色格式(CPU内存)
		GL_UNSIGNED_BYTE, // 指定像素数据的数据类型
		pixels            // 指定内存中指向图像数据的指针
	);

	// 生成多级渐远纹理，多消耗1/3的显存，较小分辨率时获得更好的效果
	// glGenerateMipmap(GL_TEXTURE_2D);

	// 指定插值方法
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	// 恢复初始对齐格式
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
	// 释放图形内存
	stbi_image_free(pixels);
};


void bindObjectAndData(TriMesh* mesh, openGLObject& object, const std::string& texture_image, const std::string& vshader, const std::string& fshader) {
	// 初始化各种对象

	std::vector<glm::vec3> points = mesh->getPoints();
	std::vector<glm::vec3> normals = mesh->getNormals();
	std::vector<glm::vec3> colors = mesh->getColors();
	std::vector<glm::vec2> textures = mesh->getTextures();

	// 创建顶点数组对象
	glGenVertexArrays(1, &object.vao);  	// 分配1个顶点数组对象
	glBindVertexArray(object.vao);  	// 绑定顶点数组对象


	// 创建并初始化顶点缓存对象
	glGenBuffers(1, &object.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, object.vbo);
	glBufferData(GL_ARRAY_BUFFER,
		points.size() * sizeof(glm::vec3) +
		normals.size() * sizeof(glm::vec3) +
		colors.size() * sizeof(glm::vec3) +
		textures.size() * sizeof(glm::vec2),
		NULL, GL_STATIC_DRAW);

	// 绑定顶点数据
	glBufferSubData(GL_ARRAY_BUFFER, 0, points.size() * sizeof(glm::vec3), points.data());
	// 绑定颜色数据
	glBufferSubData(GL_ARRAY_BUFFER, points.size() * sizeof(glm::vec3), colors.size() * sizeof(glm::vec3), colors.data());
	// 绑定法向量数据
	glBufferSubData(GL_ARRAY_BUFFER, (points.size() + colors.size()) * sizeof(glm::vec3), normals.size() * sizeof(glm::vec3), normals.data());
	// 绑定纹理数据
	glBufferSubData(GL_ARRAY_BUFFER, (points.size() + normals.size() + colors.size()) * sizeof(glm::vec3), textures.size() * sizeof(glm::vec2), textures.data());


	object.vshader = vshader;
	object.fshader = fshader;
	object.program = InitShader(object.vshader.c_str(), object.fshader.c_str());

	// 将顶点传入着色器
	object.pLocation = glGetAttribLocation(object.program, "vPosition");
	glEnableVertexAttribArray(object.pLocation);
	glVertexAttribPointer(object.pLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

	// 将颜色传入着色器
	object.cLocation = glGetAttribLocation(object.program, "vColor");
	glEnableVertexAttribArray(object.cLocation);
	glVertexAttribPointer(object.cLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(points.size() * sizeof(glm::vec3)));

	// 将法向量传入着色器
	object.nLocation = glGetAttribLocation(object.program, "vNormal");
	glEnableVertexAttribArray(object.nLocation);
	glVertexAttribPointer(object.nLocation, 3,
		GL_FLOAT, GL_FALSE, 0,
		BUFFER_OFFSET((points.size() + colors.size()) * sizeof(glm::vec3)));

	object.tLocation = glGetAttribLocation(object.program, "vTexture");
	glEnableVertexAttribArray(object.tLocation);
	glVertexAttribPointer(object.tLocation, 2,
		GL_FLOAT, GL_FALSE, 0,
		BUFFER_OFFSET((points.size() + colors.size() + normals.size()) * sizeof(glm::vec3)));


	// 获得矩阵位置
	object.modelLocation = glGetUniformLocation(object.program, "model");
	object.viewLocation = glGetUniformLocation(object.program, "view");
	object.projectionLocation = glGetUniformLocation(object.program, "projection");

	object.shadowLocation = glGetUniformLocation(object.program, "isShadow");

	// 读取纹理图片数
	object.texture_image = texture_image;
	// 创建纹理的缓存对象
	glGenTextures(1, &object.texture);
	// 调用stb_image生成纹理
	load_texture_STBImage(object.texture_image, object.texture);

	// Clean up
	glUseProgram(0);
	glBindVertexArray(0);
};


void bindLightAndMaterial(TriMesh* mesh, openGLObject& object, Light* light, Camera* camera) {

	// 传递相机的位置
	glUniform3fv(glGetUniformLocation(object.program, "eye_position"), 1, &camera->eye[0]);

	// 传递物体的材质
	glm::vec4 meshAmbient = mesh->getAmbient();
	glm::vec4 meshDiffuse = mesh->getDiffuse();
	glm::vec4 meshSpecular = mesh->getSpecular();
	float meshShininess = mesh->getShininess();
	glUniform4fv(glGetUniformLocation(object.program, "material.ambient"), 1, &meshAmbient[0]);
	glUniform4fv(glGetUniformLocation(object.program, "material.diffuse"), 1, &meshDiffuse[0]);
	glUniform4fv(glGetUniformLocation(object.program, "material.specular"), 1, &meshSpecular[0]);
	glUniform1f(glGetUniformLocation(object.program, "material.shininess"), meshShininess);

	// 传递光源信息
	glm::vec4 lightAmbient = light->getAmbient();
	glm::vec4 lightDiffuse = light->getDiffuse();
	glm::vec4 lightSpecular = light->getSpecular();
	glm::vec3 lightPosition = light->getTranslation();

	glUniform4fv(glGetUniformLocation(object.program, "light.ambient"), 1, &lightAmbient[0]);
	glUniform4fv(glGetUniformLocation(object.program, "light.diffuse"), 1, &lightDiffuse[0]);
	glUniform4fv(glGetUniformLocation(object.program, "light.specular"), 1, &lightSpecular[0]);
	glUniform3fv(glGetUniformLocation(object.program, "light.position"), 1, &lightPosition[0]);

}




void drawMesh(glm::mat4 modelMatrix, TriMesh* mesh, openGLObject object) {
	//绘制无纹理模型
	glBindVertexArray(object.vao);

	glUseProgram(object.program);

	// 父节点矩阵 * 本节点局部变换矩阵
	glUniformMatrix4fv(object.modelLocation, 1, GL_FALSE, &modelMatrix[0][0]);
	glUniformMatrix4fv(object.viewLocation, 1, GL_FALSE, &camera->viewMatrix[0][0]);
	glUniformMatrix4fv(object.projectionLocation, 1, GL_FALSE, &camera->projMatrix[0][0]);
	glUniform1i(object.shadowLocation, 3);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, object.texture);// 该语句必须，否则将只使用同一个纹理进行绘制
	// 传递纹理数据 将生成的纹理传给shader
	glUniform1i(glGetUniformLocation(object.program, "texture"), 0);


	// 将材质和光源数据传递给着色器
	bindLightAndMaterial(mesh, object, light, camera);
	// 绘制
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());


	// 绘制阴影
		// @TODO: Task2：根据光源位置，计算阴影投影矩阵
	glm::mat4 shadowProjectoinMatrix = light->getShadowProjectionMatrix();
	// 计算阴影的模型变换矩阵。
	modelMatrix = shadowProjectoinMatrix * modelMatrix;
	// 传递 isShadow 变量。
	glUniform1i(object.shadowLocation, 1);
	// 传递 unifrom 关键字的矩阵数据。
	glUniformMatrix4fv(object.modelLocation, 1, GL_FALSE, &modelMatrix[0][0]);
	// 绘制
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());
}

void drawMesh2(glm::mat4 modelMatrix, TriMesh* mesh, openGLObject object) {
	//绘制带纹理模型
	glBindVertexArray(object.vao);

	glUseProgram(object.program);

	// 父节点矩阵 * 本节点局部变换矩阵
	glUniformMatrix4fv(object.modelLocation, 1, GL_FALSE, &modelMatrix[0][0]);
	glUniformMatrix4fv(object.viewLocation, 1, GL_FALSE, &camera->viewMatrix[0][0]);
	glUniformMatrix4fv(object.projectionLocation, 1, GL_FALSE, &camera->projMatrix[0][0]);
	glUniform1i(object.shadowLocation, 0);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, object.texture);// 该语句必须，否则将只使用同一个纹理进行绘制
	// 传递纹理数据 将生成的纹理传给shader
	glUniform1i(glGetUniformLocation(object.program, "texture"), 0);


	// 将材质和光源数据传递给着色器
	bindLightAndMaterial(mesh, object, light, camera);
	// 绘制
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());


	// 绘制阴影
		// @TODO: Task2：根据光源位置，计算阴影投影矩阵
	glm::mat4 shadowProjectoinMatrix = light->getShadowProjectionMatrix();
	// 计算阴影的模型变换矩阵。
	modelMatrix = shadowProjectoinMatrix * modelMatrix;
	// 传递 isShadow 变量。
	glUniform1i(object.shadowLocation, 1);
	// 传递 unifrom 关键字的矩阵数据。
	glUniformMatrix4fv(object.modelLocation, 1, GL_FALSE, &modelMatrix[0][0]);
	// 绘制
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());
}

//  直升飞机
void body(glm::mat4 modelMatrix)
{
	// 本节点局部变换矩阵
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, Body->getTranslation());
	my = glm::scale(my, Body->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体

	drawMesh2(modelMatrix * my, Body, BodyObject);
}
void fan(glm::mat4 modelMatrix)
{
	// 本节点局部变换矩阵
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, Fan->getTranslation());
	my = glm::scale(my, Fan->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体

	drawMesh2(modelMatrix * my, Fan, FanObject);
}

// 人物
void torso(glm::mat4 modelMatrix)
{
	// 本节点局部变换矩阵
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, Torso->getTranslation());
	my = glm::scale(my, Torso->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体

	drawMesh2(modelMatrix * my, Torso, TorsoObject);
}

void head(glm::mat4 modelMatrix)
{
	// 本节点局部变换矩阵
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, Head->getTranslation());
	my = glm::scale(my, Head->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, Head, HeadObject);
}

// 左手
void left_upper_arm(glm::mat4 modelMatrix)
{
	// 本节点局部变换矩阵
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, LeftUpperArm->getTranslation());
	my = glm::scale(my, LeftUpperArm->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, LeftUpperArm, LeftUpperArmObject);
}


// @TODO: 左小臂
void left_lower_arm(glm::mat4 modelMatrix)
{
	// 本节点局部变换矩阵
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, LeftLowerArm->getTranslation());
	my = glm::scale(my, LeftLowerArm->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, LeftLowerArm, LeftLowerArmObject);
}

// @TODO: 右大臂
void right_upper_arm(glm::mat4 modelMatrix)
{
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, RightUpperArm->getTranslation());
	my = glm::scale(my, RightUpperArm->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, RightUpperArm, RightUpperArmObject);
}

// @TODO: 右小臂
void right_lower_arm(glm::mat4 modelMatrix)
{
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, RightLowerArm->getTranslation());
	my = glm::scale(my, RightLowerArm->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, RightLowerArm,RightLowerArmObject);
}

// @TODO: 左大腿
void left_upper_leg(glm::mat4 modelMatrix)
{
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, LeftUpperLeg->getTranslation());
	my = glm::scale(my, LeftUpperLeg->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, LeftUpperLeg, LeftUpperLegObject);
}

// @TODO: 左小腿
void left_lower_leg(glm::mat4 modelMatrix)
{
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, LeftLowerLeg->getTranslation());
	my = glm::scale(my, LeftLowerLeg->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, LeftLowerLeg, LeftLowerLegObject);
}

// @TODO: 右大腿
void right_upper_leg(glm::mat4 modelMatrix)
{
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, RightUpperLeg->getTranslation());
	my = glm::scale(my, RightUpperLeg->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, RightUpperLeg, RightUpperLegObject);
}

// @TODO: 右小腿
void right_lower_leg(glm::mat4 modelMatrix)
{
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, RightLowerLeg->getTranslation());
	my = glm::scale(my, RightLowerLeg->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, RightLowerLeg, RightLowerLegObject);
}
// 手机
void phone(glm::mat4 modelMatrix)
{
	glm::mat4 my = glm::mat4(1.0);
	my = glm::translate(my, Phone->getTranslation());
	my = glm::scale(my, Phone->getScale());

	// 乘以来自父物体的模型变换矩阵，绘制当前物体
	drawMesh2(modelMatrix * my, Phone, PhoneObject);
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}


void initScene0() {
	// 地板
	std::string vshader, fshader;
	// 读取着色器并使用
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";
	TriMesh* ground = new TriMesh();
	ground->readObj("./assets/sky/ground.obj");
	// 设置物体的旋转位移
	ground->setTranslation(glm::vec3(0.0, -0.001, 0.0));
	ground->setRotation(glm::vec3(0.0, 0.0, 0.0));
	ground->setScale(glm::vec3(100.0, 100.0, 70.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	ground->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	ground->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	ground->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	ground->setShininess(0.1); //高光系数
	// 加到painter中
	painter->addMesh(ground, "ground", "./assets/sky/ground.png", vshader, fshader, 0, 0);


	// desk
	TriMesh* desk = new TriMesh();
	desk->readObj("./assets/obj/desk.obj");
	// 设置物体的旋转位移
	desk->setTranslation(glm::vec3(0.0, 2.5, 10.0));
	desk->setRotation(glm::vec3(0.0, 180.0, 0.0));
	desk->setScale(glm::vec3(10.0, 10.0, 10.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	desk->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	desk->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	desk->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	desk->setShininess(0.1); //高光系数
	// 加到painter中
	painter->addMesh(desk, "desk", "./assets/obj/desk.png", vshader, fshader, 0, 1);
	glm::vec3 minPoint(4.2, 3.5, 7);
	glm::vec3 maxPoint(-4.3, 3.5, 12.5);
	desk->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(desk); // 添加到物体列表

	// chair
	TriMesh* chair = new TriMesh();
	chair->readObj("./assets/obj/chair.obj");
	// 设置物体的旋转位移
	chair->setTranslation(glm::vec3(0.0, 1.5, 7.0));
	chair->setRotation(glm::vec3(0.0, 180.0, 0.0));
	chair->setScale(glm::vec3(5.0, 5.0, 5.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	chair->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	chair->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	chair->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	chair->setShininess(0.1); //高光系数
	minPoint = glm::vec3(1.2, 3.5, 5.3);
	maxPoint = glm::vec3(-1.6, 3.5, 7);
	chair->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(chair); // 添加到物体列表
	// 加到painter中
	painter->addMesh(chair, "chair", "./assets/obj/chair.png", vshader, fshader, 0, 1);

	// bed
	TriMesh* bed = new TriMesh();
	bed->readObj("./assets/obj/bed.obj");
	// 设置物体的旋转位移
	bed->setTranslation(glm::vec3(6.8, 1.7, 0.0));
	bed->setRotation(glm::vec3(0.0, 180.0, 0.0));
	bed->setScale(glm::vec3(10.0, 10.0, 10.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	bed->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	bed->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	bed->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	bed->setShininess(0.1); //高光系数
	minPoint = glm::vec3(11.6, 3.5, -3.0);
	maxPoint = glm::vec3(2.3, 3.5, 2.8);
	bed->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(bed); // 添加到物体列表
	// 加到painter中
	painter->addMesh(bed, "bed", "./assets/obj/bed.png", vshader, fshader, 0, 1);

	// box
	TriMesh* box = new TriMesh();
	box->readObj("./assets/obj/box.obj");
	// 设置物体的旋转位移
	box->setTranslation(glm::vec3(10.0, 1.8, -4.0));
	box->setRotation(glm::vec3(0.0, 180.0, 0.0));
	box->setScale(glm::vec3(5.0, 5.0, 5.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	box->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	box->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	box->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	box->setShininess(0.1); //高光系数
	minPoint = glm::vec3(11.2, 3.5, -5.8);
	maxPoint = glm::vec3(8.1, 3.5, -2.3);
	box->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(box); // 添加到物体列表
	// 加到painter中
	painter->addMesh(box, "box", "./assets/obj/box.png", vshader, fshader, 0, 1);
	// box2
	TriMesh* box2 = new TriMesh();
	box2->readObj("./assets/obj/box.obj");
	// 设置物体的旋转位移
	box2->setTranslation(glm::vec3(10.0, 1.8, 4.0));
	box2->setRotation(glm::vec3(0.0, 180.0, 0.0));
	box2->setScale(glm::vec3(5.0, 5.0, 5.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	box2->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	box2->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	box2->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	box2->setShininess(0.1); //高光系数
	minPoint = glm::vec3(11.2, 3.5, 2.8);
	maxPoint = glm::vec3(8.1, 3.5, 6);
	box2->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(box2); // 添加到物体列表
	// 加到painter中
	painter->addMesh(box2, "box2", "./assets/obj/box.png", vshader, fshader, 0, 1);

	// lamp
	TriMesh* lamp = new TriMesh();
	lamp->readObj("./assets/obj/lamp.obj");
	// 设置物体的旋转位移
	lamp->setTranslation(glm::vec3(9.0, 2.2, 9.0));
	lamp->setRotation(glm::vec3(0.0, 180.0, 0.0));
	lamp->setScale(glm::vec3(5.0, 5.0, 5.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	lamp->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	lamp->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	lamp->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	lamp->setShininess(0.1); //高光系数
	minPoint = glm::vec3(10.8, 3.5, 8.1);
	maxPoint = glm::vec3(7.6, 3.5, 10.2);
	lamp->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(lamp); // 添加到物体列表
	// 加到painter中
	painter->addMesh(lamp, "lamp", "./assets/obj/lamp.png", vshader, fshader, 0, 1);

	std::vector<std::string> faces{
	"assets/sky/1.jpg",
	"assets/sky/2.jpg",
	"assets/sky/3.jpg",
	"assets/sky/4.jpg",
	"assets/sky/5.jpg",
	"assets/sky/6.jpg"
	};
	skyboxTexture = skybox_painter->BindSkyBox(faces);
}

void initScene1() {
	std::string vshader, fshader;
	// 读取着色器并使用
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";
	// 地板
	TriMesh* house = new TriMesh();
	house->readObj("./assets/outdoor/house.obj");
	// 设置物体的旋转位移
	house->setTranslation(glm::vec3(0.0, 11.44, 5.0));
	house->setRotation(glm::vec3(0.0, 0.0, 0.0));
	house->setScale(glm::vec3(150.0, 150.0, 150.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	house->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	house->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	house->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	house->setShininess(0.1); //高光系数
	glm::vec3 minPoint(10.8, 3.5, 3);
	glm::vec3 maxPoint(- 10.4, 3.5, 21.4);
	house->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(house); // 添加到物体列表
	// 加到painter中
	painter2->addMesh(house, "house", "./assets/outdoor/house.png", vshader, fshader, 0, 0);
	TriMesh* tmp = new TriMesh();
	minPoint = glm::vec3(17.5, 3.5, -10.5);
	maxPoint = glm::vec3(14.7, 3.5, 30.6001);
	tmp->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(tmp); // 添加到物体列表
	TriMesh* tmp1 = new TriMesh();
	minPoint = glm::vec3(-18.6, 3.5, - 9.3);
	maxPoint = glm::vec3(-21.5, 3.5, 27.1001);
	tmp1->setBoundingBox(minPoint, maxPoint);
	meshes.push_back(tmp1); // 添加到物体列表

	// 汽车
	car1->readObj("./assets/outdoor/car1.obj");
	// 设置物体的旋转位移
	car1->setTranslation(glm::vec3(car_x, 2.5, car_z));
	car1->setRotation(glm::vec3(0.0, car_d, 0.0));
	car1->setScale(glm::vec3(15.0, 15.0, 15.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	car1->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	car1->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	car1->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	car1->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(car1, "car1", "./assets/outdoor/car1.png", vshader, fshader, 0, 1);

	TriMesh* campfire = new TriMesh();
	campfire->readObj("./assets/outdoor/campfire.obj");
	campfire->setTranslation(glm::vec3(12.0, 0.5, -6.0));
	campfire->setRotation(glm::vec3(0.0, 0.0, 0.0));
	campfire->setScale(glm::vec3(3.0, 3.0, 3.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	campfire->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	campfire->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	campfire->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	campfire->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(campfire, "campfire", "./assets/outdoor/campfire.png", vshader, fshader, 0, 1);

	fire1->readObj("./assets/outdoor/fire1.obj");
	fire1->setTranslation(glm::vec3(12.0, fire1_y, -6.0));
	fire1->setRotation(glm::vec3(0.0, 0.0, 0.0));
	fire1->setScale(glm::vec3(3.0, 3.0, 3.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	fire1->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	fire1->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	fire1->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	fire1->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(fire1, "fire1", "./assets/outdoor/fire1.png", vshader, fshader, 0, 1);


	fire2->readObj("./assets/outdoor/fire2.obj");
	fire2->setTranslation(glm::vec3(12.0, fire2_y, -6.0));
	fire2->setRotation(glm::vec3(0.0, 0.0, 0.0));
	fire2->setScale(glm::vec3(3.0, 3.0, 3.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	fire2->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	fire2->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	fire2->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	fire2->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(fire2, "fire2", "./assets/outdoor/fire2.png", vshader, fshader, 0, 1);

	fire3->readObj("./assets/outdoor/fire3.obj");
	fire3->setTranslation(glm::vec3(12.0, fire3_y, -6.0));
	fire3->setRotation(glm::vec3(0.0, 0.0, 0.0));
	fire3->setScale(glm::vec3(3.0, 3.0, 3.0));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	fire3->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	fire3->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	fire3->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	fire3->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(fire3, "fire3", "./assets/outdoor/fire3.png", vshader, fshader, 0, 1);

	particle_fire1->readObj("./assets/outdoor/particle_fire1.obj");
	particle_fire1->setTranslation(glm::vec3(12.0, particle_fire1_y, -6.0));
	particle_fire1->setRotation(glm::vec3(0.0, 0.0, 0.0));
	particle_fire1->setScale(glm::vec3(0.5, 0.5, 0.5));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	particle_fire1->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	particle_fire1->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	particle_fire1->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	particle_fire1->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(particle_fire1, "particle_fire1", "./assets/outdoor/particle_fire1.png", vshader, fshader, 0, 0);

	particle_fire2->readObj("./assets/outdoor/particle_fire2.obj");
	particle_fire2->setTranslation(glm::vec3(12.0, particle_fire2_y, -6.0));
	particle_fire2->setRotation(glm::vec3(0.0, 0.0, 0.0));
	particle_fire2->setScale(glm::vec3(0.5, 0.5, 0.5));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	particle_fire2->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	particle_fire2->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	particle_fire2->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	particle_fire2->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(particle_fire2, "particle_fire2", "./assets/outdoor/particle_fire2.png", vshader, fshader, 0, 0);

	particle_fire3->readObj("./assets/outdoor/particle_fire3.obj");
	particle_fire3->setTranslation(glm::vec3(12.0, particle_fire3_y, -6.0));
	particle_fire3->setRotation(glm::vec3(0.0, 0.0, 0.0));
	particle_fire3->setScale(glm::vec3(0.5, 0.5, 0.5));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	particle_fire3->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	particle_fire3->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	particle_fire3->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	particle_fire3->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(particle_fire3, "particle_fire3", "./assets/outdoor/particle_fire3.png", vshader, fshader, 0, 0);

	particle_fire4->readObj("./assets/outdoor/particle_fire4.obj");
	particle_fire4->setTranslation(glm::vec3(12.0,particle_fire4_y, -6.0));
	particle_fire4->setRotation(glm::vec3(0.0, 0.0, 0.0));
	particle_fire4->setScale(glm::vec3(0.5, 0.5, 0.5));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	particle_fire4->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	particle_fire4->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	particle_fire4->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	particle_fire4->setShininess(0.1); //高光系数
	// 加到painter中
	painter2->addMesh(particle_fire4, "particle_fire4", "./assets/outdoor/particle_fire4.png", vshader, fshader, 0, 0);

	std::vector<std::string> faces2{
		"assets/sky2/1.jpg",
		"assets/sky2/2.jpg",
		"assets/sky2/1.jpg",
		"assets/sky2/2.jpg",
		"assets/sky2/1.jpg",
		"assets/sky2/2.jpg"
	};
	skyboxTexture2 = skybox_painter2->BindSkyBox(faces2);

	std::vector<std::string> faces3{
		"assets/sky2/night2.jpg",
		"assets/sky2/night.jpg",
		"assets/sky2/night3.jpg",
		"assets/sky2/night3.jpg",
		"assets/sky2/night.jpg",
		"assets/sky2/night.jpg"
	};
	skyboxTexture3 = skybox_painter3->BindSkyBox(faces3);
	//glClearColor(1.0, 1.0, 1.0, 1.0);
}
void init()
{
	std::string vshader, fshader;
	// 读取着色器并使用
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";

	// 设置光源
	light->setAmbient(glm::vec4(0.6, 0.6, 0.6, 1.0)); // 环境光
	light->setDiffuse(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 漫反射
	light->setSpecular(glm::vec4(0.5, 0.5, 0.5, 1.0)); // 镜面反射
	light->setAttenuation(1.0, 0.045, 0.0075); // 衰减系数
	
	initScene0();
	
	
	
	//////////////////////////////////////////////////层级建模1////////////////////////////////////////////////
	
	Torso->setNormalize(true);
	Torso->readObj("./assets/girl/body.obj");
	// 设置物体的旋转位移
	Torso->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	Torso->setRotation(glm::vec3(0.0, 0.0, 0.0));
	Torso->setScale(glm::vec3(1.25, 1.25, 1.25));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	Torso->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	Torso->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	Torso->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	Torso->setShininess(0.1); //高光系数
	bindObjectAndData(Torso, TorsoObject, "./assets/girl/body.png", vshader, fshader);


	Head->setNormalize(true);
	Head->readObj("./assets/girl/head.obj");
	// 设置物体的旋转位移
	Head->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	Head->setRotation(glm::vec3(0.0, 0.0, 0.0));
	Head->setScale(glm::vec3(1.25, 1.25, 1.25));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	Head->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	Head->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	Head->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	Head->setShininess(0.1); //高光系数
	bindObjectAndData(Head, HeadObject, "./assets/girl/head.png", vshader, fshader);


	RightUpperArm->setNormalize(true);
	RightUpperArm->readObj("./assets/girl/right_upper_arm.obj");
	// 设置物体的旋转位移
	RightUpperArm->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	RightUpperArm->setRotation(glm::vec3(0.0, 0.0, 0.0));
	RightUpperArm->setScale(glm::vec3(0.65,0.65,0.65));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	RightUpperArm->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	RightUpperArm->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	RightUpperArm->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	RightUpperArm->setShininess(0.1); //高光系数
	bindObjectAndData(RightUpperArm, RightUpperArmObject, "./assets/girl/right_upper_arm.png", vshader, fshader);

	RightLowerArm->setNormalize(true);
	RightLowerArm->readObj("./assets/girl/right_lower_arm.obj");
	// 设置物体的旋转位移
	RightLowerArm->setTranslation(glm::vec3(0, 0, 0));
	RightLowerArm->setRotation(glm::vec3(0, 0, 0.0));
	RightLowerArm->setScale(glm::vec3(0.72, 0.72, 0.72));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	RightLowerArm->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	RightLowerArm->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	RightLowerArm->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	RightLowerArm->setShininess(0.1); //高光系数
	bindObjectAndData(RightLowerArm, RightLowerArmObject, "./assets/girl/right_lower_arm.png", vshader, fshader);


	LeftUpperArm->setNormalize(true);
	LeftUpperArm->readObj("./assets/girl/left_upper_arm.obj");
	// 设置物体的旋转位移
	LeftUpperArm->setTranslation(glm::vec3(0, -0.3, 0));
	LeftUpperArm->setRotation(glm::vec3(0, 0, 0.0));
	LeftUpperArm->setScale(glm::vec3(0.65, 0.65, 0.65));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	LeftUpperArm->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	LeftUpperArm->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	LeftUpperArm->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	LeftUpperArm->setShininess(0.1); //高光系数
	bindObjectAndData(LeftUpperArm, LeftUpperArmObject, "./assets/girl/left_upper_arm.png", vshader, fshader);

	LeftLowerArm->setNormalize(true);
	LeftLowerArm->readObj("./assets/girl/left_lower_arm.obj");
	// 设置物体的旋转位移
	LeftLowerArm->setTranslation(glm::vec3(0, -0.3, 0));
	LeftLowerArm->setRotation(glm::vec3(0, 0, 0.0));
	LeftLowerArm->setScale(glm::vec3(0.72, 0.72, 0.72));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	LeftLowerArm->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	LeftLowerArm->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	LeftLowerArm->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	LeftLowerArm->setShininess(0.1); //高光系数
	bindObjectAndData(LeftLowerArm, LeftLowerArmObject, "./assets/girl/left_lower_arm.png", vshader, fshader);

	RightUpperLeg->setNormalize(true);
	RightUpperLeg->readObj("./assets/girl/right_upper_leg.obj");
	// 设置物体的旋转位移
	RightUpperLeg->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	RightUpperLeg->setRotation(glm::vec3(0.0, 0.0, 0.0));
	RightUpperLeg->setScale(glm::vec3(0.72, 0.72, 0.72));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	RightUpperLeg->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	RightUpperLeg->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	RightUpperLeg->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	RightUpperLeg->setShininess(0.1); //高光系数
	bindObjectAndData(RightUpperLeg, RightUpperLegObject, "./assets/girl/right_upper_leg.png", vshader, fshader);

	RightLowerLeg->setNormalize(true);
	RightLowerLeg->readObj("./assets/girl/right_lower_leg.obj");
	// 设置物体的旋转位移
	RightLowerLeg->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	RightLowerLeg->setRotation(glm::vec3(0.0, 0.0, 0.0));
	RightLowerLeg->setScale(glm::vec3(0.94, 0.94, 0.94));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	RightLowerLeg->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	RightLowerLeg->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	RightLowerLeg->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	RightLowerLeg->setShininess(0.1); //高光系数
	bindObjectAndData(RightLowerLeg, RightLowerLegObject, "./assets/girl/right_lower_leg.png", vshader, fshader);

	LeftUpperLeg->setNormalize(true);
	LeftUpperLeg->readObj("./assets/girl/left_upper_leg.obj");
	// 设置物体的旋转位移
	LeftUpperLeg->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	LeftUpperLeg->setRotation(glm::vec3(0.0, 0.0, 0.0));
	LeftUpperLeg->setScale(glm::vec3(0.72, 0.72, 0.72));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	LeftUpperLeg->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	LeftUpperLeg->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	LeftUpperLeg->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	LeftUpperLeg->setShininess(0.1); //高光系数
	bindObjectAndData(LeftUpperLeg, LeftUpperLegObject, "./assets/girl/left_upper_leg.png", vshader, fshader);

	LeftLowerLeg->setNormalize(true);
	LeftLowerLeg->readObj("./assets/girl/left_lower_leg.obj");
	// 设置物体的旋转位移
	LeftLowerLeg->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	LeftLowerLeg->setRotation(glm::vec3(0.0, 0.0, 0.0));
	LeftLowerLeg->setScale(glm::vec3(0.94, 0.94, 0.94));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	LeftLowerLeg->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	LeftLowerLeg->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	LeftLowerLeg->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	LeftLowerLeg->setShininess(0.1); //高光系数
	bindObjectAndData(LeftLowerLeg, LeftLowerLegObject, "./assets/girl/left_lower_leg.png", vshader, fshader);
	
	Phone->setNormalize(true);
	Phone->readObj("./assets/girl/phone.obj");
	// 设置物体的旋转位移
	Phone->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	Phone->setRotation(glm::vec3(0.0, 00.0, 00.0));
	Phone->setScale(glm::vec3(0.5, 0.5, 0.5));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	Phone->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	Phone->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	Phone->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	Phone->setShininess(0.1); //高光系数
	bindObjectAndData(Phone, PhoneObject, "./assets/girl/phone.png", vshader, fshader);
	//////////////////////////////////////////////////层级建模2////////////////////////////////////////////////
	Body->setNormalize(true);
	Body->readObj("./assets/helicopter/helicopter_body.obj");
	// 设置物体的旋转位移
	Body->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	Body->setRotation(glm::vec3(0.0, 00.0, 00.0));
	Body->setScale(glm::vec3(10, 10, 10));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	Body->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	Body->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	Body->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	Body->setShininess(0.1); //高光系数
	bindObjectAndData(Body, BodyObject, "./assets/helicopter/helicopter_body.png", vshader, fshader);

	Fan->setNormalize(true);
	Fan->readObj("./assets/helicopter/helicopter_fan.obj");
	// 设置物体的旋转位移
	Fan->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	Fan->setRotation(glm::vec3(0.0, 00.0, 00.0));
	Fan->setScale(glm::vec3(10, 10, 10));
	// 设置材质（不过本次实验中不会用到光照，感兴趣的图像结合ppt的扩展内容将着色器进行修改）
	Fan->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 环境光
	Fan->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0)); // 漫反射
	Fan->setSpecular(glm::vec4(0.1, 0.1, 0.1, 1.0)); // 镜面反射
	Fan->setShininess(0.1); //高光系数
	bindObjectAndData(Fan, FanObject, "./assets/helicopter/helicopter_fan.png", vshader, fshader);

	//////////////////////////////////////////场景2/////////////////////////////////////////////
	initScene1();
	

	 glClearColor(0.0, 0.0, 0.0, 1.0);
}


bool sceneInitialized[2] = { false, false }; // 假设只有两个场景
void display()
{
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// 相机矩阵计算
	camera->updateCamera();
	camera->viewMatrix = camera->getViewMatrix();
	camera->projMatrix = camera->getProjectionMatrix(false);


	// 物体的变换矩阵
	glm::mat4 modelMatrix = glm::mat4(1.0);
	// 保持变换矩阵的栈
	MatrixStack mstack;

	// =========== 躯干 ===========

	modelMatrix = glm::translate(modelMatrix, glm::vec3(xx, yy, zz));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.Torso]), glm::vec3(0.0, 1.0, 0.0));
	modelMatrix = glm::scale(modelMatrix, glm::vec3(2, 2, 2));
	torso(modelMatrix);
	mstack.push(modelMatrix);   // 保存躯干变换矩阵

	// =========== 头部 ===========
	modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.01, 0.62, 0.0));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.Head]), glm::vec3(0.0, 1.0, 0.0));
	head(modelMatrix);
	modelMatrix = mstack.pop(); // 恢复躯干变换矩阵


	// =========== 右臂 ===========
	mstack.push(modelMatrix);   // 保存躯干变换矩阵
	// @TODO: 右大臂
	modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.48, 0.24, -0.03));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.RightUpperArm]), glm::vec3(1.0, 1.0, 0.0));
	right_upper_arm(modelMatrix);


	// @TODO: 右小臂
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.4, 0.0));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.RightLowerArm]), glm::vec3(1.0, 0.0, 0.0));
	right_lower_arm(modelMatrix);
	modelMatrix = mstack.pop();


	// =========== 左臂 ===========
	mstack.push(modelMatrix);
	// 左大臂（这里我们希望机器人的左大臂只绕Z轴旋转，所以只计算了RotateZ，后面同理）
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0.48, 0.54, -0.03));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.LeftUpperArm]), glm::vec3(1.0, 1.0, 0.0));
	left_upper_arm(modelMatrix);

	// @TODO: 左小臂
	// 左大臂
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.4, 0.0));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.LeftLowerArm]), glm::vec3(1.0, 0.0, 0.0));
	left_lower_arm(modelMatrix);

	modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.15, -0.6, 0.20));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.Phone]), glm::vec3(0.0, 1.0, 0.0));
	phone(modelMatrix);

	modelMatrix = mstack.pop();


	// =========== 左腿 ===========
	mstack.push(modelMatrix);
	// @TODO: 左大腿
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0.165, -0.725, -0.034));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.LeftUpperLeg]), glm::vec3(1.0, 0.0, 0.0));
	left_upper_leg(modelMatrix);
	// @TODO: 左小腿
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0, -0.6, 0.07));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.LeftLowerLeg]), glm::vec3(1.0, 0.0, 0.0));
	left_lower_leg(modelMatrix);
	modelMatrix = mstack.pop();

	// =========== 右腿 ===========
	mstack.push(modelMatrix);
	// @TODO: 右大腿
	modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.17, -0.725, -0.035));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.RightUpperLeg]), glm::vec3(1.0, 0.0, 0.0));
	right_upper_leg(modelMatrix);
	// @TODO: 右小腿
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0, -0.6, 0.07));
	modelMatrix = glm::rotate(modelMatrix, glm::radians(robot.theta[robot.RightLowerLeg]), glm::vec3(1.0, 0.0, 0.0));
	right_lower_leg(modelMatrix);
	modelMatrix = mstack.pop();

	// 场景切换
	if (scene == 0) {
		if (!sceneInitialized[0]) {
			meshes.clear();
			initScene0();  // 初始化场景0的物体
			xx = 0.1;
			zz= 0;
			sceneInitialized[1] = false;
			sceneInitialized[0] = true;
		}
		skybox_painter->drawSkyBox(camera, skybox_painter->getOpenGLObj()[0], skyboxTexture);
		painter->drawMeshes(light, camera);
	
	}
	else if (scene == 1) {
		if (!sceneInitialized[1]) {
			meshes.clear();
			initScene1();  // 初始化场景1的物体
			xx = 0.1;
			zz = 0;
			sceneInitialized[1] = true;
			sceneInitialized[0] = false;
		}
		car1->setTranslation(glm::vec3(car_x, 2.5, car_z));
		car1->setRotation(glm::vec3(0.0, car_d, 0.0));
		if (!night) {
			skybox_painter2->drawSkyBox(camera, skybox_painter2->getOpenGLObj()[0], skyboxTexture2);
			
		}
		else {
			skybox_painter3->drawSkyBox(camera, skybox_painter3->getOpenGLObj()[0], skyboxTexture3);
		}

		fire1->setTranslation(glm::vec3(12.0, fire1_y, -6.0));
		fire2->setTranslation(glm::vec3(12.0, fire2_y, -6.0));
		fire3->setTranslation(glm::vec3(12.0, fire3_y, -6.0));
		particle_fire1->setTranslation(glm::vec3(12.0 - bias_fire1_x, particle_fire1_y, -6.0 - bias_fire1_z));
		particle_fire2->setTranslation(glm::vec3(12.0 - bias_fire2_x, particle_fire2_y, -6.0 - bias_fire2_z));
		particle_fire3->setTranslation(glm::vec3(12.0 - bias_fire3_x, particle_fire3_y, -6.0 - bias_fire3_z));
		particle_fire4->setTranslation(glm::vec3(12.0 - bias_fire4_x, particle_fire4_y, -6.0 - bias_fire4_z));

		glm::mat4 modelMatrix1 = glm::mat4(1.0);
		// 保持变换矩阵的栈
		MatrixStack mstack1;
		// =========== 机身 ===========

		modelMatrix1 = glm::translate(modelMatrix1, glm::vec3(h_x, h_y, h_z));
		modelMatrix1 = glm::rotate(modelMatrix1, glm::radians(helicopter.theta[helicopter.Body]), glm::vec3(0.0, 1.0, 0.0));
		modelMatrix1 = glm::scale(modelMatrix1, glm::vec3(2, 2, 2));
		body(modelMatrix1);
		mstack1.push(modelMatrix1);   // 保存躯干变换矩阵

		// =========== 机翼 ===========
		modelMatrix1 = glm::translate(modelMatrix1, glm::vec3(0.0, 1.05, 2.2));
		modelMatrix1 = glm::rotate(modelMatrix1, glm::radians(fan_rotate), glm::vec3(0.0, 1.0, 0.0));
		fan(modelMatrix1);
		modelMatrix1 = mstack1.pop(); // 恢复躯干变换矩阵
		
		painter2->drawMeshes(light, camera);

	}

}
float fire_speed1 = 0.1;
float fire_speed2 = 0.1;
float fire_speed3 = 0.1;
float fire_speed4 = 0.1;
void fire() {
	if (particle_fire1_y < 5) {
		fire_speed1+=0.01;
		particle_fire1_y += fire_speed1;
	}
	else {
		fire_speed1 = 0.1;
		particle_fire1_y = 1.2;
		std::random_device rd;
		std::mt19937 gen(rd());
		std::uniform_real_distribution<> dis(-0.7, 0.7); 
		double random_number = dis(gen);
		double random_number1= dis(gen);
		bias_fire1_x = random_number;
		bias_fire1_z = random_number1;

	}
	if (particle_fire2_y < 5) {
		fire_speed2 += 0.01;
		particle_fire2_y += fire_speed2;
	}
	else {
		fire_speed2 = 0.1;
		particle_fire2_y = 0.4;
		std::random_device rd;
		std::mt19937 gen(rd());
		std::uniform_real_distribution<> dis(-0.7, 0.7); 
		double random_number = dis(gen);
		double random_number1 = dis(gen);
		bias_fire2_x = random_number;
		bias_fire2_z = random_number1;
	}
	if (particle_fire3_y < 5) {
		fire_speed3 += 0.01;
		particle_fire3_y += fire_speed3;
	}
	else {
		fire_speed3 = 0.1;
		particle_fire3_y = 0.6;
		std::random_device rd;
		std::mt19937 gen(rd());
		std::uniform_real_distribution<> dis(-0.7, 0.7); 
		double random_number = dis(gen);
		double random_number1 = dis(gen);
		bias_fire3_x = random_number;
		bias_fire3_z = random_number1;
	}
	if (particle_fire4_y < 5) {
		fire_speed4 += 0.01;
		particle_fire4_y += fire_speed4;
	}
	else {
		fire_speed4 = 0.1;
		particle_fire4_y = 0.9;
		std::random_device rd;
		std::mt19937 gen(rd());
		std::uniform_real_distribution<> dis(-0.7, 0.7); 
		double random_number = dis(gen);
		double random_number1 = dis(gen);
		bias_fire4_x = random_number;
		bias_fire4_z = random_number1;
	}
}


void printHelp()
{
	cout << "-------------------------------------------------------------------------------------------" << endl;
	cout << "Assistant Message" << endl;
	cout <<
		"[Window]" << endl <<
		"ESC:	Exit" << endl <<
		"H:	Print Assistance" << endl << endl <<

		"[Mouse]" << endl <<
		"Long press the right button:    Control the angle of camera" << endl << endl <<

		"[Camera]" << endl <<
		"Use [UP, DOWN, LEFT, RIGHT] to control the postion ofcamera" << endl <<
		"L:	Reset the camera and character" << endl << endl <<

		"[Character]" << endl <<
		"Use [W, A, S, D] keys to control the character's walking" << endl <<
		"SPACE:  Jump" << endl <<
		"F1:	Change perspective" << endl <<
		"P:	Switch to day/night" << endl <<
		"F:	Change scene" << endl << endl <<

		"[Car]" << endl <<
		"Use [W, A, D] keys to control the car(LEFT and RIGHT only use to turn the direction)" << endl <<
		"E:	Get in the car(Ensure that the character is next to the car)" << endl << endl <<

		"[Helicopter]" << endl <<
		"Use [W, A, S, D] keys to control the helicopter" << endl <<
		"R:	Get in the helicopter(Ensure that the character is next to the helicopter)" << endl << endl <<
	

		"[Part]" << endl <<
		"Select Part" << endl <<
		"1:	Torso" << endl <<
		"2: 	Head" << endl <<
		"3: 	RightUpperArm" << endl <<
		"4: 	RightLowerArm" << endl <<
		"5: 	LeftUpperArm" << endl <<
		"6: 	LeftLowerArm" << endl <<
		"7: 	RightUpperLeg" << endl <<
		"8: 	RightLowerLeg" << endl <<
		"9: 	LeftUpperLeg" << endl <<
		"0: 	LeftLowerLeg" << endl <<
		"-: 	Phone" << endl <<

		"Update Part" << endl <<
		"z: 	Increase Theta" << endl <<
		"x: 	Decrease Theta" << endl ;
	cout << "-------------------------------------------------------------------------------------------" << endl;
}

bool rightMousePressed = false;
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{
		double x, y;
		glfwGetCursorPos(window, &x, &y);

		float half_winx = WIDTH / 2.0;
		float half_winy = HEIGHT / 2.0;
		float lx = float(x - half_winx) / half_winx;
		float ly = float(HEIGHT - y - half_winy) / half_winy;

		glm::vec3 pos = light->getTranslation();

		pos.x = lx * 4;
		pos.y = ly * 2;
		pos.z = -10.0;
		if (pos.y > -0.5)pos.y = -1.0;
		light->setTranslation(pos);
	}
	else if (button == GLFW_MOUSE_BUTTON_RIGHT) {
		if (!camera_view) {
			if (action == GLFW_PRESS && !car_control) {
				rightMousePressed = true;
				glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED); // 隐藏光标并捕捉
			}
			else if (action == GLFW_RELEASE && !car_control) {
				rightMousePressed = false;
				glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL); // 显示光标并释放
			}
			else {
				rightMousePressed = true;
				glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED); // 隐藏光标并捕捉
			}
		}
		else {
			rightMousePressed = true;
			glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED); // 隐藏光标并捕捉
		}
	}
}

float d_pitch, d_yaw;
void cursor_position_callback(GLFWwindow* window, double xpos, double ypos) {
	static double lastX = xpos;
	static double lastY = ypos;
	static bool firstMouse = true;

	if (firstMouse) {
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	if (rightMousePressed) {
		double xoffset = xpos - lastX;
		double yoffset = lastY - ypos; // 注意这里y坐标是反的
		lastX = xpos;
		lastY = ypos;

		// 根据鼠标移动更新相机视角
		float sensitivity = 0.1f;
		xoffset *= -sensitivity;
		yoffset *= -sensitivity;

		
			pitch -= yoffset;				// 俯仰角加上 y 方向上的偏移量
			roll -= xoffset;					// 偏航角加上 x 方向上的偏移量
			if (pitch > 89.0f)				// 限制俯仰角
				pitch = 89.0f;
			if (pitch < -89.0f)
				pitch = -89.0f;
		
		//else if(camera_view) {
		//	pitch -= yoffset;
		//	if (pitch > 89.0f)				// 限制俯仰角
		//		pitch = 89.0f;
		//	if (pitch < -89.0f)
		//		pitch = -89.0f;
		//	if (roll - xoffset > d_yaw + 60.f)roll = d_yaw + 60.0f;
		//	else if (roll - xoffset < d_yaw - 60.f)roll = d_yaw - 60.0f;
		//	else roll -= xoffset;
		//}
	}
}
void init_camera() {
	pitch = -25;
	roll = 135;
	
	State = 0;
	add = glm::vec3(-25, 25, -25);
	camera->fov = 45.0;
	camera->aspect = 1.0;
	camera->scale = 1.5;
}

void init_obj() {
	xx = 0.1;
	zz = 0;
	for (auto it : robot.theta) {
		it = 0;
	}
	car_x = 0;
	car_z = -26;
	car_d = 270;

}


int up = 0;
int down = 0;
int right_c = 0;
int left_c = 0;
int now_angle = 0;
void car_direction(int angle) {
	if (angle == 0) {
		up++;
		down = left_c = right_c = 0;
		car_x += 0.3;
		add = glm::vec3(car_x - 15, 15, car_z - 3);
		if (up == 1) {
			pitch = -30;
			roll = 75;
		}
	}
	else if (angle == 180) {
		down++;
		up = left_c = right_c = 0;
		car_x -= 0.3;
		add = glm::vec3(car_x + 15, 15, car_z - 3);
		if (down == 1) {
			pitch = -30;
			roll = 290;

		}

	}
	else if (angle == 270) {
		right_c++;
		up = down = left_c = 0;
		car_z += 0.3;
		add = glm::vec3(car_x , 15, car_z - 20);
		if (right_c == 1) {
			pitch = -30;
			roll = 180;
		}
	}
	else if (angle == 90) {
		left_c++;
		up = down = right_c = 0;
		car_z -= 0.3;
		add = glm::vec3(car_x , 15, car_z + 10);
		if (left_c == 1) {
			pitch = -30;
			roll = 0;
		}
	}
}
void direction(int angle) {
	if (angle == 0) {
		up++;
		down = left_c = right_c = 0;
		robot.theta[0] = 0;
		zz += 0.1;
		if (!checkCharacterCollisions()) {
			zz -= 0.1;
		}
		State++;
		character_animation(State);
		add = glm::vec3(xx, 3.9, zz - 2.3);
		if (up == 1) {
			pitch = 0;
			roll = 180;
			d_pitch = 0;
			d_yaw = 180;
		}
	}
	else if (angle == 180) {
		down++;
		up = left_c = right_c = 0;
		robot.theta[0] = 180;
		zz -= 0.1;
		if (!checkCharacterCollisions()) {
			zz += 0.1;
		}
		State++;
		character_animation(State);
		add = glm::vec3(xx, 3.9, zz - 3.7);
		if (down == 1) {
			pitch = 0;
			roll = 0;
			d_pitch = 0;
			d_yaw = 0;
		}
	}
	else if (angle == 90) {
		left_c++;
		up = down = right_c = 0;
		robot.theta[0] = 90;
		xx += 0.1;
		if (!checkCharacterCollisions()) {
			xx -= 0.1;
		}
		State++;
		character_animation(State);
		add = glm::vec3(xx + 0.7, 3.9, zz - 3.0);
		if (left_c == 1) {
			pitch = 0;
			roll = 90;
			d_pitch = 0;
			d_yaw = 90;
		}
	}
	else if (angle == 270) {
		right_c++;
		up = down = left_c = 0;
		robot.theta[0] = 270;
		xx -= 0.1;
		if (!checkCharacterCollisions()) {
			xx += 0.1;
		}
		State++;
		character_animation(State);
		add = glm::vec3(xx - 0.7, 3.9, zz - 3.0);
		if (right_c == 1) {
			pitch = 0;
			roll = -90;
			d_pitch = 0;
			d_yaw = -90;
		}
	}
}
float upspeed = 0;
float g = 0.2;
void jump() {
	if (upspeed !=0){
		yy += upspeed;
		if (camera_view)add.y += upspeed;
		upspeed -= g;
	}
	if (yy == 3.5)upspeed = 0;
}

float movespeed = 0.1;
void move(int d) {
	float move_x = glm::sin(glm::radians(roll)) * movespeed;
	float move_z = -glm::cos(glm::radians(roll)) * movespeed;
	if (d == 1) {//前进
		xx += move_x;
		if (!checkCharacterCollisions()) {
			xx -= move_x;
		}
		else add.x = xx + 6 * move_x;
		zz += move_z;
		if (!checkCharacterCollisions()) {
			zz -= move_z;
		}
		else add.z = zz - 3.0 + 6 * move_z;
	}
	else if (d == 2) {//后退
		xx -= move_x;
		if (!checkCharacterCollisions()) {
			xx += move_x;
		}
		else add.x = xx + 6 * move_x;
		zz -= move_z;
		if (!checkCharacterCollisions()) {
			zz += move_z;
		}
		else add.z = zz - 3.0 + 6 * move_z;
	}
	else if (d == 3) {
		float move_xx = glm::sin(glm::radians(roll+90)) * movespeed;
		float move_zz = -glm::cos(glm::radians(roll+90)) * movespeed;
		xx -= move_xx;
		if (!checkCharacterCollisions()) {
			xx += move_xx;
		}
		else add.x = xx + 6 * move_x;
		zz -= move_zz;
		if (!checkCharacterCollisions()) {
			zz += move_zz;
		}
		else add.z = zz - 3.0 + 6 * move_z;
	}
	else if (d == 4) {
		float move_xx = glm::sin(glm::radians(roll - 90)) * movespeed;
		float move_zz = -glm::cos(glm::radians(roll - 90)) * movespeed;
		xx -= move_xx;
		if (!checkCharacterCollisions()) {
			xx += move_xx;
		}
		else add.x = xx + 6 * move_x;
		zz -= move_zz;
		if (!checkCharacterCollisions()) {
			zz += move_zz;
		}
		else add.z = zz - 3.0 + 6 * move_z;
	}
	State++;//改变动画关键帧
	character_animation(State);//人物移动时将会调用动画函数
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	if (key == GLFW_KEY_1 && mode == 0x0000) {
		Selected_mesh = robot.Torso;
	}
	else if (key == GLFW_KEY_2 && mode == 0x0000) {
		Selected_mesh = robot.Head;
	}
	else if (key == GLFW_KEY_3 && mode == 0x0000) {
		Selected_mesh = robot.RightUpperArm;
	}
	else if (key == GLFW_KEY_4 && mode == 0x0000) {
		Selected_mesh = robot.RightLowerArm;
	}
	else if (key == GLFW_KEY_5 && mode == 0x0000) {
		Selected_mesh = robot.LeftUpperArm;
	}
	else if (key == GLFW_KEY_6 && mode == 0x0000) {
		Selected_mesh = robot.LeftLowerArm;
	}
	else if (key == GLFW_KEY_7 && mode == 0x0000) {
		Selected_mesh = robot.RightUpperLeg;
	}
	else if (key == GLFW_KEY_8 && mode == 0x0000) {
		Selected_mesh = robot.RightLowerLeg;
	}
	else if (key == GLFW_KEY_9 && mode == 0x0000) {
		Selected_mesh = robot.LeftUpperLeg;
	}
	else if (key == GLFW_KEY_0 && mode == 0x0000) {
		Selected_mesh = robot.LeftLowerLeg;
	}
	else if (key == GLFW_KEY_MINUS && mode == 0x0000) {
		Selected_mesh = robot.Phone;
	}
	else if (key == GLFW_KEY_Z && mode == 0x0000) {
		robot.theta[Selected_mesh] -= 10.0;
		if (robot.theta[Selected_mesh] > 360.0)
			robot.theta[Selected_mesh] -= 360.0;
		// 向左转
	}
	else if (key == GLFW_KEY_X && mode == 0x0000) {
		robot.theta[Selected_mesh] += 10.0;
		if (robot.theta[Selected_mesh] < 0.0)
			robot.theta[Selected_mesh] += 360.0;
		// 向右转
	}
	else if (key == GLFW_KEY_F && action == GLFW_PRESS && mode == 0x0000) {
		scene += 1;
		scene %= 2;
	}
	else if (key == GLFW_KEY_P && action == GLFW_PRESS && mode == 0x0000) {
		night = !night;
	}
	else if (key == GLFW_KEY_R && action == GLFW_PRESS && mode == 0x0000) {
		if (scene == 1 && fabs(xx - h_x) <= 10 && fabs(zz - h_z) <= 10 && helicopter_control == 0 && camera_view == 0) {
			helicopter_control = !helicopter_control;
			yy = -50;
			if (helicopter_control == 1) {
				pitch = -30;
				roll = 0;
				add = glm::vec3(h_x , 15, h_z +5);
			}
		}
		else if (scene == 1 && helicopter_control == 1 && camera_view == 0) {
			helicopter_control = !helicopter_control;
			h_y = 3.5;
			yy = 3.5;
			xx = h_x + 7;
			zz = h_z;
		}
	}
	else if (key == GLFW_KEY_E && action == GLFW_PRESS && mode == 0x0000) {
		if (scene == 1&&fabs(xx-car_x)<=10&&fabs(zz-car_z)<=10 && car_control == 0 && camera_view ==0) { //在场景1的情况下才能进入汽车
			car_control = !car_control;
			yy -= 50;
			if (car_control == 1) {
				pitch = -30;
				roll = 75;
				add = glm::vec3(car_x - 15, 15, car_z - 3);
			}
		}
		else if (scene == 1 && car_control == 1 && camera_view == 0) {
			car_control = !car_control;
			yy = 3.5;
			xx = car_x -10;
			zz = car_z;
		}
	}
	else if (key == GLFW_KEY_F1 && action == GLFW_PRESS && mode == 0x0000) {
		camera_view = !camera_view;
		up = down = left_c = right_c = 0;
		
		if (camera_view == 0) {
			init_camera();
		}
		else if(camera_view && !car_control){
			add = glm::vec3(xx, 3.9, zz - 2.3);
			robot.theta[0] = 0;
			pitch = 0;
			roll = 180;
		}
	}
	// 通过按键上下左右改变相机位置
	else if (key == GLFW_KEY_UP && mode == 0x0000){
			glm::vec3 at2 = camera->at;
			glm::vec3 now = add;
			now.x = add.x + 0.01f * at2.x;
			if (now.x<50.0 && now.x > -50.0)
				add.x = now.x;
			now.y = add.y + 0.01f * at2.y;
			if (now.y < 50.0 && now.y > 0.0)
				add.y = now.y;
			now.z = add.z + 0.01f * at2.z;
			if (now.z<50.0 && now.z > -50.0)
				add.z = now.z;
	}
	else if (key == GLFW_KEY_LEFT && mode == 0x0000) {
		glm::vec3 at2 = glm::normalize(glm::cross(glm::vec3(camera->at), glm::vec3(camera->up)));
		glm::vec3 now = add;
		now.x = add.x - 0.6f * at2.x;
		if (now.x<50.0 && now.x > -50.0)
			add.x = now.x;
		now.y = add.y - 0.6f * at2.y;
		if (now.y < 50.0 && now.y > 0.0)
			add.y = now.y;
		now.z = add.z - 0.6f * at2.z;
		if (now.z<50.0 && now.z > -50.0)
			add.z = now.z;
	}
	else if (key == GLFW_KEY_DOWN && mode == 0x0000) {
		glm::vec3 at2 = camera->at;
		glm::vec3 now = add;
		now.x = add.x - 0.01f * at2.x;
		if (now.x<50.0 && now.x > -50.0)
			add.x = now.x;
		now.y = add.y - 0.01f * at2.y;
		if (now.y < 50.0 && now.y > 0.0)
			add.y = now.y;
		now.z = add.z - 0.01f * at2.z;
		if (now.z<50.0 && now.z > -50.0)
			add.z = now.z;
	}
	else if (key == GLFW_KEY_RIGHT && mode == 0x0000) {
		glm::vec3 at2 = glm::normalize(glm::cross(glm::vec3(camera->at), glm::vec3(camera->up)));
		glm::vec3 now = add;
		now.x = add.x + 0.6f * at2.x;
		if (now.x<50.0 && now.x > -50.0)
			add.x = now.x;
		now.y = add.y + 0.6f * at2.y;
		if (now.y < 50.0 && now.y > 0.0)
			add.y = now.y;
		now.z = add.z + 0.6f * at2.z;
		if (now.z<50.0 && now.z > -50.0)
			add.z = now.z;
	}
	// 方向键控制人物移动
	else if (key == GLFW_KEY_W && mode == 0x0000)
	{
		if (checkCharacterCollisions()) {
			if (!camera_view) { //第三人称
				if (car_control) { //汽车视角
					now_angle %= 360;
					car_direction(now_angle);
				}
				else if (helicopter_control) { //直升机视角
					glm::vec3 at2 = camera->at;
					glm::vec3 now = add;
					now.x = add.x + 0.01f * at2.x;
					if (now.x<50.0 && now.x > -50.0)
						add.x = now.x;
					now.y = add.y + 0.01f * at2.y;
					if (now.y < 50.0 && now.y > 15)
						add.y = now.y;
					now.z = add.z + 0.01f * at2.z;
					if (now.z<50.0 && now.z > -50.0)
						add.z = now.z;
					float move_x = glm::sin(glm::radians(roll));
					float move_z = -glm::cos(glm::radians(roll));
					h_x = add.x+0.5+10*move_x;
					h_y = add.y - 10;
					h_z = add.z+10*move_z;
					helicopter.theta[0] = 180-roll;
				}
				else{ //人物视角
					robot.theta[0] = 0;
					zz += 0.1;
					if (!checkCharacterCollisions()) {
						zz -= 0.1;
					}
					State++;//改变动画关键帧
					character_animation(State);//人物移动时将会调用动画函数
				}

			}
			else if (camera_view) { //人物第一人称
				robot.theta[0] = 180-roll;
				move(1);
			}
		}
	}
	else if (key == GLFW_KEY_S  && mode == 0x0000)
	{
		if (checkCharacterCollisions()) {
			if (!camera_view) {
				if (helicopter_control) {
					glm::vec3 at2 = camera->at;
					glm::vec3 now = add;
					now.x = add.x - 0.01f * at2.x;
					if (now.x<50.0 && now.x > -50.0)
						add.x = now.x;
					now.y = add.y - 0.01f * at2.y;
					if (now.y < 50.0 && now.y > 15.0)
						add.y = now.y;
					now.z = add.z - 0.01f * at2.z;
					if (now.z<50.0 && now.z > -50.0)
						add.z = now.z;
					float move_x = glm::sin(glm::radians(roll)) ;
					float move_z = -glm::cos(glm::radians(roll)) ;
					h_x = add.x + 0.5 + 10 * move_x;
					h_y = add.y - 10;
					h_z = add.z + 10 * move_z;
					helicopter.theta[0] = 180 - roll;
				}
				else {
					robot.theta[0] = 180;
					zz -= 0.1;
					if (!checkCharacterCollisions()) {
						zz += 0.1;
					}
					State++;//改变动画关键帧
					character_animation(State);
				}
				
			}
			else if (camera_view) {
				robot.theta[0] = 180 - roll;
				move(2);
			}
		}

	}
	else if (key == GLFW_KEY_A && mode == 0x0000)
	{	
		if (checkCharacterCollisions()) {
			if (!camera_view) {
				if (car_control) {
					if (action == GLFW_PRESS) {
						car_d += 90;
						car_d %= 360;
						now_angle += 90;
						now_angle %= 360;
						car_direction(now_angle);
					}
				}
				else if (helicopter_control) {
					glm::vec3 at2 = glm::normalize(glm::cross(glm::vec3(camera->at), glm::vec3(camera->up)));
					glm::vec3 now = add;
					now.x = add.x - 0.6f * at2.x;
					if (now.x<50.0 && now.x > -50.0)
						add.x = now.x;
					now.y = add.y - 0.6f * at2.y;
					if (now.y < 50.0 && now.y > 0.0)
						add.y = now.y;
					now.z = add.z - 0.6f * at2.z;
					if (now.z<50.0 && now.z > -50.0)
						add.z = now.z;
					float move_x = glm::sin(glm::radians(roll));
					float move_z = -glm::cos(glm::radians(roll));
					h_x = add.x + 0.5 + 10 * move_x;
					h_y = add.y - 10;
					h_z = add.z + 10 * move_z;
					helicopter.theta[0] = 180 - roll;
				}
				else {
					robot.theta[0] = 90;
					xx += 0.1;
					if (!checkCharacterCollisions()) {
						xx -= 0.1;
					}
					State++;//改变动画关键帧
					character_animation(State);
				}
			}
			else if (camera_view) {
				robot.theta[0] = 180 - roll;
				move(3);
			}
		}

	}
	else if (key == GLFW_KEY_D && mode == 0x0000)
	{
		if (checkCharacterCollisions()) {
			if (!camera_view) {
				if (car_control) {
					if (action == GLFW_PRESS) {
						car_d -= 90;
						car_d = car_d > 0 ? car_d : car_d + 360;
						now_angle -= 90;
						if (now_angle < 0)now_angle += 360;
						now_angle %= 360;
						car_direction(now_angle);
					}
				}
				else if (helicopter_control) {
					glm::vec3 at2 = glm::normalize(glm::cross(glm::vec3(camera->at), glm::vec3(camera->up)));
					glm::vec3 now = add;
					now.x = add.x + 0.6f * at2.x;
					if (now.x<50.0 && now.x > -50.0)
						add.x = now.x;
					now.y = add.y + 0.6f * at2.y;
					if (now.y < 50.0 && now.y > 0.0)
						add.y = now.y;
					now.z = add.z + 0.6f * at2.z;
					if (now.z<50.0 && now.z > -50.0)
						add.z = now.z;
					float move_x = glm::sin(glm::radians(roll));
					float move_z = -glm::cos(glm::radians(roll));
					h_x = add.x + 0.5 + 10 * move_x;
					h_y = add.y - 10;
					h_z = add.z + 10 * move_z;
					helicopter.theta[0] = 180 - roll;
				}
				else {
					robot.theta[0] = 270;
					xx -= 0.1;
					if (!checkCharacterCollisions()) {
						xx += 0.1;
					}
					State++;
					character_animation(State);
				}
			}
			else if (camera_view) {
				robot.theta[0] = 180 - roll;
				move(4);
			}
		}
		
	}
	else if (key == GLFW_KEY_SPACE && action == GLFW_PRESS && mode == 0x0000) {
		if (yy == 3.5)upspeed = 0.5;

	}
	// 空格键初始化所有参数
	else if (key == GLFW_KEY_L && action == GLFW_PRESS && mode == 0x0000) {
		init_camera();
		init_obj();
	}
	//Esc 退出
	else if (key == GLFW_KEY_ESCAPE && mode == 0x0000)
	{
		exit(EXIT_SUCCESS); 

	}
	//H 打开帮助助手
	else if (key == GLFW_KEY_H && mode == 0x0000)
	{
		printHelp();
	}
}



void cleanData() {
	delete camera;
	camera = NULL;

	delete light;
	light = NULL;

	painter->cleanMeshes();

	delete painter;
	painter = NULL;

	for (int i = 0; i < meshList.size(); i++) {
		delete meshList[i];
	}
	meshList.clear();
}


int fire_num=0;
int main(int argc, char** argv)
{
	// 初始化GLFW库，必须是应用程序调用的第一个GLFW函数
	glfwInit();

	// 配置GLFW
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// 配置窗口属性
	GLFWwindow* window = glfwCreateWindow(600, 600, u8"2022150221_HeZeFeng_FinalProject", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetKeyCallback(window, key_callback);
	//glfwSetCursorPosCallback(window,mouse_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, cursor_position_callback);

	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << endl;
		return -1;
	}

	// Init mesh, shaders, buffer
	init();
	// 输出帮助信息
	printHelp();
	// 启用深度测试
	glEnable(GL_DEPTH_TEST);

	// 用于计时的变量
	double lastTime = glfwGetTime();
	double accumulatedTime = 0.0;
	double deltaTime;
	double lastTime1 = glfwGetTime();
	double accumulatedTime1 = 0.0;
	double deltaTime1;
	while (!glfwWindowShouldClose(window))
	{
		display();

		if (camera_view) {
			float v = robot.theta[0];
			float tmp = 180 - (roll+v);
			robot.theta[1] =tmp;
		}
		double currentTime = glfwGetTime();
		deltaTime = currentTime - lastTime;
		if (deltaTime > 0.1) {
			lastTime = currentTime;
			jump();
			if (helicopter_control) {
				fan_rotate += 45;
				if (fan_rotate > 360)fan_rotate -= 360;
			}
		}
		double currentTime1 = glfwGetTime();
		deltaTime1 = currentTime1 - lastTime1;
		if (deltaTime1 > 0.3) {
			fire();
			lastTime1 = currentTime1;
			fire_num++;
			fire_num %= 3;
			if (fire_num == 0) {
				fire1_y = 1.5;
				fire2_y = -10;
				fire3_y = -10;

			}
			else if (fire_num == 1) {
				fire1_y = -10;
				fire2_y = 1.5;
				fire3_y = -10;
			}
			else{
				fire1_y = -10;
				fire2_y = -10;
				fire3_y = 1.5;
			}


		}
		
		Dynamic_lighting();
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	cleanData();

	return 0;
}