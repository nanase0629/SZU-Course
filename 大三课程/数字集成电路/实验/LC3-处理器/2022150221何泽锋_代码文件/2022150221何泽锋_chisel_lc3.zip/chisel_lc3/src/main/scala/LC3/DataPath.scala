package LC3

import chisel3._
import chisel3.util._

class FeedBack extends Bundle {
  val sig = Output(UInt(10.W))     // control signal. sig[9:4]: j   sig[3:1]: cond   sig[0]: ird
  val int = Output(Bool())         // high priority device request
  val r   = Output(Bool())         // ready: memory operations is finished
  val ir  = Output(UInt(4.W))      // opcode
  val ben = Output(Bool())         // br can be executed
  val psr = Output(Bool())         // privilege: supervisor or user
}

class IOMap extends Module {
  val io = IO(new Bundle{
    val mar = Input(UInt(16.W))
    val mio_en = Input(Bool())
    val r_w = Input(Bool())

    val r_kbsr = Output(Bool())
    val r_kbdr = Output(Bool())
    val r_dsr  = Output(Bool())
    val r_mem  = Output(Bool())

    val w_kbsr = Output(Bool())
    val w_dsr  = Output(Bool())
    val w_ddr  = Output(Bool())
  })

  // Need write
  // 特殊寄存器的内存映射地址
  val KBSR_ADDR = 0xFE00.U
  val KBDR_ADDR = 0xFE02.U
  val DSR_ADDR  = 0xFE04.U
  val DDR_ADDR  = 0xFE06.U

  // 初始化输出信号
  io.r_kbsr := false.B
  io.r_kbdr := false.B
  io.r_dsr  := false.B
  io.r_mem  := false.B
  io.w_kbsr := false.B
  io.w_dsr  := false.B
  io.w_ddr  := false.B

  // 当mio_en为true时，根据r_w的值进行读或写操作
  when(io.mio_en) {
    when(io.r_w) { // 写操作
      when(io.mar === KBSR_ADDR) {
        io.w_kbsr := true.B
      }
      when(io.mar === DSR_ADDR) {
        io.w_dsr := true.B
      }
      when(io.mar === DDR_ADDR) {
        io.w_ddr := true.B
      }
    } .otherwise { // 读操作
      when(io.mar === KBDR_ADDR) {
        io.r_kbdr := true.B
      }
      when(io.mar === KBSR_ADDR) {
        io.r_kbsr := true.B
      }
      when(io.mar === DSR_ADDR) {
        io.r_dsr := true.B
      }
      when(io.mar < 0xfe00.U) {
        io.r_mem := true.B
      }
    }
  }
}

class DataPath extends Module {
  val io = IO(new Bundle{
    val signal = Input(new signalEntry)
    val mem = Flipped(new MemIO)
    val out = new FeedBack

    val initPC = Flipped(ValidIO(Input(UInt(16.W))))
    val uartRx = Flipped(DecoupledIO(UInt(8.W)))
    val uartTx = DecoupledIO(UInt(8.W))

    val end = Output(Bool())
  })

  val SIG = io.signal
  val time = GTimer()

  val SP = 6.U(3.W)
  val R7 = 7.U(3.W)

  // 初始化
  val PC  = RegInit("h3000".U(16.W)) // TODO: Maybe the PC can be dynamically specified by the image
  val RESET_PC  = RegInit("h3000".U(16.W))
  when(io.initPC.valid) {
    PC := io.initPC.bits
    RESET_PC := io.initPC.bits
  }
  val IR  = RegInit(0.U(16.W))
  val MAR = RegInit(0.U(16.W))
  val MDR = RegInit(0.U(16.W))
  val PSR = RegInit(0.U(16.W))

  val KBDR = RegInit(0.U(16.W))
  val KBSR = RegInit(0.U(16.W))
  val DDR  = RegInit(0.U(16.W))
  val DSR  = RegInit(0.U(16.W))

  val BEN = RegInit(false.B)
  val N = RegInit(false.B)
  val P = RegInit(false.B)
  val Z = RegInit(true.B)

  val ADDR1MUX  = Wire(UInt(16.W))
  val ADDR2MUX  = Wire(UInt(16.W))

  val PCMUX     = Wire(UInt(16.W))
  val DRMUX     = Wire(UInt(16.W))
  val SR1MUX    = Wire(UInt(16.W))
  val SR2MUX    = Wire(UInt(16.W))
  val SPMUX     = Wire(UInt(16.W))
  val MARMUX    = Wire(UInt(16.W))
  val VectorMUX = Wire(UInt(16.W))
  val PSRMUX    = Wire(UInt(16.W))
  val addrOut   = Wire(UInt(16.W))
  val aluOut    = Wire(UInt(16.W))
  val GATEOUT   = WireInit(0.U(16.W))
  val r1Data    = WireInit(0.U(16.W))
  val r2Data    = WireInit(0.U(16.W))

  // IR Decode
  val offset5  = SignExt(IR(4,0),  16)  //imm
  val offset6  = SignExt(IR(5,0),  16)
  val offset9  = SignExt(IR(8,0),  16)  // PC offset
  val offset11 = SignExt(IR(10,0), 16)  // (JSP)
  val offset8  = ZeroExt(IR(7,0),  16)  // interrupt vector (TRAP)

  /********  Mux  ********/

  ADDR1MUX := Mux(SIG.ADDR1_MUX, r1Data, PC)

  ADDR2MUX := MuxLookup(SIG.ADDR2_MUX, 0.U, Seq(
    0.U -> 0.U,
    1.U -> offset6,
    2.U -> offset9,
    3.U -> offset11
  ))

  addrOut := ADDR1MUX + ADDR2MUX

  PCMUX := MuxLookup(SIG.PC_MUX, RESET_PC, Seq(
    0.U -> Mux(PC===0.U, RESET_PC,  PC + 1.U),
    1.U -> GATEOUT,
    2.U -> addrOut
  ))

  // 实验五-任务一：选择器连接

  DRMUX := MuxLookup(SIG.DR_MUX, IR(11,9), Seq(
    0.U -> IR(11,9),
    1.U -> R7,
    2.U -> SP
  ))

  SR1MUX := MuxLookup(SIG.SR1_MUX, IR(11,9), Seq(
    0.U -> IR(11,9),
    1.U -> IR(8,6),
    2.U -> SP
  ))

  SR2MUX := Mux(IR(5), offset5, r2Data)

  SPMUX := MuxLookup(SIG.SP_MUX, r1Data+1.U, Seq(
    0.U -> (r1Data+1.U),
    1.U -> (r1Data-1.U),
    2.U -> SP, // TODO: Supervisor StackPointer
    3.U -> SP  // TODO: User StackPointer
  ))

  MARMUX := Mux(SIG.MAR_MUX, addrOut, offset8)

  VectorMUX := MuxLookup(SIG.VECTOR_MUX, 0.U, Seq(  // TODO: Interrupt
    0.U -> 0.U,
    1.U -> 0.U,
    2.U -> 0.U
  ))

  PSRMUX := 0.U

  /*********** ALU Interface ****************/
  val alu = Module(new ALU)
  alu.io.ina := r1Data
  alu.io.inb := SR2MUX
  alu.io.op := SIG.ALUK
  aluOut := alu.io.out

  /*********** Regfile Interface ****************/
  // 实验五-任务二：寄存器堆例化与端口连接
  val regfile  = Module(new Regfile)
  regfile.io.wen :=SIG.LD_REG
  regfile.io.wAddr :=DRMUX
  regfile.io.r1Addr:=SR1MUX
  regfile.io.r2Addr:=IR(2,0)
  regfile.io.wData:=GATEOUT
  r1Data:=regfile.io.r1Data
  r2Data:=regfile.io.r2Data

  val dstData = WireInit(regfile.io.wData)

  /*********** Memory ****************/

  // address control logic that convered by truth table

  val iomap = Module(new IOMap)
  iomap.io.mar := MAR
  iomap.io.mio_en := SIG.MIO_EN
  iomap.io.r_w := SIG.R_W

  //val MEM_EN = SIG.MIO_EN && MAR < 0xfe00.U
  val MEM_RD = SIG.MIO_EN && !SIG.R_W
  val MEM_EN = SIG.MIO_EN && (MAR < 0xfe00.U)

  // val IN_MUX = MuxCase(io.mem.rdata, Array(
  //   (MEM_RD && (MAR === 0xfe00.U)) -> KBSR,
  //   (MEM_RD && (MAR === 0xfe02.U)) -> KBDR,
  //   (MEM_RD && (MAR === 0xfe04.U)) -> DSR,
  //   (MEM_EN && !SIG.R_W) -> io.mem.rdata
  //   ))

  val IN_MUX = MuxCase(iomap.io.r_mem, Array(
    (iomap.io.r_kbsr) -> KBSR,
    (iomap.io.r_kbdr) -> KBDR,
    (iomap.io.r_dsr) -> DSR,
    (iomap.io.r_mem) -> io.mem.rdata
    ))

  // UART Input
  io.uartRx.ready := !KBSR(15).asBool
  when(io.uartRx.fire) {
    KBDR := Cat(0.U(8.W), io.uartRx.bits)
    KBSR := Cat(1.U(1.W), 0.U(15.W))
  }

  // val LD_KBSR = (MAR === 0xfe00.U) && SIG.MIO_EN && SIG.R_W
  // val LD_DSR  = (MAR === 0xfe04.U) && SIG.MIO_EN && SIG.R_W
  // val LD_DDR  = (MAR === 0xfe06.U) && SIG.MIO_EN && SIG.R_W

  val LD_KBSR = iomap.io.w_kbsr
  val LD_DSR  = iomap.io.w_dsr
  val LD_DDR  = iomap.io.w_ddr

  // UART Output
  DSR := Cat(io.uartTx.ready, 0.U(15.W))
  io.uartTx.valid := RegNext(LD_DDR)
  io.uartTx.bits  := DDR(7, 0)

  io.mem.raddr   := MAR
  io.mem.waddr   := MAR
  io.mem.wdata  := MDR
  io.mem.wen    := SIG.MIO_EN && SIG.R_W
  io.mem.mio_en := SIG.MIO_EN


  // 实验五-任务三：连接总线
  GATEOUT := PC
  when(SIG.GATE_PC){ GATEOUT := PC }
  when(SIG.GATE_MDR){ GATEOUT := MDR }
  when(SIG.GATE_ALU){ GATEOUT := aluOut }
  when(SIG.GATE_MARMUX){ GATEOUT := MARMUX}
  when(SIG.GATE_VECTOR){ GATEOUT := Cat(1.U(8.W), 0.U) }
  when(SIG.GATE_PC1){ GATEOUT := PC - 1.U }
  when(SIG.GATE_PSR){ GATEOUT := Cat(Seq(0.U(13.W), PSRMUX)) }
  when(SIG.GATE_SP){ GATEOUT := SPMUX }

  /********  LD  ********/

  when(SIG.LD_MAR) { MAR := GATEOUT }
  when(SIG.LD_MDR) { MDR := Mux(SIG.MIO_EN, IN_MUX, GATEOUT) }

  when(SIG.LD_IR)  { IR  := MDR }
  when(SIG.LD_BEN) { BEN := IR(11) && N || IR(10) && Z || IR(9) && P }
  when(SIG.LD_PC || time === 0.U)  { PC := PCMUX }

  when(SIG.LD_CC) {
    N := dstData(15)
    Z := !dstData.orR()
    P := !dstData(15) && dstData.orR()
  }

  when(LD_KBSR) { KBSR := MDR }
  when(LD_DSR)  { DSR  := MDR }
  when(LD_DDR)  { DDR  := MDR }


  //OUT//
  io.out.sig  := DontCare
  io.out.int  := false.B
  io.out.r    := io.mem.R
  io.out.ir   := IR(15, 12)
  io.out.ben  := BEN
  io.out.psr  := PSR(15)

  // Stop LC3 when program run end
  val PRE_IR = RegNext(IR)
  val END = RegInit(false.B)
  io.end := END
  when(IR === 0.U && PRE_IR =/= 0.U) {
    END := true.B
  }
}

