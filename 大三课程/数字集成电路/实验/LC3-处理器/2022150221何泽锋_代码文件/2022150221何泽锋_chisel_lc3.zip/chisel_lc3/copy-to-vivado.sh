cp ./build/TopMain.v /mnt/d/lc3_demo/lc3_demo.srcs/sources_1/new
